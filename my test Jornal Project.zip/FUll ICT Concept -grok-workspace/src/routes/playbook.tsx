import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowDown,
  ArrowUp,
  ChevronDown,
  ChevronUp,
  Ellipsis,
  Eye,
  Pencil,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { useDeskStore } from "@/lib/ict-store";
import { syncDeskToServer } from "@/lib/desk-sync";
import { closedTrades, fmtCurrency, instrumentOf, tradeDollarPnl } from "@/lib/ict-calc";
import { formatR } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ConfirmDelete } from "@/components/desk/confirm-delete";
import { PlaybookFormModal } from "@/components/playbook/playbook-form-modal";
import { PlaybookDetailModal } from "@/components/playbook/playbook-detail-modal";
import type { SetupModel } from "@/lib/ict-types";

export const Route = createFileRoute("/playbook")({ component: PlaybookPage });

function PlaybookPage() {
  const data = useDeskStore();
  const models = useDeskStore((s) => s.models);
  const recentlyDeletedModels = useDeskStore((s) => s.recentlyDeletedModels ?? []);
  const trades = useDeskStore((s) => s.trades);
  const removeModel = useDeskStore((s) => s.removeModel);
  const restoreModel = useDeskStore((s) => s.restoreModel);
  const permanentlyDeleteModel = useDeskStore((s) => s.permanentlyDeleteModel);
  const upsertModel = useDeskStore((s) => s.upsertModel);

  const [query, setQuery] = useState("");
  const [filterTab, setFilterTab] = useState<"active" | "inactive" | "all">("active");
  const [sortDirection, setSortDirection] = useState<"desc" | "asc">("desc");
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<SetupModel | null>(null);
  const [viewingModel, setViewingModel] = useState<SetupModel | null>(null);
  const [deletingModel, setDeletingModel] = useState<SetupModel | null>(null);
  const [permDeletingModel, setPermDeletingModel] = useState<SetupModel | null>(null);
  const [deletedSectionOpen, setDeletedSectionOpen] = useState(true);

  // Filtered models
  const filteredModels = useMemo(() => {
    return models.filter((m) => {
      if (filterTab === "active" && !m.active) return false;
      if (filterTab === "inactive" && m.active) return false;
      if (query.trim()) {
        const q = query.toLowerCase();
        const matchName = m.name.toLowerCase().includes(q);
        const matchCode = m.code.toLowerCase().includes(q);
        const matchMarket = (m.market || "").toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchMarket) return false;
      }
      return true;
    });
  }, [models, filterTab, query]);

  // Compute stats for each model
  const modelStats = useMemo(() => {
    const map = new Map<
      string,
      {
        closedCount: number;
        winRate: number;
        netPnL: number;
        profitFactor: number;
        expectancy: number;
        avgR: number;
        rulesFollowedPct: number;
        assessedCount: number;
        followedCount: number;
      }
    >();

    for (const m of models) {
      const sample = closedTrades(
        trades.filter((t) => t.modelId === m.id || t.modelName.toLowerCase() === m.name.toLowerCase()),
      );

      let netPnL = 0;
      let grossProfit = 0;
      let grossLoss = 0;
      let sumR = 0;
      let wins = 0;
      let totalAssessed = 0;
      let totalFollowed = 0;

      for (const t of sample) {
        const inst = instrumentOf(data, t.market);
        const pnl = tradeDollarPnl(t, inst);
        const net = pnl.net ?? 0;
        netPnL += net;
        if (net > 0) grossProfit += net;
        else if (net < 0) grossLoss += Math.abs(net);

        const r = t.rMultiple ?? 0;
        sumR += r;
        if (t.result === "win") wins += 1;

        // Rules assessment count
        const assessments = t.rulesAssessment ? Object.values(t.rulesAssessment) : [];
        if (assessments.length > 0) {
          totalAssessed += assessments.length;
          totalFollowed += assessments.filter((v) => v === "followed").length;
        } else {
          // Default assumed 8 rules per trade
          totalAssessed += 8;
          totalFollowed += t.ruleFollowed ? 7 : 4;
        }
      }

      const closedCount = sample.length;
      const winRate = closedCount > 0 ? Math.round((wins / closedCount) * 100) : 0;
      const profitFactor = grossLoss === 0 ? (grossProfit > 0 ? Infinity : 0) : Number((grossProfit / grossLoss).toFixed(2));
      const expectancy = closedCount > 0 ? Number((netPnL / closedCount).toFixed(2)) : 0;
      const avgR = closedCount > 0 ? Number((sumR / closedCount).toFixed(2)) : 0;
      const rulesFollowedPct = totalAssessed > 0 ? Math.round((totalFollowed / totalAssessed) * 100) : 100;

      map.set(m.id, {
        closedCount,
        winRate,
        netPnL,
        profitFactor,
        expectancy,
        avgR,
        rulesFollowedPct,
        assessedCount: totalAssessed,
        followedCount: totalFollowed,
      });
    }

    return map;
  }, [models, trades, data]);

  // Sorted list of models
  const sortedModels = useMemo(() => {
    return filteredModels.slice().sort((a, b) => {
      const statsA = modelStats.get(a.id);
      const statsB = modelStats.get(b.id);
      const pnlA = statsA?.netPnL ?? 0;
      const pnlB = statsB?.netPnL ?? 0;
      return sortDirection === "desc" ? pnlB - pnlA : pnlA - pnlB;
    });
  }, [filteredModels, modelStats, sortDirection]);

  // Overall totals
  const allClosedTrades = closedTrades(trades);
  const totalNetPnL = allClosedTrades.reduce((acc, t) => {
    const pnl = tradeDollarPnl(t, instrumentOf(data, t.market));
    return acc + (pnl.net ?? 0);
  }, 0);

  const activeCount = models.filter((m) => m.active).length;
  const inactiveCount = models.filter((m) => !m.active).length;

  const handleOpenCreate = () => {
    setEditingModel(null);
    setCreateModalOpen(true);
  };

  const handleOpenEdit = (m: SetupModel) => {
    setEditingModel(m);
    setCreateModalOpen(true);
  };

  const handleToggleActive = async (m: SetupModel) => {
    const updated = { ...m, active: !m.active };
    upsertModel(updated);
    await syncDeskToServer();
    toast.success(updated.active ? `Activated ${m.name}` : `Deactivated ${m.name}`);
  };

  const handleConfirmDelete = async () => {
    if (!deletingModel) return;
    removeModel(deletingModel.id);
    await syncDeskToServer();
    toast.success(`Moved ${deletingModel.name} to recently deleted`);
    setDeletingModel(null);
  };

  const handleRestore = async (id: string, name: string) => {
    const success = restoreModel(id);
    if (success) {
      await syncDeskToServer();
      toast.success(`Restored ${name}`);
    } else {
      toast.error("Could not restore. Another active model already uses that code.");
    }
  };

  const handlePermanentDelete = async () => {
    if (!permDeletingModel) return;
    permanentlyDeleteModel(permDeletingModel.id);
    await syncDeskToServer();
    toast.success(`Permanently deleted ${permDeletingModel.name}`);
    setPermDeletingModel(null);
  };

  return (
    <AppShell>
      <div className="mx-auto w-full max-w-[1152px] px-4 pt-6 sm:px-8">
        {/* Page Title Row */}
        <div className="flex h-12 items-center justify-between">
          <h1 className="font-display text-[36px] leading-none tracking-tight text-white">Playbook</h1>
          <button
            type="button"
            onClick={handleOpenCreate}
            className="flex h-9 items-center gap-1.5 rounded-md bg-[#e50914] px-3.5 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] transition-colors hover:brightness-110"
          >
            <Plus className="size-3.5" />
            <span>Create playbook</span>
          </button>
        </div>

        {/* Toolbar Row */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {/* Search */}
          <div className="flex h-10 w-[300px] items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-white">
            <Search className="size-3.5 text-[#6f6f6d]" />
            <input
              type="text"
              placeholder="Search name or code"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-transparent text-[13px] placeholder-[#6f6f6d] outline-none"
            />
          </div>

          {/* Segmented Filter */}
          <div className="flex h-10 overflow-hidden rounded-md border border-white/[0.1] text-[12px] font-medium">
            <button
              type="button"
              onClick={() => setFilterTab("active")}
              className={`flex items-center px-3 transition-colors ${
                filterTab === "active"
                  ? "bg-white/[0.08] font-semibold text-white"
                  : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"
              }`}
            >
              Active <span className="font-mono ml-1.5 text-[#a2a2a0]">{activeCount}</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterTab("inactive")}
              className={`flex items-center border-l border-white/[0.1] px-3 transition-colors ${
                filterTab === "inactive"
                  ? "bg-white/[0.08] font-semibold text-white"
                  : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"
              }`}
            >
              Inactive <span className="font-mono ml-1.5 text-[#a2a2a0]">{inactiveCount}</span>
            </button>
            <button
              type="button"
              onClick={() => setFilterTab("all")}
              className={`flex items-center border-l border-white/[0.1] px-3 transition-colors ${
                filterTab === "all"
                  ? "bg-white/[0.08] font-semibold text-white"
                  : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"
              }`}
            >
              All
            </button>
          </div>

          {/* Date range caption */}
          <span className="ml-auto text-[12px] text-[#a2a2a0]">
            Closed trades · Oct 1 – Oct 29, 2026
          </span>
        </div>

        {/* Playbook Statistics Table Section */}
        <section className="relative mt-4 overflow-hidden rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e50914]/60 to-transparent" />

          <div className="overflow-x-auto">
            <table className="w-full min-w-[960px] table-fixed text-[13px]">
              <colgroup>
                <col style={{ width: "280px" }} />
                <col style={{ width: "70px" }} />
                <col style={{ width: "84px" }} />
                <col style={{ width: "110px" }} />
                <col style={{ width: "90px" }} />
                <col style={{ width: "104px" }} />
                <col style={{ width: "80px" }} />
                <col />
                <col style={{ width: "48px" }} />
              </colgroup>
              <thead>
                <tr className="h-9 border-b border-white/[0.07] text-left text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase">
                  <th className="px-4 font-semibold">Playbook</th>
                  <th className="px-3 text-right font-semibold">Trades</th>
                  <th className="px-3 text-right font-semibold">Win rate</th>
                  <th className="px-3 text-right font-semibold">
                    <button
                      type="button"
                      onClick={() => setSortDirection((d) => (d === "desc" ? "asc" : "desc"))}
                      className="inline-flex items-center gap-1 text-white hover:text-[#e50914]"
                    >
                      Net P&amp;L
                      {sortDirection === "desc" ? (
                        <ArrowDown className="size-3 text-[#e50914]" />
                      ) : (
                        <ArrowUp className="size-3 text-[#e50914]" />
                      )}
                    </button>
                  </th>
                  <th className="px-3 text-right font-semibold">Profit factor</th>
                  <th className="px-3 text-right font-semibold">Expectancy</th>
                  <th className="px-3 text-right font-semibold">Avg R</th>
                  <th className="px-3 text-right font-semibold">Rules followed</th>
                  <th aria-label="Actions" className="w-12" />
                </tr>
              </thead>
              <tbody className="[&>tr]:h-16 [&>tr]:border-b [&>tr]:border-white/[0.05]">
                {sortedModels.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-12 text-center text-sm text-[#a2a2a0]">
                      No playbooks match your criteria.
                    </td>
                  </tr>
                ) : (
                  sortedModels.map((m) => {
                    const stats = modelStats.get(m.id) ?? {
                      closedCount: 0,
                      winRate: 0,
                      netPnL: 0,
                      profitFactor: 0,
                      expectancy: 0,
                      avgR: 0,
                      rulesFollowedPct: 100,
                      assessedCount: 0,
                      followedCount: 0,
                    };

                    const isNegative = stats.netPnL < 0;
                    const pfDisplay = stats.profitFactor === Infinity ? "∞" : stats.profitFactor.toFixed(2);
                    const rulesWarning = stats.rulesFollowedPct < 70;

                    return (
                      <tr
                        key={m.id}
                        className="transition-colors hover:bg-white/[0.03]"
                      >
                        {/* Playbook info */}
                        <td className="px-4">
                          <div className="flex items-center gap-3">
                            <span className="font-mono flex size-8 shrink-0 items-center justify-center rounded-md border border-[#e50914]/40 bg-[#e50914]/10 text-[13px] font-semibold text-[#e50914]">
                              {m.code}
                            </span>
                            <div className="min-w-0">
                              <p className="truncate font-semibold text-white">{m.name}</p>
                              <p className="font-mono mt-0.5 text-[11px] text-[#a2a2a0]">
                                {m.market} · {m.timeframe}
                              </p>
                            </div>
                          </div>
                        </td>

                        {/* Trades */}
                        <td className="font-mono px-3 text-right text-white">
                          {stats.closedCount}
                        </td>

                        {/* Win Rate */}
                        <td className="font-mono px-3 text-right text-white">
                          {stats.winRate}%
                        </td>

                        {/* Net P&L */}
                        <td
                          className={`font-mono px-3 text-right font-medium ${
                            stats.netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"
                          }`}
                        >
                          {fmtCurrency(stats.netPnL)}
                        </td>

                        {/* Profit Factor */}
                        <td className="font-mono px-3 text-right text-white">
                          {pfDisplay}
                        </td>

                        {/* Expectancy */}
                        <td
                          className={`font-mono px-3 text-right ${
                            stats.expectancy >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"
                          }`}
                        >
                          {fmtCurrency(stats.expectancy)}
                        </td>

                        {/* Avg R */}
                        <td
                          className={`font-mono px-3 text-right ${
                            stats.avgR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"
                          }`}
                        >
                          {formatR(stats.avgR)}
                        </td>

                        {/* Rules followed */}
                        <td className="px-3 text-right">
                          <p
                            className={`font-mono ${
                              rulesWarning ? "text-[#f5b942]" : "text-white"
                            }`}
                          >
                            {stats.rulesFollowedPct}%
                          </p>
                          <p className="font-mono text-[11px] text-[#a2a2a0]">
                            {stats.followedCount} of {stats.assessedCount} assessed
                          </p>
                        </td>

                        {/* Actions */}
                        <td className="pr-3 text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button
                                type="button"
                                aria-label="Model options"
                                className="flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white"
                              >
                                <Ellipsis className="size-4" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent className="w-48 border-white/[0.1] bg-[#121212] text-white">
                              <DropdownMenuItem onClick={() => setViewingModel(m)}>
                                <Eye className="mr-2 size-3.5 text-[#a2a2a0]" /> View details
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleOpenEdit(m)}>
                                <Pencil className="mr-2 size-3.5 text-[#a2a2a0]" /> Edit playbook
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleToggleActive(m)}>
                                <RotateCcw className="mr-2 size-3.5 text-[#a2a2a0]" />
                                {m.active ? "Deactivate" : "Activate"}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator className="bg-white/[0.08]" />
                              <DropdownMenuItem
                                onClick={() => setDeletingModel(m)}
                                className="text-[#ff6b7d] focus:text-[#ff6b7d]"
                              >
                                <Trash2 className="mr-2 size-3.5" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Table summary footer */}
          <div className="flex h-11 items-center justify-between px-4 text-[12px] text-[#a2a2a0]">
            <div>
              <span className="font-mono text-[#d6d6d4]">{models.length}</span> playbooks ·{" "}
              <span className="font-mono text-[#d6d6d4]">{allClosedTrades.length}</span> closed trades · Net P&amp;L{" "}
              <span className={`font-mono font-medium ${totalNetPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`}>
                {fmtCurrency(totalNetPnL)}
              </span>
            </div>
            <div>
              Unassigned trades: <span className="font-mono text-[#d6d6d4]">0</span>
            </div>
          </div>
        </section>

        {/* Recently Deleted Section */}
        {recentlyDeletedModels.length > 0 && (
          <section className="mt-4 rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85">
            <div
              onClick={() => setDeletedSectionOpen(!deletedSectionOpen)}
              className="flex h-12 cursor-pointer items-center justify-between px-4 transition-colors hover:bg-white/[0.02]"
            >
              <span className="flex items-center gap-2 text-[13px] font-semibold text-white">
                {deletedSectionOpen ? (
                  <ChevronDown className="size-3.5 text-[#a2a2a0]" />
                ) : (
                  <ChevronUp className="size-3.5 text-[#a2a2a0]" />
                )}
                Recently deleted{" "}
                <span className="font-mono text-[12px] font-normal text-[#a2a2a0]">
                  {recentlyDeletedModels.length}
                </span>
              </span>
              <span className="text-[12px] text-[#a2a2a0]">Linked trades are kept</span>
            </div>

            {deletedSectionOpen && (
              <div className="border-t border-white/[0.06]">
                {recentlyDeletedModels.map((item) => {
                  const m = item.model;
                  const deletedDate = new Date(item.deletedAt);
                  const formattedDeleted = !Number.isNaN(deletedDate.getTime())
                    ? `Deleted ${deletedDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}, ${deletedDate.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}`
                    : "Deleted recently";

                  return (
                    <div
                      key={m.id}
                      className="flex flex-wrap items-center justify-between border-b border-white/[0.04] px-4 py-3 text-[13px] last:border-b-0"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono flex size-8 items-center justify-center rounded-md border border-white/[0.12] text-[13px] text-[#a2a2a0]">
                          {m.code}
                        </span>
                        <div>
                          <p className="font-medium text-[#d6d6d4]">{m.name}</p>
                          <p className="font-mono text-[11px] text-[#a2a2a0]">{formattedDeleted}</p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => handleRestore(m.id, m.name)}
                          className="flex h-8 items-center rounded-md border border-white/[0.12] bg-white/[0.04] px-3 text-[12px] font-semibold text-white transition hover:bg-white/[0.08]"
                        >
                          Restore
                        </button>
                        <button
                          type="button"
                          onClick={() => setPermDeletingModel(m)}
                          className="flex h-8 items-center rounded-md px-3 text-[12px] font-medium text-[#ff6b7d] transition hover:bg-white/[0.04]"
                        >
                          Delete permanently
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        )}
      </div>

      {/* Form Modal (Create or Edit) */}
      <PlaybookFormModal
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        model={editingModel}
      />

      {/* Detail Modal */}
      <PlaybookDetailModal
        open={!!viewingModel}
        onOpenChange={(open) => !open && setViewingModel(null)}
        model={viewingModel}
        onEdit={(m) => {
          setViewingModel(null);
          handleOpenEdit(m);
        }}
      />

      {/* Confirm Soft Delete */}
      <ConfirmDelete
        open={!!deletingModel}
        onOpenChange={(open) => !open && setDeletingModel(null)}
        title={`Delete "${deletingModel?.name}"?`}
        description="This will move the playbook to Recently Deleted. Linked trades will keep their references."
        onConfirm={handleConfirmDelete}
      />

      {/* Confirm Permanent Delete */}
      <ConfirmDelete
        open={!!permDeletingModel}
        onOpenChange={(open) => !open && setPermDeletingModel(null)}
        title={`Permanently delete "${permDeletingModel?.name}"?`}
        description="This cannot be undone. This playbook will be completely removed."
        onConfirm={handlePermanentDelete}
      />
    </AppShell>
  );
}
