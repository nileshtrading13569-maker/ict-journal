import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Calendar as CalendarIcon,
  Check,
  ChevronLeft,
  ChevronRight,
  Columns3,
  Ellipsis,
  Search,
  SlidersHorizontal,
} from "lucide-react";
import { useDeskStore } from "@/lib/ict-store";
import { fmtCurrency, instrumentOf, tradeDollarPnl } from "@/lib/ict-calc";
import { paginateJournalRows } from "@/lib/journal-pagination";
import { cn, formatR } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Trade } from "@/lib/ict-types";

interface AllViewProps {
  trades: Trade[];
  selectedTradeId: string | null;
  onSelectTrade: (trade: Trade | null) => void;
  onEditTrade: (trade: Trade) => void;
}

export function AllView({
  trades,
  selectedTradeId,
  onSelectTrade,
}: AllViewProps) {
  const data = useDeskStore();
  const models = useDeskStore((s) => s.models);

  const [query, setQuery] = useState("");
  const [filterSide, setFilterSide] = useState<"all" | "long" | "short">("all");
  const [filterStatus, setFilterStatus] = useState<"all" | "open" | "win" | "loss" | "be">("all");
  const [filterReviewed, setFilterReviewed] = useState<"all" | "reviewed" | "unreviewed">("all");
  const [sortDirection, setSortDirection] = useState<"desc" | "asc">("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  // Filtered & sorted trades
  const filtered = useMemo(() => {
    return trades
      .filter((t) => {
        // Query search
        if (query.trim()) {
          const q = query.toLowerCase();
          const matchSymbol = t.market.toLowerCase().includes(q);
          const matchPlaybook = t.modelName.toLowerCase().includes(q);
          const matchNotes = (t.notes || "").toLowerCase().includes(q);
          const matchTags = (t.tags || []).some((tag) => tag.toLowerCase().includes(q));
          if (!matchSymbol && !matchPlaybook && !matchNotes && !matchTags) return false;
        }

        // Side filter
        if (filterSide !== "all" && t.side !== filterSide) return false;

        // Status filter
        if (filterStatus !== "all" && t.result !== filterStatus) return false;

        // Reviewed filter
        if (filterReviewed === "reviewed" && !t.reviewed) return false;
        if (filterReviewed === "unreviewed" && t.reviewed) return false;

        return true;
      })
      .sort((a, b) => {
        const timeA = `${a.date}T${a.time || "00:00"}`;
        const timeB = `${b.date}T${b.time || "00:00"}`;
        return sortDirection === "desc"
          ? timeB.localeCompare(timeA)
          : timeA.localeCompare(timeB);
      });
  }, [trades, query, filterSide, filterStatus, filterReviewed, sortDirection]);

  // Pagination
  const pagination = paginateJournalRows(filtered, currentPage, pageSize);
  const { page, totalPages, startIndex, rows: paginated } = pagination;

  // Summary stats across closed trades
  const totalClosed = trades.filter((t) => t.result !== "open");
  const totalNetPnL = totalClosed.reduce((sum, t) => {
    const pnl = tradeDollarPnl(t, instrumentOf(data, t.market));
    return sum + (pnl.net ?? 0);
  }, 0);

  const getModelCode = (trade: Trade) => {
    const m = models.find((mod) => mod.id === trade.modelId || mod.name === trade.modelName);
    if (m?.code) return m.code;
    const firstLetter = (trade.modelName || "A").trim().charAt(0).toUpperCase();
    return firstLetter || "A";
  };

  const formatOpenTime = (trade: Trade) => {
    if (!trade.date) return "—";
    const d = new Date(trade.date);
    const month = d.toLocaleDateString("en-US", { month: "short" });
    const day = d.getDate();
    return `${month} ${day}, ${trade.time || "00:00"}`;
  };

  return (
    <div className="space-y-4">
      {/* Journal toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        {/* Search */}
        <div className="flex h-10 w-[300px] items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-white">
          <Search className="size-3.5 text-[#6f6f6d]" />
          <input
            type="text"
            placeholder="Search symbol, playbook, tag, note"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full bg-transparent text-[13px] placeholder-[#6f6f6d] outline-none"
          />
        </div>

        {/* Date range display */}
        <div className="flex h-10 items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-[#d6d6d4]">
          <CalendarIcon className="size-3.5 text-[#a2a2a0]" />
          <span>Oct 1 – Oct 29, 2026</span>
        </div>

        {/* Filters dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              className={cn(
                "flex h-10 items-center gap-2 rounded-md border border-white/[0.09] px-3 text-[13px] font-medium text-[#d6d6d4] transition-colors hover:bg-white/[0.06]",
                (filterSide !== "all" || filterStatus !== "all" || filterReviewed !== "all") &&
                  "border-[#e50914]/50 bg-[#e50914]/10 text-white",
                filterSide === "all" && filterStatus === "all" && filterReviewed === "all" && "bg-white/[0.03]",
              )}
            >
              <SlidersHorizontal className="size-3.5" />
              <span>
                Filters
                {filterSide !== "all" || filterStatus !== "all" || filterReviewed !== "all" ? " (Active)" : ""}
              </span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 border-white/[0.1] bg-[#121212] text-white">
            <DropdownMenuLabel className="text-xs text-[#a2a2a0] uppercase">Side</DropdownMenuLabel>
            <DropdownMenuCheckboxItem checked={filterSide === "all"} onCheckedChange={() => setFilterSide("all")}>
              All sides
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterSide === "long"} onCheckedChange={() => setFilterSide("long")}>
              Long only
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterSide === "short"} onCheckedChange={() => setFilterSide("short")}>
              Short only
            </DropdownMenuCheckboxItem>

            <DropdownMenuSeparator className="bg-white/[0.08]" />
            <DropdownMenuLabel className="text-xs text-[#a2a2a0] uppercase">Status</DropdownMenuLabel>
            <DropdownMenuCheckboxItem checked={filterStatus === "all"} onCheckedChange={() => setFilterStatus("all")}>
              All statuses
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterStatus === "win"} onCheckedChange={() => setFilterStatus("win")}>
              Wins
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterStatus === "loss"} onCheckedChange={() => setFilterStatus("loss")}>
              Losses
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterStatus === "be"} onCheckedChange={() => setFilterStatus("be")}>
              Break-even
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterStatus === "open"} onCheckedChange={() => setFilterStatus("open")}>
              Open positions
            </DropdownMenuCheckboxItem>

            <DropdownMenuSeparator className="bg-white/[0.08]" />
            <DropdownMenuLabel className="text-xs text-[#a2a2a0] uppercase">Review</DropdownMenuLabel>
            <DropdownMenuCheckboxItem checked={filterReviewed === "all"} onCheckedChange={() => setFilterReviewed("all")}>
              All
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterReviewed === "reviewed"} onCheckedChange={() => setFilterReviewed("reviewed")}>
              Reviewed only
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem checked={filterReviewed === "unreviewed"} onCheckedChange={() => setFilterReviewed("unreviewed")}>
              To review only
            </DropdownMenuCheckboxItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Columns & Actions */}
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            className="flex h-10 items-center gap-2 rounded-md border border-white/[0.09] bg-white/[0.03] px-3 text-[13px] font-medium text-[#d6d6d4] transition-colors hover:bg-white/[0.06]"
          >
            <Columns3 className="size-3.5" />
            <span>Columns</span>
          </button>
          <button
            type="button"
            aria-label="More options"
            className="flex size-10 items-center justify-center rounded-md border border-white/[0.09] bg-white/[0.03] text-[15px] text-[#d6d6d4] transition-colors hover:bg-white/[0.06]"
          >
            <Ellipsis className="size-4" />
          </button>
        </div>
      </div>

      {/* Trade journal table section */}
      <section className="relative overflow-hidden rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e50914]/60 to-transparent" />

        <div className="overflow-x-auto">
          <table className="w-full min-w-[960px] table-fixed text-[13px]">
            <colgroup>
              <col style={{ width: "128px" }} />
              <col style={{ width: "76px" }} />
              <col style={{ width: "58px" }} />
              <col style={{ width: "88px" }} />
              <col style={{ width: "56px" }} />
              <col style={{ width: "84px" }} />
              <col style={{ width: "84px" }} />
              <col style={{ width: "96px" }} />
              <col style={{ width: "66px" }} />
              <col />
              <col style={{ width: "120px" }} />
              <col style={{ width: "70px" }} />
            </colgroup>
            <thead>
              <tr className="h-9 border-b border-white/[0.07] text-left text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase">
                <th className="px-3 font-semibold">
                  <button
                    type="button"
                    onClick={() => setSortDirection((d) => (d === "desc" ? "asc" : "desc"))}
                    className="inline-flex items-center gap-1 text-white hover:text-[#e50914]"
                  >
                    Open (ET)
                    {sortDirection === "desc" ? (
                      <ArrowDown className="size-3 text-[#e50914]" />
                    ) : (
                      <ArrowUp className="size-3 text-[#e50914]" />
                    )}
                  </button>
                </th>
                <th className="px-3 font-semibold">Symbol</th>
                <th className="px-3 font-semibold">Side</th>
                <th className="px-3 font-semibold">Status</th>
                <th className="px-3 text-right font-semibold">Lots</th>
                <th className="px-3 text-right font-semibold">Entry</th>
                <th className="px-3 text-right font-semibold">Exit</th>
                <th className="px-3 text-right font-semibold">Net P&amp;L</th>
                <th className="px-3 text-right font-semibold">R</th>
                <th className="px-3 font-semibold">Playbook</th>
                <th className="px-3 font-semibold">Tags</th>
                <th className="px-3 text-center font-semibold">Reviewed</th>
              </tr>
            </thead>
            <tbody className="[&>tr]:h-10 [&>tr]:border-b [&>tr]:border-white/[0.05]">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={12} className="py-12 text-center text-sm text-[#a2a2a0]">
                    {trades.length === 0 ? "No trades recorded yet. Click 'Log trade' to add one." : "No trades match these filters."}
                  </td>
                </tr>
              ) : (
                paginated.map((trade) => {
                  const inst = instrumentOf(data, trade.market);
                  const pnl = tradeDollarPnl(trade, inst);
                  const isSelected = trade.id === selectedTradeId;
                  const code = getModelCode(trade);
                  const tagLabel = trade.tags?.[0] || trade.setupTags?.[0] || trade.killZone || "";
                  const hasWarningTag =
                    (trade.mistakeTags && trade.mistakeTags.length > 0) ||
                    (trade.tags || []).some((t) => t.toLowerCase().includes("outside") || t.toLowerCase().includes("early") || t.toLowerCase().includes("late"));

                  return (
                    <tr
                      key={trade.id}
                      onClick={() => onSelectTrade(isSelected ? null : trade)}
                      className={cn(
                        "cursor-pointer transition-colors hover:bg-white/[0.04]",
                        isSelected && "bg-white/[0.05] shadow-[inset_2px_0_0_#e50914]",
                      )}
                    >
                      {/* Open (ET) */}
                      <td className="font-mono px-3 text-[12px] text-[#d6d6d4]">
                        {formatOpenTime(trade)}
                      </td>

                      {/* Symbol */}
                      <td className="px-3 font-semibold text-white">{trade.market}</td>

                      {/* Side */}
                      <td className="px-3 capitalize text-[#d6d6d4]">{trade.side}</td>

                      {/* Status */}
                      <td className="px-3">
                        <span
                          className={cn(
                            "rounded-sm px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.08em] uppercase",
                            trade.result === "win"
                              ? "border border-[#3ddc84]/30 bg-[#3ddc84]/10 text-[#3ddc84]"
                              : trade.result === "loss"
                                ? "border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 text-[#ff6b7d]"
                                : trade.result === "be"
                                  ? "whitespace-nowrap border border-white/[0.14] bg-white/[0.05] text-[#d6d6d4]"
                                  : "border border-[#f5b942]/30 bg-[#f5b942]/10 text-[#f5b942]",
                          )}
                        >
                          {trade.result === "win"
                            ? "Win"
                            : trade.result === "loss"
                              ? "Loss"
                              : trade.result === "be"
                                ? "Break-even"
                                : "Open"}
                        </span>
                      </td>

                      {/* Lots */}
                      <td className="font-mono px-3 text-right text-white">
                        {trade.lots != null ? trade.lots.toFixed(2) : "—"}
                      </td>

                      {/* Entry */}
                      <td className="font-mono px-3 text-right text-white">
                        {trade.entry != null ? trade.entry.toFixed(inst?.digits ?? 2) : "—"}
                      </td>

                      {/* Exit */}
                      <td className="font-mono px-3 text-right text-white">
                        {trade.exitPrice != null ? trade.exitPrice.toFixed(inst?.digits ?? 2) : "—"}
                      </td>

                      {/* Net P&L */}
                      <td
                        className={cn(
                          "font-mono px-3 text-right font-medium",
                          pnl.net == null
                            ? "text-[#6f6f6d]"
                            : pnl.net >= 0
                              ? "text-[#3ddc84]"
                              : "text-[#ff6b7d]",
                        )}
                      >
                        {fmtCurrency(pnl.net)}
                      </td>

                      {/* R */}
                      <td
                        className={cn(
                          "font-mono px-3 text-right",
                          trade.rMultiple == null
                            ? "text-[#6f6f6d]"
                            : trade.rMultiple >= 0
                              ? "text-[#3ddc84]"
                              : "text-[#ff6b7d]",
                        )}
                      >
                        {trade.rMultiple != null ? formatR(trade.rMultiple) : "—"}
                      </td>

                      {/* Playbook */}
                      <td className="truncate px-3 text-white">
                        <span className="font-mono mr-1.5 inline-block text-[11px] text-[#a2a2a0]">
                          {code}
                        </span>
                        <span>{trade.modelName || "Continuation"}</span>
                      </td>

                      {/* Tags */}
                      <td className="truncate px-3 text-[12px]">
                        <span className={cn(hasWarningTag ? "text-[#f5b942]" : "text-[#a2a2a0]")}>
                          {tagLabel || "—"}
                        </span>
                      </td>

                      {/* Reviewed */}
                      <td className="px-3 text-center">
                        {trade.reviewed ? (
                          <Check className="mx-auto size-3.5 text-[#3ddc84]" />
                        ) : (
                          <span className="text-[#6f6f6d]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table footer with summary */}
        <div className="flex h-10 items-center justify-between border-t border-white/[0.07] px-3 text-[12px] text-[#a2a2a0]">
          <div>
            <span className="font-mono text-[#d6d6d4]">{trades.length}</span> trades ·{" "}
            <span className="font-mono text-[#d6d6d4]">{totalClosed.length}</span> closed · Net P&amp;L{" "}
            <span className={cn("font-mono font-medium", totalNetPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]")}>
              {fmtCurrency(totalNetPnL)}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="font-mono">
              {filtered.length === 0 ? "0–0 of 0" : `${startIndex + 1}–${Math.min(startIndex + pageSize, filtered.length)} of ${filtered.length}`}
            </span>
            <div className="flex gap-1 text-[14px]">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                aria-label="Previous page"
                className="rounded p-1 text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white disabled:opacity-30"
              >
                <ChevronLeft className="size-4" />
              </button>
              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                aria-label="Next page"
                className="rounded p-1 text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white disabled:opacity-30"
              >
                <ChevronRight className="size-4" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
