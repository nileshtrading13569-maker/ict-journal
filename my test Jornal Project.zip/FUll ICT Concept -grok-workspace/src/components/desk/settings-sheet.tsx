import { useEffect, useState } from "react";
import { toast } from "sonner";
import { deskSnapshot, useDeskStore } from "@/lib/ict-store";
import { authEnabled } from "@/lib/auth/client";
import { isDeskData, saveDeskState } from "@/lib/desk-sync";
import { createResetState } from "@/lib/ict-defaults";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { ConfirmDelete } from "./confirm-delete";
import { Field } from "./fields";
import { TRADING_TZ } from "@/lib/ict-time";

const ACCENT_COLORS = [
  { id: "cinema", name: "Cinema red", value: "#e50914", foreground: "#ffffff" },
  { id: "scarlet", name: "Scarlet", value: "#ff2d3f", foreground: "#ffffff" },
  { id: "wine", name: "Wine", value: "#9f1239", foreground: "#ffffff" },
  { id: "ember", name: "Ember", value: "#f5b942", foreground: "#111111" },
  { id: "ice", name: "Ice", value: "#7dd3fc", foreground: "#082f49" },
  { id: "violet", name: "Violet", value: "#c4b5fd", foreground: "#2e1065" },
  { id: "sage", name: "Sage", value: "#d4ded0", foreground: "#111111" },
] as const;

type AccentColor = (typeof ACCENT_COLORS)[number]["id"];
const DEFAULT_ACCENT: AccentColor = "cinema";
// Bumped with the cinematic palette so older saved ids (wine/sage/…) do not
// repaint the new UI. Previous keys are intentionally left unread.
const ACCENT_STORAGE_KEY = "first-payout-accent-color-v2";

function applyAccentColor(colorId: AccentColor) {
  const color = ACCENT_COLORS.find((option) => option.id === colorId);
  if (!color) return;
  const root = document.documentElement.style;
  root.setProperty("--color-accent", color.value);
  root.setProperty("--color-accent-foreground", color.foreground);
  root.setProperty("--color-primary", color.value);
  root.setProperty("--color-primary-foreground", color.foreground);
  root.setProperty("--color-ring", color.value);
}

export function SettingsSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const data = useDeskStore();
  const patchAccount = useDeskStore((s) => s.patchAccount);
  const rebuildProtocolDates = useDeskStore((s) => s.rebuildProtocolDates);
  const resetAll = useDeskStore((s) => s.resetAll);
  const replaceAll = useDeskStore((s) => s.replaceAll);
  const [resetOpen, setResetOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);
  const [accentColor, setAccentColor] = useState<AccentColor>(DEFAULT_ACCENT);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(ACCENT_STORAGE_KEY);
      const color = ACCENT_COLORS.find((option) => option.id === saved)?.id ?? DEFAULT_ACCENT;
      setAccentColor(color);
      applyAccentColor(color);
    } catch (error) {
      console.error("[settings] failed to load accent color:", error);
      applyAccentColor(DEFAULT_ACCENT);
    }
  }, []);

  const handleAccentColorChange = (color: AccentColor) => {
    setAccentColor(color);
    applyAccentColor(color);
    try {
      window.localStorage.setItem(ACCENT_STORAGE_KEY, color);
    } catch (error) {
      console.error("[settings] failed to save accent color:", error);
      toast.error("Color changed for this session but could not be saved.");
    }
  };

  const handleReset = async () => {
    setIsResetting(true);
    try {
      const resetState = createResetState();
      if (authEnabled) {
        await saveDeskState({ data: resetState });
      }
      resetAll(resetState);
      setResetOpen(false);
      toast.success("All desk data reset");
    } catch (error) {
      console.error("[settings] failed to reset desk data:", error);
      toast.error("Could not reset desk data. Your saved data was not changed.");
    } finally {
      setIsResetting(false);
    }
  };

  const downloadBackup = () => {
    const blob = new Blob([JSON.stringify(deskSnapshot(), null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `first-payout-backup-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success("Backup downloaded");
  };

  const restoreBackup = async (file: File) => {
    try {
      if (file.size > 1_000_000) {
        throw new Error("Backup exceeds the 1 MB limit.");
      }
      const parsed: unknown = JSON.parse(await file.text());
      if (!isDeskData(parsed)) {
        throw new Error("This file is not a valid First Payout backup.");
      }
      if (!window.confirm(`Restore ${parsed.trades.length} trades and replace the current desk data?`)) {
        return;
      }
      if (authEnabled) await saveDeskState({ data: parsed });
      replaceAll(parsed);
      toast.success("Desk backup restored");
    } catch (error) {
      console.error("[settings] failed to restore desk backup:", error);
      toast.error(error instanceof Error ? error.message : "Could not restore the backup.");
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Account rules</SheetTitle>
          <SheetDescription>
            Funded-account constraints plus risk. ICT timing always uses {TRADING_TZ} — not the browser clock.
          </SheetDescription>
        </SheetHeader>
        <div className="flex flex-col gap-4 p-5">
          <section className="rounded-lg border border-white/[0.08] bg-white/[0.02] p-4">
            <div className="mb-3">
              <h3 className="text-[10px] font-semibold tracking-[0.16em] text-accent uppercase">Accent color</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Red is the desk default. Everything else is a deviation.
              </p>
            </div>
            <div aria-label="Accent color" className="flex flex-wrap gap-3" role="group">
              {ACCENT_COLORS.map((color) => (
                <button
                  key={color.id}
                  type="button"
                  aria-label={`${color.name} accent`}
                  aria-pressed={accentColor === color.id}
                  title={color.name}
                  onClick={() => handleAccentColorChange(color.id)}
                  className={`size-8 rounded-full border-2 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
                    accentColor === color.id
                      ? "border-foreground scale-110"
                      : "border-white/20 hover:scale-105"
                  }`}
                  style={{ backgroundColor: color.value }}
                />
              ))}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Selected: {ACCENT_COLORS.find((color) => color.id === accentColor)?.name}
            </p>
          </section>
          <Field label="Account name">
            <Input value={data.accountName} onChange={(e) => patchAccount({ accountName: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Starting balance">
              <Input
                type="number"
                value={data.rules.startingBalance}
                onChange={(e) => patchAccount({ startingBalance: Number(e.target.value) })}
              />
            </Field>
            <Field label="Payout threshold %">
              <Input
                type="number"
                step="0.5"
                value={data.rules.payoutThresholdPct}
                onChange={(e) => patchAccount({ payoutThresholdPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Profit target %">
              <Input
                type="number"
                step="0.5"
                value={data.rules.profitTargetPct}
                onChange={(e) => patchAccount({ profitTargetPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Profit split %">
              <Input
                type="number"
                value={data.rules.profitSplit}
                onChange={(e) => patchAccount({ profitSplit: Number(e.target.value) })}
              />
            </Field>
            <Field label="Max daily loss %">
              <Input
                type="number"
                step="0.1"
                value={data.rules.maxDailyLossPct}
                onChange={(e) => patchAccount({ maxDailyLossPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Max total DD %">
              <Input
                type="number"
                step="0.1"
                value={data.rules.maxTotalDrawdownPct}
                onChange={(e) => patchAccount({ maxTotalDrawdownPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Normal risk %">
              <Input
                type="number"
                step="0.05"
                value={data.rules.normalRiskPct}
                onChange={(e) => patchAccount({ normalRiskPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="High-conviction %">
              <Input
                type="number"
                step="0.05"
                value={data.rules.highConvictionRiskPct}
                onChange={(e) => patchAccount({ highConvictionRiskPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Max trades / day">
              <Input
                type="number"
                value={data.rules.maxTrades}
                onChange={(e) => patchAccount({ maxTrades: Number(e.target.value) })}
              />
            </Field>
            <Field label="Max consecutive losses">
              <Input
                type="number"
                value={data.rules.maxConsecutiveLosses}
                onChange={(e) => patchAccount({ maxConsecutiveLosses: Number(e.target.value) })}
              />
            </Field>
            <Field label="Window start (NY)">
              <Input
                type="time"
                value={data.rules.windowStart}
                onChange={(e) => patchAccount({ windowStart: e.target.value })}
              />
            </Field>
            <Field label="Window end (NY)">
              <Input
                type="time"
                value={data.rules.windowEnd}
                onChange={(e) => patchAccount({ windowEnd: e.target.value })}
              />
            </Field>
            <Field label="Min trading days">
              <Input
                type="number"
                value={data.rules.minTradingDays}
                onChange={(e) => patchAccount({ minTradingDays: Number(e.target.value) })}
              />
            </Field>
            <Field label="Consistency cap %">
              <Input
                type="number"
                value={data.rules.consistencyPct}
                onChange={(e) => patchAccount({ consistencyPct: Number(e.target.value) })}
              />
            </Field>
            <Field label="Max lots">
              <Input
                type="number"
                step="0.01"
                value={data.rules.maxPositionLots}
                onChange={(e) => patchAccount({ maxPositionLots: Number(e.target.value) })}
              />
            </Field>
            <Field label="Protocol start">
              <Input
                type="date"
                value={data.rules.protocolStartDate}
                onChange={(e) => rebuildProtocolDates(e.target.value)}
              />
            </Field>
          </div>
          <div className="flex items-center justify-between rounded-md bg-surface-2 px-3 py-2">
            <span className="text-sm">News restricted</span>
            <Switch
              checked={data.rules.newsRestricted}
              onCheckedChange={(v) => patchAccount({ newsRestricted: v })}
            />
          </div>
          <div className="flex items-center justify-between rounded-md bg-surface-2 px-3 py-2">
            <span className="text-sm">Weekend restricted</span>
            <Switch
              checked={data.rules.weekendRestricted}
              onCheckedChange={(v) => patchAccount({ weekendRestricted: v })}
            />
          </div>
          <Field label="Scaling note">
            <Input
              value={data.rules.scalingNote}
              onChange={(e) => patchAccount({ scalingNote: e.target.value })}
            />
          </Field>
          <Field label="Mantra">
            <Textarea value={data.mantra} onChange={(e) => patchAccount({ mantra: e.target.value })} />
          </Field>

          <div className="flex flex-wrap gap-2 pt-2">
            <Button
              onClick={() => {
                try {
                  patchAccount({
                    accountName: data.accountName,
                    phaseId: data.phaseId,
                    mantra: data.mantra,
                    ...data.rules,
                  });
                  toast.success("Account settings saved");
                  onOpenChange(false);
                } catch (error) {
                  console.error("[settings] failed to save account settings:", error);
                  toast.error("Could not save account settings");
                }
              }}
            >
              Save settings
            </Button>
            <Button variant="outline" onClick={downloadBackup}>Download backup</Button>
            <Button variant="outline" asChild>
              <label className="cursor-pointer">
                Restore backup
                <input
                  type="file"
                  accept="application/json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void restoreBackup(file);
                    e.currentTarget.value = "";
                  }}
                />
              </label>
            </Button>
            <Button variant="destructive" onClick={() => setResetOpen(true)}>
              Reset All Data
            </Button>
          </div>
        </div>
      </SheetContent>
      <ConfirmDelete
        open={resetOpen}
        onOpenChange={setResetOpen}
        title="Reset all desk data?"
        description="This permanently clears your trades, plans, notes, settings, and checklist progress. Your standard checklist will return unchecked. This cannot be undone."
        confirmLabel="Reset All Data"
        isPending={isResetting}
        pendingLabel="Resetting…"
        onConfirm={() => void handleReset()}
      />
    </Sheet>
  );
}
