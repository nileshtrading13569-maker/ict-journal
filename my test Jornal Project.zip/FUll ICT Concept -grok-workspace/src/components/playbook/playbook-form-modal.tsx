import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Trash2, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useDeskStore } from "@/lib/ict-store";
import { syncDeskToServer } from "@/lib/desk-sync";
import { uid } from "@/lib/utils";
import type { SetupModel } from "@/lib/ict-types";

interface PlaybookFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  model: SetupModel | null;
  onSaved?: (model: SetupModel) => void;
}

export function PlaybookFormModal({ open, onOpenChange, model, onSaved }: PlaybookFormModalProps) {
  const models = useDeskStore((s) => s.models);
  const upsertModel = useDeskStore((s) => s.upsertModel);

  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [market, setMarket] = useState("XAUUSD");
  const [timeframe, setTimeframe] = useState("1H → 5m");
  const [htfNarrative, setHtfNarrative] = useState("");
  const [liquidityCondition, setLiquidityCondition] = useState("");
  const [pdArray, setPdArray] = useState("");
  const [trigger, setTrigger] = useState("");
  const [invalidation, setInvalidation] = useState("");
  const [target, setTarget] = useState("");
  const [requiredTiming, setRequiredTiming] = useState("");
  const [validWhen, setValidWhen] = useState<string[]>([]);
  const [invalidWhen, setInvalidWhen] = useState<string[]>([]);
  const [active, setActive] = useState(true);
  const [newValidRule, setNewValidRule] = useState("");
  const [newInvalidRule, setNewInvalidRule] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (model) {
      setCode(model.code || "");
      setName(model.name || "");
      setMarket(model.market || "XAUUSD");
      setTimeframe(model.timeframe || "1H → 5m");
      setHtfNarrative(model.htfNarrative || "");
      setLiquidityCondition(model.liquidityCondition || "");
      setPdArray(model.pdArray || "");
      setTrigger(model.trigger || "");
      setInvalidation(model.invalidation || "");
      setTarget(model.target || "");
      setRequiredTiming(model.requiredTiming || "");
      setValidWhen(model.validWhen ? [...model.validWhen] : []);
      setInvalidWhen(model.invalidWhen ? [...model.invalidWhen] : []);
      setActive(model.active !== false);
    } else {
      // Suggest next letter
      const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      const usedCodes = new Set(models.map((m) => m.code.toUpperCase()));
      let nextCode = "A";
      for (let i = 0; i < letters.length; i++) {
        if (!usedCodes.has(letters[i])) {
          nextCode = letters[i];
          break;
        }
      }

      setCode(nextCode);
      setName("");
      setMarket("XAUUSD");
      setTimeframe("1H → 5m");
      setHtfNarrative("");
      setLiquidityCondition("");
      setPdArray("");
      setTrigger("");
      setInvalidation("");
      setTarget("");
      setRequiredTiming("");
      setValidWhen(["HTF aligned", "Liquidity swept", "Kill zone timing"]);
      setInvalidWhen(["Mid-range", "Already delivered"]);
      setActive(true);
    }
  }, [open, model, models]);

  const addValidRule = () => {
    const val = newValidRule.trim();
    if (val && !validWhen.includes(val)) {
      setValidWhen([...validWhen, val]);
      setNewValidRule("");
    }
  };

  const removeValidRule = (index: number) => {
    setValidWhen(validWhen.filter((_, i) => i !== index));
  };

  const addInvalidRule = () => {
    const val = newInvalidRule.trim();
    if (val && !invalidWhen.includes(val)) {
      setInvalidWhen([...invalidWhen, val]);
      setNewInvalidRule("");
    }
  };

  const removeInvalidRule = (index: number) => {
    setInvalidWhen(invalidWhen.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    const trimmedName = name.trim();
    const trimmedCode = code.trim().toUpperCase();

    if (!trimmedName) {
      toast.error("Please enter a playbook name.");
      return;
    }
    if (!trimmedCode) {
      toast.error("Please enter a playbook code.");
      return;
    }

    // Check code duplication
    const duplicate = models.find(
      (m) => m.id !== model?.id && m.code.toUpperCase() === trimmedCode,
    );
    if (duplicate) {
      toast.error(`Code '${trimmedCode}' is already used by ${duplicate.name}.`);
      return;
    }

    const updatedModel: SetupModel = {
      id: model?.id ?? `model-${uid()}`,
      code: trimmedCode,
      name: trimmedName,
      market: market.trim() || "XAUUSD",
      timeframe: timeframe.trim() || "1H → 5m",
      htfNarrative: htfNarrative.trim(),
      liquidityCondition: liquidityCondition.trim(),
      pdArray: pdArray.trim(),
      trigger: trigger.trim(),
      invalidation: invalidation.trim(),
      target: target.trim(),
      requiredTiming: requiredTiming.trim(),
      validWhen: validWhen.map((s) => s.trim()).filter(Boolean),
      invalidWhen: invalidWhen.map((s) => s.trim()).filter(Boolean),
      active,
    };

    setSaving(true);
    try {
      upsertModel(updatedModel);
      await syncDeskToServer();
      toast.success(model ? "Playbook updated" : "Playbook created");
      onSaved?.(updatedModel);
      onOpenChange(false);
    } catch (err) {
      console.error("[playbook-form] save error:", err);
      toast.error("Saved locally. Could not sync with server.");
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby="playbook-form-desc"
        className="max-h-[90vh] w-[95vw] max-w-[680px] overflow-hidden rounded-xl border border-white/[0.1] bg-[#0e0e0e] p-0 text-[#f5f5f4] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.95)]"
      >
        <DialogTitle className="sr-only">
          {model ? "Edit playbook" : "Create playbook"}
        </DialogTitle>
        <DialogDescription id="playbook-form-desc" className="sr-only">
          Configure playbook rules, criteria, and timing.
        </DialogDescription>

        {/* Header */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-white/[0.07] px-6">
          <div className="flex items-baseline gap-3">
            <h2 className="font-display text-[26px] leading-none text-white">
              {model ? "Edit playbook" : "Create playbook"}
            </h2>
            <span className="font-mono text-[12px] text-[#a2a2a0]">
              {code ? `Code [${code}]` : ""}
            </span>
          </div>
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            aria-label="Close"
            className="flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-white"
          >
            <X className="size-4" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="max-h-[calc(90vh-140px)] min-h-0 flex-1 overflow-y-auto px-6 py-5">
          <div className="space-y-4">
            {/* Row 1: Code, Name, Market, Timeframe */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Code
                </label>
                <Input
                  type="text"
                  maxLength={4}
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="A"
                  className="font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[14px] font-semibold text-[#e50914]"
                />
              </div>
              <div className="sm:col-span-3">
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Playbook name
                </label>
                <Input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Sell-side raid reversal"
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] font-semibold text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Market
                </label>
                <Input
                  type="text"
                  value={market}
                  onChange={(e) => setMarket(e.target.value)}
                  placeholder="XAUUSD"
                  className="font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Timeframe
                </label>
                <Input
                  type="text"
                  value={timeframe}
                  onChange={(e) => setTimeframe(e.target.value)}
                  placeholder="1H → 5m"
                  className="font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
            </div>

            {/* HTF Narrative */}
            <div>
              <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                HTF narrative &amp; context
              </label>
              <Input
                type="text"
                value={htfNarrative}
                onChange={(e) => setHtfNarrative(e.target.value)}
                placeholder="Bearish weekly/daily. Price in premium of the dealing range."
                className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
              />
            </div>

            {/* Liquidity condition & PD Array */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Liquidity condition
                </label>
                <Input
                  type="text"
                  value={liquidityCondition}
                  onChange={(e) => setLiquidityCondition(e.target.value)}
                  placeholder="SSL / PDL / Asia low taken first."
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  PD Array
                </label>
                <Input
                  type="text"
                  value={pdArray}
                  onChange={(e) => setPdArray(e.target.value)}
                  placeholder="1H or 15m bearish FVG / OB in premium."
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
            </div>

            {/* Trigger & Invalidation */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Trigger
                </label>
                <Input
                  type="text"
                  value={trigger}
                  onChange={(e) => setTrigger(e.target.value)}
                  placeholder="MSS + displacement + 5m FVG."
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Invalidation
                </label>
                <Input
                  type="text"
                  value={invalidation}
                  onChange={(e) => setInvalidation(e.target.value)}
                  placeholder="Close back beyond the swept structural extreme."
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
            </div>

            {/* Target & Required Timing */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Target
                </label>
                <Input
                  type="text"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  placeholder="BSL / PDH / opposing external."
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                  Required timing / session
                </label>
                <Input
                  type="text"
                  value={requiredTiming}
                  onChange={(e) => setRequiredTiming(e.target.value)}
                  placeholder="NY AM kill zone (09:30–11:00 ET)"
                  className="h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
                />
              </div>
            </div>

            {/* Valid When Rules */}
            <div>
              <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                Valid When (Checklist rules)
              </label>
              <div className="space-y-1.5">
                {validWhen.map((rule, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="flex-1 rounded-md border border-white/[0.08] bg-[#151515] px-3 py-1.5 text-[12px] text-white">
                      {rule}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeValidRule(idx)}
                      className="text-[#a2a2a0] hover:text-[#ff6b7d]"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex items-center gap-2 pt-1">
                  <Input
                    type="text"
                    value={newValidRule}
                    onChange={(e) => setNewValidRule(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addValidRule())}
                    placeholder="Add a required condition..."
                    className="h-8 text-[12px]"
                  />
                  <Button type="button" size="sm" onClick={addValidRule} className="h-8 px-3 text-xs">
                    <Plus className="mr-1 size-3" /> Add
                  </Button>
                </div>
              </div>
            </div>

            {/* Invalid When Rules */}
            <div>
              <label className="mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase">
                Invalid When (Disqualifiers)
              </label>
              <div className="space-y-1.5">
                {invalidWhen.map((rule, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="flex-1 rounded-md border border-[#ff6b7d]/20 bg-[#ff6b7d]/5 px-3 py-1.5 text-[12px] text-[#ff6b7d]">
                      {rule}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeInvalidRule(idx)}
                      className="text-[#a2a2a0] hover:text-[#ff6b7d]"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                ))}
                <div className="flex items-center gap-2 pt-1">
                  <Input
                    type="text"
                    value={newInvalidRule}
                    onChange={(e) => setNewInvalidRule(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addInvalidRule())}
                    placeholder="Add a disqualifier..."
                    className="h-8 text-[12px]"
                  />
                  <Button type="button" size="sm" onClick={addInvalidRule} className="h-8 px-3 text-xs">
                    <Plus className="mr-1 size-3" /> Add
                  </Button>
                </div>
              </div>
            </div>

            {/* Active Toggle */}
            <div className="flex items-center gap-2.5 pt-2">
              <input
                type="checkbox"
                id="model-active-check"
                checked={active}
                onChange={(e) => setActive(e.target.checked)}
                className="size-4 rounded border-white/[0.2] bg-white/[0.04] text-[#e50914] focus:ring-[#e50914]"
              />
              <label htmlFor="model-active-check" className="cursor-pointer text-[13px] text-[#d6d6d4]">
                Active playbook (shows in quick dropdowns and active ledger)
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex h-16 shrink-0 items-center justify-end gap-2 border-t border-white/[0.07] px-6">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="h-10 border-white/[0.1] bg-white/[0.03] px-4 text-[13px] text-white hover:bg-white/[0.08]"
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="h-10 bg-[#e50914] px-4 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] hover:brightness-110"
          >
            {saving ? "Saving…" : model ? "Save changes" : "Create playbook"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
