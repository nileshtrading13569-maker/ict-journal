import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { closedTrades, fmtCurrency, instrumentOf, tradeDollarPnl } from "@/lib/ict-calc";
import { useDeskStore } from "@/lib/ict-store";
import { formatR } from "@/lib/utils";
import { Pencil, X } from "lucide-react";
import type { SetupModel } from "@/lib/ict-types";

interface PlaybookDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  model: SetupModel | null;
  onEdit: (model: SetupModel) => void;
}

export function PlaybookDetailModal({
  open,
  onOpenChange,
  model,
  onEdit,
}: PlaybookDetailModalProps) {
  const data = useDeskStore();
  const trades = useDeskStore((s) => s.trades);

  if (!model) return null;

  const sample = closedTrades(
    trades.filter((t) => t.modelId === model.id || t.modelName === model.name),
  );
  const wins = sample.filter((t) => t.result === "win").length;
  const wr = sample.length ? Math.round((wins / sample.length) * 100) : 0;
  const netPnL = sample.reduce((acc, t) => {
    const pnl = tradeDollarPnl(t, instrumentOf(data, t.market));
    return acc + (pnl.net ?? 0);
  }, 0);
  const sumR = sample.reduce((acc, t) => acc + (t.rMultiple ?? 0), 0);
  const avgR = sample.length ? Number((sumR / sample.length).toFixed(2)) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby="playbook-detail-desc"
        className="max-h-[90vh] w-[95vw] max-w-[700px] overflow-hidden rounded-xl border border-white/[0.1] bg-[#0e0e0e] p-0 text-[#f5f5f4] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.95)]"
      >
        <DialogTitle className="sr-only">{model.name}</DialogTitle>
        <DialogDescription id="playbook-detail-desc" className="sr-only">
          Playbook model specifications, rules, and research performance.
        </DialogDescription>

        {/* Header */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-white/[0.07] px-6">
          <div className="flex items-center gap-3">
            <span className="font-mono flex size-8 items-center justify-center rounded-md border border-[#e50914]/40 bg-[#e50914]/10 text-[13px] font-semibold text-[#e50914]">
              {model.code}
            </span>
            <div>
              <h2 className="font-display text-[22px] leading-none text-white">{model.name}</h2>
              <p className="font-mono mt-1 text-[11px] text-[#a2a2a0]">
                {model.market} · {model.timeframe}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                onOpenChange(false);
                onEdit(model);
              }}
              className="h-8 border-white/[0.1] bg-white/[0.03] text-xs text-white hover:bg-white/[0.08]"
            >
              <Pencil className="mr-1 size-3" /> Edit
            </Button>
            <button
              type="button"
              onClick={() => onOpenChange(false)}
              aria-label="Close"
              className="flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-white"
            >
              <X className="size-4" />
            </button>
          </div>
        </div>

        {/* Quick stats banner */}
        <div className="grid grid-cols-4 border-b border-white/[0.07] bg-white/[0.02] px-6 py-3 text-center">
          <div>
            <p className="text-[10px] uppercase text-[#a2a2a0]">Closed trades</p>
            <p className="font-mono mt-0.5 text-[16px] text-white">{sample.length}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase text-[#a2a2a0]">Win rate</p>
            <p className="font-mono mt-0.5 text-[16px] text-white">{wr}%</p>
          </div>
          <div>
            <p className="text-[10px] uppercase text-[#a2a2a0]">Net P&amp;L</p>
            <p className={`font-mono mt-0.5 text-[16px] ${netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`}>
              {fmtCurrency(netPnL)}
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase text-[#a2a2a0]">Avg R</p>
            <p className={`font-mono mt-0.5 text-[16px] ${avgR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`}>
              {formatR(avgR)}
            </p>
          </div>
        </div>

        {/* Scrollable details */}
        <div className="max-h-[calc(90vh-180px)] min-h-0 flex-1 space-y-4 overflow-y-auto px-6 py-5 text-[13px]">
          {/* Narrative & Condition */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">HTF narrative</p>
              <p className="mt-1 leading-relaxed text-white">{model.htfNarrative || "None specified"}</p>
            </div>
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">Liquidity condition</p>
              <p className="mt-1 leading-relaxed text-white">{model.liquidityCondition || "None specified"}</p>
            </div>
          </div>

          {/* PD Array & Trigger */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">PD array</p>
              <p className="mt-1 leading-relaxed text-white">{model.pdArray || "None specified"}</p>
            </div>
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">Trigger</p>
              <p className="mt-1 leading-relaxed text-white">{model.trigger || "None specified"}</p>
            </div>
          </div>

          {/* Target & Invalidation */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">Target</p>
              <p className="mt-1 leading-relaxed text-white">{model.target || "None specified"}</p>
            </div>
            <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
              <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">Invalidation</p>
              <p className="mt-1 leading-relaxed text-white">{model.invalidation || "None specified"}</p>
            </div>
          </div>

          {/* Required Timing */}
          <div className="rounded-md border border-white/[0.07] bg-[#151515] p-3">
            <p className="text-[11px] font-semibold text-[#a2a2a0] uppercase">Required timing</p>
            <p className="mt-1 leading-relaxed text-white">{model.requiredTiming || "Any session"}</p>
          </div>

          {/* Valid When Rules */}
          <div>
            <p className="mb-1.5 text-[11px] font-semibold text-[#a2a2a0] uppercase">Valid when (Rules)</p>
            <div className="flex flex-wrap gap-1.5">
              {model.validWhen?.length ? (
                model.validWhen.map((r, i) => (
                  <span
                    key={i}
                    className="rounded-md border border-[#3ddc84]/30 bg-[#3ddc84]/10 px-2.5 py-1 text-xs text-[#3ddc84]"
                  >
                    ✓ {r}
                  </span>
                ))
              ) : (
                <span className="text-xs text-[#6f6f6d]">No checklist rules</span>
              )}
            </div>
          </div>

          {/* Invalid When Rules */}
          <div>
            <p className="mb-1.5 text-[11px] font-semibold text-[#a2a2a0] uppercase">Invalid when (Disqualifiers)</p>
            <div className="flex flex-wrap gap-1.5">
              {model.invalidWhen?.length ? (
                model.invalidWhen.map((r, i) => (
                  <span
                    key={i}
                    className="rounded-md border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 px-2.5 py-1 text-xs text-[#ff6b7d]"
                  >
                    ✕ {r}
                  </span>
                ))
              ) : (
                <span className="text-xs text-[#6f6f6d]">No disqualifiers</span>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
