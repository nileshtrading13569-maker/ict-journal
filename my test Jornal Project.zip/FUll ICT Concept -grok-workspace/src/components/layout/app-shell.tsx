import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  CalendarRange,
  ChartLine,
  Cloud,
  CloudOff,
  CloudUpload,
  Compass,
  LayoutDashboard,
  ListChecks,
  MoreHorizontal,
  Plus,
  RotateCcw,
  Settings2,
  Shield,
  Sun,
  Users,
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useDeskStore } from "@/lib/ict-store";
import { UserButton } from "@/lib/auth/gates";
import { signOut } from "@/lib/auth/client";
import { toast } from "sonner";
import { useDeskSyncStatus } from "@/components/desk/desk-sync-context";
import { lockInfo, protocolDayNumber } from "@/lib/ict-stats";
import { cn, todayISO } from "@/lib/utils";
import { TradeWizard } from "@/components/desk/trade-wizard";
import { SettingsSheet } from "@/components/desk/settings-sheet";
import { RoomSheet } from "@/components/desk/room-sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const NAV = [
  { to: "/", label: "Today", icon: LayoutDashboard },
  { to: "/weekly", label: "Weekly", icon: CalendarRange },
  { to: "/daily", label: "Daily", icon: Sun },
  { to: "/playbook", label: "Playbook", icon: Compass },
  { to: "/journal", label: "Journal", icon: BookOpen },
  { to: "/replay", label: "Replay", icon: RotateCcw },
  { to: "/analytics", label: "Analytics", icon: ChartLine },
  { to: "/protocol", label: "Protocol", icon: ListChecks },
] as const;

const MOBILE = [
  { to: "/", label: "Today", icon: LayoutDashboard },
  { to: "/weekly", label: "Weekly", icon: CalendarRange },
  { to: "/journal", label: "Journal", icon: BookOpen },
  { to: "/analytics", label: "Edge", icon: ChartLine },
] as const;

const MOBILE_MORE = [
  { to: "/daily", label: "Daily map" },
  { to: "/playbook", label: "Playbook" },
  { to: "/replay", label: "Replay" },
  { to: "/protocol", label: "Protocol" },
] as const;

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const phaseId = useDeskStore((s) => s.phaseId);
  const phases = useDeskStore((s) => s.phases);
  const accountName = useDeskStore((s) => s.accountName);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [roomOpen, setRoomOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const syncStatus = useDeskSyncStatus();
  // Primitive selectors keep the shell from re-rendering on every desk edit.
  const locked = useDeskStore((s) => lockInfo(s, todayISO()).locked);
  const day = useDeskStore((s) => protocolDayNumber(s));
  const phase = phases.find((p) => p.id === phaseId);

  const syncLabel = {
    local: "Local only",
    loading: "Connecting",
    saved: "Cloud saved",
    saving: "Syncing",
    error: "Sync issue",
  }[syncStatus];
  const SyncIcon =
    syncStatus === "error" ? CloudOff : syncStatus === "saving" || syncStatus === "loading" ? CloudUpload : Cloud;

  const handleMobileSignOut = () => {
    void signOut().catch((error: unknown) => {
      console.error("[auth] sign-out failed:", error);
      toast.error(error instanceof Error ? error.message : "Could not sign out. Please try again.");
    });
  };

  return (
    <div className="flex min-h-dvh bg-background text-foreground">
      <aside
        id="primary-sidebar"
        aria-label="Primary navigation"
        className={cn(
          "sticky top-0 hidden h-dvh shrink-0 flex-col overflow-hidden border-r border-white/[0.08] bg-black/50 px-2.5 py-5 lg:flex",
          sidebarExpanded ? "w-56" : "w-[68px]",
        )}
      >
        <div className={cn("mb-7 flex items-center gap-2.5 px-1.5", !sidebarExpanded && "justify-center px-0")}>
          <button
            type="button"
            className="flex size-8 shrink-0 items-center justify-center rounded-sm bg-accent text-primary-foreground shadow-[0_8px_20px_-10px_rgba(229,9,20,0.9)] transition hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
            aria-label={sidebarExpanded ? "Collapse sidebar" : "Expand sidebar"}
            aria-controls="primary-sidebar"
            aria-expanded={sidebarExpanded}
            title={sidebarExpanded ? "Collapse sidebar" : "Expand sidebar"}
            onClick={() => setSidebarExpanded((expanded) => !expanded)}
          >
            <Shield className="size-4" />
          </button>
          {sidebarExpanded ? (
            <div className="min-w-0">
              <p className="truncate font-display text-lg leading-none tracking-wide text-foreground">
                First Payout
              </p>
              <p className="mt-1 whitespace-nowrap text-[9px] font-semibold tracking-[0.2em] text-accent uppercase">
                ICT desk terminal
              </p>
            </div>
          ) : null}
        </div>

        <nav className="flex flex-1 flex-col gap-0.5">
          {NAV.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                title={!sidebarExpanded ? item.label : undefined}
                aria-label={item.label}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "relative flex h-9 items-center gap-2.5 rounded-sm text-[12px] font-medium transition-colors duration-150",
                  sidebarExpanded ? "px-2.5" : "justify-center px-0",
                  active
                    ? "bg-white/[0.06] text-foreground before:absolute before:inset-y-1.5 before:left-0 before:w-0.5 before:rounded-full before:bg-accent"
                    : "text-muted-foreground hover:bg-white/[0.03] hover:text-foreground",
                )}
              >
                <item.icon
                  className={cn("size-4 shrink-0", active ? "text-accent" : "text-muted-foreground")}
                  aria-hidden="true"
                />
                {sidebarExpanded ? <span className="whitespace-nowrap">{item.label}</span> : null}
              </Link>
            );
          })}
        </nav>

        <div
          className={cn(
            "mt-auto w-full border-t border-white/[0.08] pt-3",
            sidebarExpanded ? "px-1" : "flex flex-col items-center px-0",
          )}
        >
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setRoomOpen(true)}
            className={cn(
              "mb-2 w-full justify-start gap-2 text-muted-foreground hover:bg-white/[0.05] hover:text-foreground",
              !sidebarExpanded && "justify-center px-0",
            )}
            aria-label="Open live room"
            title="Live room"
          >
            <Users className="size-3.5 shrink-0" aria-hidden="true" />
            {sidebarExpanded ? <span className="text-[11px] font-medium">Live room</span> : null}
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setSettingsOpen(true)}
            className={cn(
              "mb-3 w-full justify-start gap-2 rounded-sm border border-white/[0.08] text-muted-foreground transition hover:border-white/[0.2] hover:bg-white/[0.04] hover:text-foreground",
              !sidebarExpanded && "justify-center px-0",
            )}
            aria-label="Open settings"
            title="Settings"
          >
            <Settings2 className="size-3.5 shrink-0" aria-hidden="true" />
            {sidebarExpanded ? <span className="text-[11px] font-medium">Settings</span> : null}
          </Button>
          <div
            className={cn(
              "flex w-full items-center font-mono text-[10px] text-muted-foreground",
              sidebarExpanded ? "justify-between" : "justify-center",
            )}
          >
            {sidebarExpanded ? (
              <>
                <span>Day {day}</span>
                <span className="inline-flex items-center gap-1 text-up">
                  <span className="size-1 rounded-full bg-up animate-pulse" aria-hidden="true" /> Live NY
                </span>
              </>
            ) : (
              <span className="size-1.5 rounded-full bg-up animate-pulse" title={`Day ${day} · Live NY`} />
            )}
          </div>
          <div
            className={cn("mt-3 w-full border-t border-white/[0.08] pt-3", !sidebarExpanded && "flex justify-center")}
          >
            <UserButton collapsed={!sidebarExpanded} />
          </div>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-2.5 border-b border-white/[0.08] bg-background/85 px-4 py-2.5 backdrop-blur-xl md:px-8">
          <div className="min-w-0 flex-1">
            <p className="hidden truncate text-[10px] font-semibold tracking-[0.16em] text-muted-foreground uppercase sm:block">
              {accountName}
            </p>
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge variant={locked ? "down" : "up"} className="gap-1.5 whitespace-nowrap">
                <span
                  className={cn("size-1 rounded-full", locked ? "bg-down" : "bg-up animate-pulse")}
                  aria-hidden="true"
                />
                {locked ? "Platform closed" : "Session open"}
              </Badge>
              <Badge variant="default" className="whitespace-nowrap">
                Phase {phaseId} · {phase?.name}
              </Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Open live room"
            title="Live room"
            onClick={() => setRoomOpen(true)}
            className="rounded-sm border border-white/[0.08] hover:border-accent/40 hover:text-accent"
          >
            <Users className="size-4" aria-hidden="true" />
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Settings"
            title="Settings"
            onClick={() => setSettingsOpen(true)}
            className="rounded-sm border border-white/[0.08] hover:border-white/[0.2]"
          >
            <Settings2 className="size-4" aria-hidden="true" />
          </Button>
          <span
            role="status"
            title={syncLabel}
            className={cn(
              "inline-flex shrink-0 items-center gap-1.5 text-[10px] font-medium",
              syncStatus === "error" ? "text-down" : "text-muted-foreground",
            )}
          >
            <SyncIcon
              className={cn("size-3.5", (syncStatus === "saving" || syncStatus === "loading") && "animate-pulse")}
              aria-hidden="true"
            />
            <span className="hidden sm:inline">{syncLabel}</span>
          </span>
          <Button
            size="sm"
            onClick={() => setTradeOpen(true)}
            className="gap-1.5 transition-transform active:scale-95"
            aria-label="Quick trade"
          >
            <Plus className="size-4 shrink-0" aria-hidden="true" />
            <span className="text-xs font-semibold">Quick trade</span>
          </Button>
        </header>

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 md:px-8 md:pb-12">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-white/[0.08] bg-black/90 backdrop-blur-xl lg:hidden">
        {MOBILE.map((item) => {
          const active = pathname === item.to;
          return (
            <Link
              key={item.to}
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium tracking-wide uppercase transition-colors",
                active ? "text-accent" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {active ? (
                <span className="absolute inset-x-3 top-0 h-0.5 rounded-full bg-accent" aria-hidden="true" />
              ) : null}
              <item.icon className="size-4" aria-hidden="true" />
              {item.label}
            </Link>
          );
        })}
        <DropdownMenu>
          <DropdownMenuTrigger
            className={cn(
              "flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium tracking-wide uppercase",
              MOBILE_MORE.some((item) => item.to === pathname)
                ? "text-accent"
                : "text-muted-foreground",
            )}
          >
            <MoreHorizontal className="size-4" aria-hidden="true" />
            More
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="mb-2 border-white/[0.12] bg-popover">
            {MOBILE_MORE.map((item) => (
              <DropdownMenuItem key={item.to} onSelect={() => void navigate({ to: item.to })}>
                {item.label}
              </DropdownMenuItem>
            ))}
            <DropdownMenuItem onSelect={() => setRoomOpen(true)}>Live room</DropdownMenuItem>
            <DropdownMenuItem onSelect={() => setSettingsOpen(true)}>Settings</DropdownMenuItem>
            <DropdownMenuItem onSelect={handleMobileSignOut}>Sign out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </nav>

      <TradeWizard open={tradeOpen} onOpenChange={setTradeOpen} trade={null} />
      <SettingsSheet open={settingsOpen} onOpenChange={setSettingsOpen} />
      <RoomSheet open={roomOpen} onOpenChange={setRoomOpen} />
    </div>
  );
}
