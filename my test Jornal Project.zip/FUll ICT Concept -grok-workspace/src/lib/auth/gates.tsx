import { useState, useSyncExternalStore, type ReactNode } from "react";
import { Navigate } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { authEnabled, signOut } from "./client";
import { hasGateSessionMarker } from "./gate-session-marker";
import { useCurrentUser, useCurrentUserState } from "./use-current-user";

const subscribeToNothing = () => () => {};
const noGateSessionOnServer = () => false;

/**
 * Auth state components — plain wrappers around `useCurrentUserState()`.
 *
 * With auth on, visitors are signed out until they authenticate — in the sandbox
 * live preview too, which does real sign-in. The shared dev user appears only
 * when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
 * While the session is still resolving, gates that care about signed-out state
 * render nothing so there's no signed-out flash on hard reload.
 */

/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
export const SIGN_IN_PATH = "/login";

/** Render children only when a user is present (real session, or the disabled-auth dev user). */
export function SignedIn({ children }: { children: ReactNode }) {
  const { user } = useCurrentUserState();
  return user ? <>{children}</> : null;
}

/**
 * Render children only once we KNOW the visitor is signed out (`isPending` has
 * cleared and there is no user). Hidden while the session is still loading.
 */
export function SignedOut({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending || user) return null;
  return <>{children}</>;
}

/**
 * Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
 * `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
 * session loading, which feels like a second "Loading…" on /login.
 *
 * Guard routes by waiting out `isPending` first (see `use-current-user`), then
 * render this.
 */
export function RedirectToSignIn({ to = SIGN_IN_PATH }: { to?: string }) {
  return <Navigate to={to} />;
}

/**
 * Minimal signed-in identity chip + sign-out. Restyle freely (see the
 * `design-ui` skill). Sign-out is only shown when auth is enabled (the
 * disabled-auth dev user has nothing to sign out of) and the session is not
 * gate-materialized — behind the gate the next request signs the viewer
 * straight back in, so a sign-out control there is a broken loop.
 */
export function UserButton({ collapsed = false }: { collapsed?: boolean }) {
  const user = useCurrentUser();
  // Sign-out can take a moment (and can fail when deployed), so the control
  // shows it is working and cannot be fired twice.
  const [signingOut, setSigningOut] = useState(false);
  const gateSession = useSyncExternalStore(
    subscribeToNothing,
    hasGateSessionMarker,
    noGateSessionOnServer,
  );
  if (!user) return null;
  const label = user.displayName ?? user.primaryEmail ?? "Account";
  const canSignOut = authEnabled && !gateSession;
  const avatar = user.profileImageUrl ? (
    <img
      src={user.profileImageUrl}
      alt={collapsed ? label : ""}
      title={collapsed ? label : undefined}
      className="h-8 w-8 rounded-full object-cover"
    />
  ) : (
    <span
      role={collapsed ? "img" : undefined}
      aria-label={collapsed ? label : undefined}
      title={collapsed ? label : undefined}
      className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20"
    >
      {label.charAt(0).toUpperCase()}
    </span>
  );

  const signOutButton = canSignOut ? (
    <button
      type="button"
      disabled={signingOut}
      aria-label={signingOut ? "Signing out" : "Sign out"}
      title={signingOut ? "Signing out" : "Sign out"}
      onClick={() => {
        setSigningOut(true);
        // Success navigates away; on failure re-enable so it can be retried.
        void signOut().catch(() => setSigningOut(false));
      }}
      className={
        collapsed
          ? "grid size-8 place-items-center rounded-lg text-muted-foreground opacity-70 transition hover:bg-white/[0.06] hover:text-foreground disabled:cursor-wait"
          : "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline"
      }
    >
      {collapsed ? <LogOut aria-hidden="true" className="size-4" /> : signingOut ? "Signing out…" : "Sign out"}
    </button>
  ) : null;

  if (collapsed) {
    return (
      <div className="flex flex-col items-center gap-2">
        {avatar}
        {signOutButton}
      </div>
    );
  }

  return (
    <div className="flex min-w-0 items-center gap-2">
      {avatar}
      <span className="min-w-0 truncate text-sm font-medium" title={label}>{label}</span>
      {signOutButton}
    </div>
  );
}
