import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { k as Flame, o as TrendingUp, r as Wallet, x as Percent } from "../_libs/lucide-react.mjs";
import { D as SESSIONS, I as cn, K as weekStartISO, L as formatMoney, R as formatPct, U as todayISO, l as useDeskStore, z as formatR } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { A as conceptMatrix, E as avgWinR, F as errorBreakdown, G as profitFactor, H as maxDrawdownPct, I as expectancyR, J as ruleFollowRate, M as dayOfWeekTable, P as equityCurve, T as avgLossR, U as payoutProgress, V as maeMfeStats, X as sumR, Y as sumPnlPct, j as currentBalance, n as Badge, nt as worstStreak, q as remainingRToDanger, t as AppShell, tt as winRate, x as Panel } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
import { t as KpiCard } from "./kpi-card-CYolVXt8.mjs";
import { a as CartesianGrid, i as Area, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-CXCX0qZk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AnalyticsPage() {
	const data = useDeskStore();
	const [fromDate, setFromDate] = (0, import_react.useState)("");
	const [toDate, setToDate] = (0, import_react.useState)("");
	const [modelFilter, setModelFilter] = (0, import_react.useState)("all");
	const [sessionFilter, setSessionFilter] = (0, import_react.useState)("all");
	const filteredTrades = data.trades.filter((trade) => (!fromDate || trade.date >= fromDate) && (!toDate || trade.date <= toDate) && (modelFilter === "all" || trade.modelId === modelFilter) && (sessionFilter === "all" || trade.session === sessionFilter));
	const curve = equityCurve(filteredTrades);
	const pay = payoutProgress(data);
	const concepts = conceptMatrix(filteredTrades).slice(0, 18);
	const errors = errorBreakdown(filteredTrades);
	const days = dayOfWeekTable(filteredTrades);
	const mm = maeMfeStats(filteredTrades);
	const danger = remainingRToDanger(data);
	const totalR = sumR(filteredTrades);
	const wr = winRate(filteredTrades);
	const pf = profitFactor(filteredTrades);
	const currentWeek = weekStartISO(todayISO());
	const weekTrades = data.trades.filter((trade) => trade.date >= currentWeek);
	const ruleBreaks = Array.from({ length: 7 }, (_, weekday) => {
		const count = filteredTrades.filter((trade) => !trade.ruleFollowed && (/* @__PURE__ */ new Date(`${trade.date}T00:00:00Z`)).getUTCDay() === weekday).length;
		return {
			day: [
				"Sun",
				"Mon",
				"Tue",
				"Wed",
				"Thu",
				"Fri",
				"Sat"
			][weekday],
			count
		};
	});
	const closedTrades = filteredTrades.filter((trade) => trade.result !== "open");
	const missingRiskData = closedTrades.filter((trade) => trade.entry == null || trade.sl == null).length;
	const missingModel = filteredTrades.filter((trade) => !trade.modelId && !trade.modelName).length;
	const missingReview = closedTrades.filter((trade) => !trade.notes.trim() && !trade.primaryError).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "ICT edge analytics",
			title: "Which concept pays?",
			description: "Slice by narrative, liquidity, PD array, trigger, session, location — not by mood.",
			aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: [filteredTrades.length, " trades in sample"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-6",
			title: "Analytics filters",
			kicker: `${filteredTrades.length} matching trades`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-xs text-muted-foreground",
						children: ["From date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: fromDate,
							onChange: (event) => setFromDate(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-xs text-muted-foreground",
						children: ["To date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: toDate,
							onChange: (event) => setToDate(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-xs text-muted-foreground",
						children: ["Setup model", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground",
							value: modelFilter,
							onChange: (event) => setModelFilter(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All models"
							}), data.models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: model.id,
								children: model.name
							}, model.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-xs text-muted-foreground",
						children: ["Session", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground",
							value: sessionFilter,
							onChange: (event) => setSessionFilter(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All sessions"
							}), SESSIONS.map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: session,
								children: session
							}, session))]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 grid grid-cols-2 gap-3.5 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Equity",
					value: formatMoney(currentBalance(data)),
					hint: formatPct(sumPnlPct(filteredTrades)),
					icon: Wallet
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Total R",
					value: formatR(totalR),
					hint: `${filteredTrades.length} matching trades`,
					icon: Flame,
					variant: totalR > 0 ? "up" : totalR < 0 ? "down" : "default"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Win Rate",
					value: `${wr.toFixed(0)}%`,
					hint: `Exp: ${formatR(expectancyR(filteredTrades))}`,
					icon: Percent,
					variant: wr >= 50 ? "up" : "default"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Profit Factor",
					value: pf.toFixed(2),
					hint: `Max DD ${formatPct(-maxDrawdownPct(filteredTrades))}`,
					icon: TrendingUp,
					variant: pf >= 1.5 ? "up" : "default"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-6",
			title: "Equity Curve (in R)",
			kicker: `Payout path ${Math.max(0, Math.round(pay.pct))}%`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-72 w-full pt-2",
				children: curve.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
						data: curve,
						margin: {
							top: 12,
							right: 12,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
								id: "curveGlow",
								x1: "0",
								y1: "0",
								x2: "0",
								y2: "1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "5%",
									stopColor: "var(--color-accent)",
									stopOpacity: .28
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "95%",
									stopColor: "var(--color-accent)",
									stopOpacity: 0
								})]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "rgba(255, 255, 255, 0.05)",
								vertical: false,
								strokeDasharray: "3 3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "date",
								tick: {
									fill: "rgba(255, 255, 255, 0.4)",
									fontSize: 11
								},
								axisLine: { stroke: "rgba(255, 255, 255, 0.1)" },
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tick: {
									fill: "rgba(255, 255, 255, 0.4)",
									fontSize: 11
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "rgba(18, 20, 17, 0.95)",
								border: "1px solid rgba(255, 255, 255, 0.12)",
								borderRadius: 12,
								boxShadow: "0 8px 32px rgba(0, 0, 0, 0.5)",
								color: "var(--color-foreground)",
								backdropFilter: "blur(12px)"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
								type: "monotone",
								dataKey: "r",
								stroke: "var(--color-accent)",
								fill: "url(#curveGlow)",
								strokeWidth: 2.5
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center text-sm text-muted-foreground",
					children: "No closed trades logged yet. Log executions to generate your edge curve."
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 grid gap-5 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Risk of Ruin Model",
				kicker: "Distance to danger",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Daily R remaining"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-semibold text-foreground",
								children: [
									danger.dailyR.toFixed(1),
									"R (",
									danger.dailyLeftPct.toFixed(2),
									"%)"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Total Drawdown remaining"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-semibold text-foreground",
								children: [
									danger.totalR.toFixed(1),
									"R (",
									danger.totalLeftPct.toFixed(2),
									"%)"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Worst losing streak"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-semibold text-down",
								children: [worstStreak(filteredTrades), " consecutive"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Win / Loss Ratio"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-semibold text-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-up",
										children: formatR(avgWinR(filteredTrades))
									}),
									" / ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-down",
										children: formatR(avgLossR(filteredTrades))
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Rule Compliance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: ruleFollowRate(filteredTrades) >= 80 ? "up" : "warn",
								children: [ruleFollowRate(filteredTrades).toFixed(0), "% Followed"]
							})]
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "MAE / MFE Edge",
				kicker: `${mm.n} trades with excursion`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-2.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Average MAE (Drawdown during trade)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-semibold text-down",
								children: formatR(mm.avgMae)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Average MFE (Maximum favorable potential)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-semibold text-up",
								children: formatR(mm.avgMfe)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between rounded-lg border border-white/[0.04] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "MFE → Realized Conversion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-bold text-accent",
								children: [(mm.conversion * 100).toFixed(0), "%"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-xl border border-white/[0.06] bg-black/25 p-3 text-xs leading-relaxed text-muted-foreground",
							children: "💡 If MFE is 3R and you bank 1R, the entry model is sharp and trade management is where alpha is leaking."
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 grid gap-5 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					title: "Weekly scorecard",
					kicker: `Week of ${currentWeek}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
								label: "Trades",
								value: String(weekTrades.length)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
								label: "Net R",
								value: formatR(sumR(weekTrades))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
								label: "Win rate",
								value: `${winRate(weekTrades).toFixed(0)}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, {
								label: "Rule follow",
								value: `${ruleFollowRate(weekTrades).toFixed(0)}%`
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted-foreground",
						children: "Review the week in Weekly and record one lesson before planning the next session."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Rule-break heatmap",
					kicker: "Count by weekday · current filters",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-7 gap-1.5",
						children: ruleBreaks.map(({ day, count }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("flex aspect-square items-center justify-center rounded-lg border text-sm font-semibold", count ? "border-down/40 bg-down/15 text-down" : "border-white/[0.06] bg-white/[0.02] text-muted-foreground"),
								title: `${count} rule breaks`,
								children: count
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-[10px] text-muted-foreground",
								children: day
							})]
						}, day))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Journal data health",
					kicker: `${filteredTrades.length} matching trades`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthRow, {
								label: "Closed trades missing entry or stop",
								count: missingRiskData
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthRow, {
								label: "Trades without a setup model",
								count: missingModel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthRow, {
								label: "Closed trades without a written review",
								count: missingReview
							})
						]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-6",
			title: "ICT Concept Performance Matrix",
			kicker: "Empirical Edge",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[36rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] font-semibold tracking-wider text-muted-foreground uppercase border-b border-white/[0.08]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-3 px-3 font-medium",
								children: "Concept"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-3 px-3 font-medium",
								children: "Sample"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-3 px-3 font-medium",
								children: "Win %"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-3 px-3 font-medium",
								children: "Avg R (Exp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-3 px-3 font-medium text-right",
								children: "Net R"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-white/[0.04]",
						children: concepts.map((c) => {
							const wr = c.trades ? (c.wins / c.trades * 100).toFixed(0) : 0;
							const isPositive = c.r > 0;
							const isNegative = c.r < 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "transition-colors hover:bg-white/[0.03]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-3 font-medium text-foreground",
										children: c.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-3 font-mono text-muted-foreground tabular-nums",
										children: c.trades
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-3 font-mono tabular-nums",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: cn(Number(wr) >= 50 ? "text-up font-semibold" : "text-muted-foreground"),
											children: [wr, "%"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-3 font-mono tabular-nums",
										children: formatR(c.expectancy)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-3 font-mono font-bold text-right tabular-nums",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: isPositive ? "text-up" : isNegative ? "text-down" : "text-muted-foreground",
											children: formatR(c.r)
										})
									})
								]
							}, c.key);
						})
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 grid gap-5 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Primary Error Attribution",
				kicker: "Behavioral leaks",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: errors.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-xl border border-white/[0.05] bg-surface-2/40 px-3.5 py-2.5 text-sm transition-colors hover:bg-surface-2/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-foreground",
							children: e.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: [e.trades, " trades"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs font-bold text-down",
								children: formatR(e.r)
							})]
						})]
					}, e.key))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Session / Day Performance",
				kicker: "Time cycle edge",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-semibold text-muted-foreground uppercase border-b border-white/[0.08]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-2 font-medium",
									children: "Day"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-2 font-medium",
									children: "Bias"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-2 font-medium",
									children: "Liq"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-2 font-medium text-right",
									children: "R"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-white/[0.04]",
							children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "transition-colors hover:bg-white/[0.03]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 px-2 font-medium text-foreground",
										children: d.day
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 px-2 capitalize text-muted-foreground",
										children: d.bias
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 px-2 text-muted-foreground",
										children: d.liq
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2.5 px-2 font-mono font-bold text-right tabular-nums",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: d.r > 0 ? "text-up" : d.r < 0 ? "text-down" : "text-muted-foreground",
											children: formatR(d.r)
										})
									})
								]
							}, d.day))
						})]
					})
				})
			})]
		})
	] });
}
function Score({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-white/[0.06] bg-white/[0.02] p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-lg font-semibold",
			children: value
		})]
	});
}
function HealthRow({ label, count }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start justify-between gap-2 rounded-lg border border-white/[0.05] bg-white/[0.02] p-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: count ? "warn" : "up",
			children: count
		})]
	});
}
//#endregion
export { AnalyticsPage as component };
