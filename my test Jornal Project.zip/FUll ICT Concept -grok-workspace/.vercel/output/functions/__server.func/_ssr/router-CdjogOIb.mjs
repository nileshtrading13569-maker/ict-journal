import { o as __toESM } from "../_runtime.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, x as useRouter, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Slot, P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { F as literal, H as union, L as number, M as custom, N as discriminatedUnion, O as _enum, R as object, U as unknown, V as string } from "../_libs/@better-auth/core+[...].mjs";
import { i as signOut, t as authClient } from "./client-B40BzJxt.mjs";
import { i as getSql, t as authMiddleware } from "./middleware-B9Dz24Ph.mjs";
import { n as number$1 } from "../_libs/zod.mjs";
import { a as hasGateSessionMarker, n as auth } from "./server-C59QZTrp.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as TriangleAlert, w as LogOut } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-BYdnyVA4.js
var TRADING_TZ = "America/New_York";
function part(parts, type) {
	return parts.find((p) => p.type === type)?.value ?? "";
}
function nyParts(date = /* @__PURE__ */ new Date()) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone: TRADING_TZ,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		weekday: "short",
		hour12: false
	}).formatToParts(date);
	let hour = part(parts, "hour");
	if (hour === "24") hour = "00";
	return {
		year: part(parts, "year"),
		month: part(parts, "month"),
		day: part(parts, "day"),
		hour,
		minute: part(parts, "minute"),
		weekday: part(parts, "weekday")
	};
}
function todayISO$1(date = /* @__PURE__ */ new Date()) {
	const p = nyParts(date);
	return `${p.year}-${p.month}-${p.day}`;
}
function nowHHMM(date = /* @__PURE__ */ new Date()) {
	const p = nyParts(date);
	return `${p.hour}:${p.minute}`;
}
function weekdayShort(dateISO) {
	const [y, m, d] = dateISO.split("-").map(Number);
	return [
		"Sun",
		"Mon",
		"Tue",
		"Wed",
		"Thu",
		"Fri",
		"Sat"
	][new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
}
function weekStartISO(dateISO) {
	const [y, m, d] = dateISO.split("-").map(Number);
	const utc = Date.UTC(y, m - 1, d);
	const day = new Date(utc).getUTCDay();
	const diff = day === 0 ? -6 : 1 - day;
	const mon = new Date(utc);
	mon.setUTCDate(mon.getUTCDate() + diff);
	return mon.toISOString().slice(0, 10);
}
function addDaysISO(dateISO, days) {
	const [y, m, d] = dateISO.split("-").map(Number);
	return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}
function inWindow(start, end, now = nowHHMM()) {
	if (start <= end) return now >= start && now <= end;
	return now >= start || now <= end;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
}
function todayISO() {
	return todayISO$1();
}
function formatMoney(n) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		maximumFractionDigits: 0
	}).format(n);
}
function formatPct(n, digits = 2) {
	return `${n > 0 ? "+" : ""}${n.toFixed(digits)}%`;
}
function formatR(n, digits = 2) {
	return `${n > 0 ? "+" : ""}${n.toFixed(digits)}R`;
}
function parseNum(v) {
	if (v.trim() === "") return null;
	const n = Number(v);
	return Number.isFinite(n) ? n : null;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/use-current-user-DEy0BbzW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-all duration-[var(--motion-quick)] ease-[var(--ease-cinema)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-primary-foreground font-semibold shadow-[inset_0_1px_0_rgba(255,255,255,0.22),0_10px_24px_-12px_rgba(229,9,20,0.9)] hover:bg-[#f40d18]",
			secondary: "bg-surface-2 text-foreground/90 border border-white/[0.09] hover:bg-surface-3 hover:border-white/[0.18]",
			outline: "bg-transparent text-foreground/90 border border-white/[0.14] hover:bg-white/[0.06] hover:border-white/[0.3]",
			ghost: "text-muted-foreground hover:bg-white/[0.06] hover:text-foreground",
			destructive: "bg-down/12 text-down border border-down/35 hover:bg-down/20 focus-visible:ring-down/50",
			link: "text-accent underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-8.5 px-3 text-xs",
			lg: "h-12 px-6 text-base",
			icon: "size-10",
			"icon-sm": "size-8.5"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CdjogOIb.js
var LIQUIDITY_TYPES = [
	"BSL",
	"SSL",
	"EQH",
	"EQL",
	"PDH",
	"PDL",
	"PWH",
	"PWL",
	"Asia High",
	"Asia Low",
	"London High",
	"London Low",
	"Session High",
	"Session Low",
	"Internal",
	"External"
];
var PD_ARRAYS = [
	"Fair Value Gap",
	"Inverse Fair Value Gap",
	"Order Block",
	"Breaker Block",
	"Mitigation Block",
	"Rejection Block",
	"Balanced Price Range",
	"Volume Imbalance",
	"Liquidity Void",
	"Consequent Encroachment",
	"Previous Day FVG",
	"Previous Week FVG",
	"Session FVG",
	"HTF FVG"
];
var TIMEFRAMES = [
	"1W",
	"1D",
	"4H",
	"1H",
	"15m",
	"5m",
	"1m"
];
var TRIGGERS = [
	"Liquidity sweep",
	"MSS",
	"BOS",
	"CISD",
	"Displacement",
	"FVG creation",
	"FVG retracement",
	"Breaker confirmation",
	"OB confirmation",
	"OTE confluence",
	"SMT + MSS",
	"Session opening manipulation"
];
var SESSIONS = [
	"Asia",
	"London",
	"NY",
	"London–NY overlap"
];
var KILL_ZONES = [
	"London Kill Zone",
	"NY AM Kill Zone",
	"NY PM",
	"London Close",
	"Other"
];
var TIME_MODELS = [
	"Pre-London",
	"London open",
	"London expansion",
	"NY pre-market",
	"NY open",
	"NY AM continuation",
	"NY AM reversal",
	"NY PM",
	"End of day"
];
var DRAWS = [
	"PDH",
	"PDL",
	"PWH",
	"PWL",
	"EQH",
	"EQL",
	"FVG",
	"OB",
	"BSL",
	"SSL",
	"External",
	"Internal"
];
var DELIVERIES = [
	"Expand higher",
	"Expand lower",
	"Raid then reverse",
	"Retrace then continue",
	"Consolidate"
];
var AMD_PHASES = [
	"Accumulation",
	"Manipulation",
	"Distribution"
];
var EXIT_REASONS = [
	"TP",
	"SL",
	"Manual",
	"Time-based",
	"News",
	"Session end",
	"Narrative invalidated",
	"Partial",
	"Trailing stop"
];
var MANAGEMENT = [
	"No management",
	"BE",
	"Partial",
	"Trailed",
	"Scaled",
	"Discretionary"
];
var ERRORS = [
	"Bias wrong",
	"Narrative wrong",
	"Liquidity read wrong",
	"Location wrong",
	"Timing wrong",
	"Trigger wrong",
	"Entry too early",
	"Entry too late",
	"Stop placement wrong",
	"Target wrong",
	"Management wrong",
	"Psychology",
	"No actual error"
];
var MISS_REASONS = [
	"Hesitation",
	"Fear of loss",
	"Missed timing",
	"Too much analysis",
	"Already moved",
	"Distracted",
	"Outside rules",
	"Technical issue",
	"Unsure bias",
	"Other"
];
var MISS_OUTCOMES = [
	"Full TP",
	"Partial TP",
	"Stopped",
	"No follow-through"
];
var EMOTIONS = [
	{
		value: "calm",
		label: "Calm"
	},
	{
		value: "confidence",
		label: "Confidence"
	},
	{
		value: "hesitation",
		label: "Hesitation"
	},
	{
		value: "fomo",
		label: "FOMO"
	},
	{
		value: "revenge",
		label: "Revenge"
	},
	{
		value: "pressure",
		label: "Pressure"
	}
];
function emptyJudas() {
	return {
		present: "unclear",
		direction: "",
		aligned: false,
		after: ""
	};
}
function emptyOte() {
	return {
		used: "not-used",
		swingHigh: null,
		swingLow: null,
		retracement: null,
		inside: false,
		confluence: false
	};
}
function emptySmt() {
	return {
		present: "no",
		pair: "",
		sweptMarket: "",
		failedMarket: "",
		beforeTrigger: false
	};
}
function emptyCrt() {
	return {
		used: false,
		reference: "",
		high: null,
		low: null,
		raidSide: "",
		purge: false,
		reclaim: false,
		entryAfterReclaim: false,
		target: ""
	};
}
function emptyIntermarket() {
	return {
		dxy: "",
		yields: "",
		silver: "",
		indices: ""
	};
}
function emptyRange() {
	return {
		high: null,
		low: null,
		open: null,
		close: null,
		current: null
	};
}
var DEFAULT_PHASES = [
	{
		id: 1,
		name: "Survival",
		goal: "20–30 trades without breaking risk rules",
		description: "Protect capital. One model. Tiny size. The job is to still be in the game."
	},
	{
		id: 2,
		name: "Consistency",
		goal: "Positive expectancy + controlled drawdown",
		description: "Log the narrative, not just the fill. Rule-follow is the score."
	},
	{
		id: 3,
		name: "Payout protection",
		goal: "Once in profit, do not increase risk — often decrease",
		description: "The dangerous moment is overconfidence after a green week."
	},
	{
		id: 4,
		name: "Payout lock",
		goal: "Near the threshold, refuse the ‘one big trade’",
		description: "Small consistent gains + controlled losses. Lock the payout."
	}
];
var DEFAULT_MANTRA = "Was the read correct? Was the execution correct? Does this model have expectancy?";
var DEFAULT_INSTRUMENTS = [
	{
		id: "xau",
		symbol: "XAUUSD",
		tickSize: .01,
		tickValuePerLot: 1,
		digits: 2
	},
	{
		id: "eur",
		symbol: "EURUSD",
		tickSize: 1e-4,
		tickValuePerLot: 10,
		digits: 5
	},
	{
		id: "gbp",
		symbol: "GBPUSD",
		tickSize: 1e-4,
		tickValuePerLot: 10,
		digits: 5
	},
	{
		id: "nas",
		symbol: "NAS100",
		tickSize: 1,
		tickValuePerLot: 1,
		digits: 1
	}
];
var DEFAULT_MODELS = [
	{
		id: "model-a",
		code: "A",
		name: "Sell-side raid reversal",
		market: "XAUUSD",
		timeframe: "1H → 5m",
		htfNarrative: "Bearish weekly/daily. Price in premium of the dealing range.",
		liquidityCondition: "SSL / PDL / Asia low taken first.",
		pdArray: "1H or 15m bearish FVG / OB in premium.",
		trigger: "MSS + displacement + 5m FVG.",
		invalidation: "Displacement back through the swept high; FVG fully mitigated against bias.",
		target: "BSL / PDH / opposing external.",
		requiredTiming: "NY AM kill zone (or London expansion if HTF already delivered Asia).",
		validWhen: [
			"HTF aligned",
			"Premium location",
			"Liquidity swept",
			"Kill zone",
			"MSS + displacement"
		],
		invalidWhen: [
			"Mid-range",
			"Already delivered",
			"Wrong session",
			"No remaining target"
		],
		active: true
	},
	{
		id: "model-b",
		code: "B",
		name: "Buy-side raid reversal",
		market: "XAUUSD",
		timeframe: "1H → 5m",
		htfNarrative: "Bullish weekly/daily. Price in discount of the dealing range.",
		liquidityCondition: "BSL / PDH / Asia high taken first.",
		pdArray: "1H or 15m bullish FVG / OB in discount.",
		trigger: "MSS + displacement + 5m FVG.",
		invalidation: "Close back below the swept low.",
		target: "SSL / PDL / opposing external.",
		requiredTiming: "NY AM or London kill zone.",
		validWhen: [
			"HTF aligned",
			"Discount location",
			"Liquidity swept",
			"Kill zone",
			"MSS + displacement"
		],
		invalidWhen: [
			"Mid-range",
			"Already delivered",
			"Counter-narrative",
			"Late chase"
		],
		active: true
	},
	{
		id: "model-c",
		code: "C",
		name: "Continuation",
		market: "XAUUSD",
		timeframe: "1H → 5m",
		htfNarrative: "Established expansion. Pullback into PD array.",
		liquidityCondition: "Internal liquidity taken; external still available.",
		pdArray: "FVG / OB / breaker in the direction of HTF.",
		trigger: "Continuation displacement off the array.",
		invalidation: "Array fully mitigated and structure shifts against.",
		target: "External liquidity of the dealing range.",
		requiredTiming: "Session continuation window (London expansion / NY AM continuation).",
		validWhen: [
			"HTF expansion",
			"Internal taken",
			"Fresh PD array",
			"Continuation displacement"
		],
		invalidWhen: [
			"Range day",
			"External already taken",
			"Deep retrace through invalidation"
		],
		active: true
	},
	{
		id: "model-d",
		code: "D",
		name: "AMD / Judas",
		market: "XAUUSD",
		timeframe: "15m → 5m",
		htfNarrative: "Clear daily draw. Asia is accumulation.",
		liquidityCondition: "Asia high/low or previous session extreme raided (Judas).",
		pdArray: "Session FVG created after the raid.",
		trigger: "Judas → MSS → displacement → FVG.",
		invalidation: "Price accepts beyond the Judas and continues that way.",
		target: "Opposing session extreme / daily draw.",
		requiredTiming: "London open or NY open.",
		validWhen: [
			"Asia accumulation",
			"Judas present",
			"Narrative alignment",
			"NY/London open"
		],
		invalidWhen: [
			"No Judas",
			"News inside the window",
			"Already distributed"
		],
		active: true
	},
	{
		id: "model-e",
		code: "E",
		name: "CRT purge-reclaim",
		market: "XAUUSD",
		timeframe: "4H / 1H reference",
		htfNarrative: "Candle-range theory: raid one side of the reference candle, reclaim, target the other.",
		liquidityCondition: "Purge of the reference high or low.",
		pdArray: "Reclaim close back inside the range + FVG.",
		trigger: "Purge → reclaim → entry after reclaim.",
		invalidation: "Acceptance outside the opposite side without reclaim.",
		target: "Opposite side of the CRT range, then external.",
		requiredTiming: "Any session if the reference candle is HTF; prefer London/NY for XAU.",
		validWhen: [
			"Clear reference candle",
			"Purge",
			"Reclaim",
			"Opposite-side target free"
		],
		invalidWhen: [
			"Both sides already raided",
			"No reclaim",
			"Inside mid of range"
		],
		active: true
	}
];
var CHECKLIST = [
	{
		group: "core",
		label: "HTF narrative defined"
	},
	{
		group: "core",
		label: "Draw on liquidity is clear"
	},
	{
		group: "core",
		label: "Location: premium / discount / PD array"
	},
	{
		group: "core",
		label: "Timing: session + kill zone"
	},
	{
		group: "core",
		label: "Trigger: sweep → shift → displacement"
	},
	{
		group: "core",
		label: "Risk, stop, and invalidation written"
	},
	{
		group: "conditional",
		label: "SMT (only if used)"
	},
	{
		group: "conditional",
		label: "OTE mapped (only if used)"
	},
	{
		group: "conditional",
		label: "CRT range defined (only if used)"
	},
	{
		group: "conditional",
		label: "Judas identified (session models)"
	},
	{
		group: "conditional",
		label: "AMD phase named"
	},
	{
		group: "conditional",
		label: "News / high-impact checked"
	},
	{
		group: "lifestyle",
		label: "Sleep 7–9 hours"
	},
	{
		group: "lifestyle",
		label: "Emotional state is normal"
	},
	{
		group: "lifestyle",
		label: "Notifications off during the window"
	}
];
function defaultRules(start) {
	return {
		startingBalance: 5e4,
		profitTargetPct: 8,
		maxDailyLossPct: 1,
		maxTotalDrawdownPct: 5,
		drawdownType: "static",
		profitSplit: 80,
		consistencyPct: 30,
		minTradingDays: 5,
		maxPositionLots: 2,
		newsRestricted: true,
		weekendRestricted: true,
		scalingNote: "Do not size up inside a payout cycle.",
		payoutThresholdPct: 8,
		normalRiskPct: .25,
		highConvictionRiskPct: .5,
		maxTrades: 2,
		maxConsecutiveLosses: 2,
		windowStart: "03:00",
		windowEnd: "11:30",
		protocolStartDate: start
	};
}
function defaultPlanFrom(data, date) {
	const rules = "rules" in data ? data.rules : data;
	return {
		date,
		market: "XAUUSD",
		htfStructure: "consolidation",
		previousDay: {
			pdh: null,
			pdl: null,
			pdc: null,
			dailyOpen: null,
			midnightOpen: null
		},
		location: "equilibrium",
		liquidityCondition: "Both",
		expectedDraw: "",
		expectedDelivery: "",
		alignments: {
			htf: false,
			liquidity: false,
			location: false,
			time: false,
			narrative: false
		},
		amdPhase: "",
		expectedManipulation: "",
		expectedDistribution: "",
		dealingRange: emptyRange(),
		scenarios: "",
		maxTrades: rules.maxTrades,
		maxDailyLossPct: rules.maxDailyLossPct,
		riskPerTrade: rules.normalRiskPct,
		notes: ""
	};
}
function protocolFocus(day) {
	if (day <= 10) return {
		title: `Survival · Day ${day}`,
		focus: {
			1: "Write the weekly narrative. Mark PWH/PWL. Take nothing unless the model is obvious.",
			2: "Separate location from trigger. Journal the chain, not a paragraph.",
			4: "If you feel FOMO, you are already late. Skip.",
			7: "Weekly review: narrative errors vs execution errors.",
			10: "Survival check: still 0.25%? If yes, you are winning phase 1."
		}[day] ?? "Tiny size. One model. Stop after two losses.",
		riskPct: .25,
		maxTrades: 2,
		phase: 1
	};
	if (day <= 20) return {
		title: `Consistency · Day ${day}`,
		focus: day === 15 ? "Expectancy check. If rule-follow < 90%, stay at 0.25%." : "Positive expectancy with controlled drawdown. Do not invent a new model.",
		riskPct: day >= 15 ? .35 : .25,
		maxTrades: 2,
		phase: 2
	};
	if (day <= 26) return {
		title: `Payout protection · Day ${day}`,
		focus: day === 21 ? "If the account is green, cut risk." : "Hold the line. No size-up.",
		riskPct: .25,
		maxTrades: 2,
		phase: 3
	};
	return {
		title: `Payout lock · Day ${day}`,
		focus: {
			27: "Payout lock. Max 1 trade. Refuse heroics.",
			28: "If you are near the threshold, sit on your hands.",
			29: "Review the journal. One more clean day beats one more gamble.",
			30: "Lock. Request. Do not give it back on the last day."
		}[day] ?? "Max one trade. Reduced risk.",
		riskPct: .2,
		maxTrades: 1,
		phase: 4
	};
}
function buildProtocolDays(startDate) {
	return Array.from({ length: 30 }, (_, i) => {
		const day = i + 1;
		const meta = protocolFocus(day);
		return {
			id: `day-${day}`,
			day,
			date: addDaysISO(startDate, i),
			title: meta.title,
			focus: meta.focus,
			phase: meta.phase,
			riskPct: meta.riskPct,
			maxTrades: meta.maxTrades,
			completed: false,
			skipped: false,
			notes: ""
		};
	});
}
function baseTrade(partial) {
	return {
		market: "XAUUSD",
		side: "short",
		modelId: "model-a",
		modelName: "Sell-side raid reversal",
		weeklyBias: "bearish",
		dailyBias: "bearish",
		drawOnLiquidity: "BSL",
		location: "premium",
		dealingRange: {
			high: 3532,
			low: 3468,
			current: 3490
		},
		dealingRangeLabel: "Daily",
		taken: ["PWH"],
		targetLiq: ["BSL", "PDL"],
		pdArray: "Fair Value Gap",
		pdTimeframe: "1H",
		pdCondition: "fresh",
		triggers: [
			"Liquidity sweep",
			"MSS",
			"Displacement"
		],
		session: "NY",
		killZone: "NY AM Kill Zone",
		timeModel: "NY AM reversal",
		structureBefore: "range",
		displacementQuality: "strong",
		fvgCreated: true,
		fvgTimeframe: "5m",
		judas: emptyJudas(),
		ote: emptyOte(),
		smt: emptySmt(),
		crt: emptyCrt(),
		intermarket: emptyIntermarket(),
		entry: null,
		sl: null,
		tp1: null,
		tp2: null,
		tp3: null,
		exitPrice: null,
		exitTime: "",
		exitReason: "",
		riskPct: .25,
		lots: .22,
		management: "Partial",
		partialAtR: 1,
		be: false,
		maeR: null,
		mfeR: null,
		narrativeCorrect: true,
		liquidityCorrect: true,
		locationCorrect: true,
		triggerCorrect: true,
		executionQuality: "optimal",
		managementQuality: "good",
		errors: ["No actual error"],
		primaryError: "No actual error",
		deliveryStatus: "early",
		grade: "A",
		emotion: "calm",
		ruleFollowed: true,
		notes: "",
		screenshotHtf: "",
		screenshotExec: "",
		result: "open",
		rMultiple: null,
		...partial
	};
}
function emptyTrade(date, time, risk, model) {
	return baseTrade({
		id: uid("tr"),
		date,
		time,
		riskPct: risk,
		modelId: model?.id ?? "",
		modelName: model?.name ?? "",
		result: "open",
		rMultiple: null,
		narrativeCorrect: null,
		liquidityCorrect: null,
		locationCorrect: null,
		triggerCorrect: null,
		executionQuality: "",
		managementQuality: "n/a",
		errors: [],
		primaryError: "",
		deliveryStatus: "",
		grade: "",
		lots: null,
		management: "No management",
		partialAtR: null
	});
}
function emptyMissed(date, time) {
	return {
		id: uid("ms"),
		date,
		time,
		market: "XAUUSD",
		side: "long",
		narrativeValid: true,
		liquiditySwept: true,
		pdArrayPresent: true,
		triggerOccurred: true,
		why: "Hesitation",
		outcome: "",
		notes: ""
	};
}
function emptyWeekly(weekStart) {
	return {
		id: uid("wk"),
		weekStart,
		market: "XAUUSD",
		dealingRange: emptyRange(),
		structure: "consolidation",
		profile: "normal",
		liquidity: [
			{
				type: "PWH",
				price: null,
				status: "untouched"
			},
			{
				type: "PWL",
				price: null,
				status: "untouched"
			},
			{
				type: "EQH",
				price: null,
				status: "untouched"
			},
			{
				type: "EQL",
				price: null,
				status: "untouched"
			}
		],
		primaryDraw: "",
		secondaryDraw: "",
		beforeDraw: "",
		notes: ""
	};
}
function emptyDesk() {
	return {
		hasBootstrapped: false,
		accountName: "Funded · First payout",
		phaseId: 1,
		phases: DEFAULT_PHASES,
		rules: defaultRules(""),
		mantra: DEFAULT_MANTRA,
		instruments: [],
		models: [],
		recentlyDeletedModels: [],
		trades: [],
		missed: [],
		weeklies: [],
		dailyPlans: {},
		liquidity: [],
		checklistItems: [],
		checks: {},
		protocolDays: [],
		newsEvents: [],
		forceClosedDates: [],
		forceOpenDates: []
	};
}
function createResetState() {
	return {
		...emptyDesk(),
		hasBootstrapped: true,
		instruments: DEFAULT_INSTRUMENTS.map((instrument) => ({ ...instrument })),
		models: DEFAULT_MODELS.map((model) => ({
			...model,
			validWhen: [...model.validWhen],
			invalidWhen: [...model.invalidWhen]
		})),
		checklistItems: CHECKLIST.map((item) => ({
			id: uid("chk"),
			...item
		}))
	};
}
function ensureMinimumDeskData(data) {
	let repaired = data;
	if (!Array.isArray(data.recentlyDeletedModels)) repaired = {
		...repaired,
		recentlyDeletedModels: []
	};
	if (!Array.isArray(data.checklistItems) || data.checklistItems.length === 0) repaired = {
		...repaired,
		checklistItems: CHECKLIST.map((item) => ({
			id: uid("chk"),
			...item
		}))
	};
	if (!Array.isArray(data.models) || data.models.length === 0) repaired = {
		...repaired,
		models: DEFAULT_MODELS.map((model) => ({
			...model,
			validWhen: [...model.validWhen],
			invalidWhen: [...model.invalidWhen]
		}))
	};
	if (!Array.isArray(data.instruments) || data.instruments.length === 0) repaired = {
		...repaired,
		instruments: DEFAULT_INSTRUMENTS.map((instrument) => ({ ...instrument }))
	};
	return repaired;
}
function createInitialState() {
	const today = todayISO$1();
	const start = addDaysISO(today, -8);
	const week = weekStartISO(today);
	const prevWeek = addDaysISO(week, -7);
	const rules = defaultRules(start);
	const checklistItems = CHECKLIST.map((c) => ({
		id: uid("chk"),
		...c
	}));
	const weeklies = [{
		id: "wk-prev",
		weekStart: prevWeek,
		market: "XAUUSD",
		dealingRange: {
			high: 3524.8,
			low: 3458.2,
			open: 3482,
			close: 3501.4,
			current: 3501.4
		},
		structure: "expansion",
		profile: "expansion",
		liquidity: [
			{
				type: "PWH",
				price: 3518.6,
				status: "taken"
			},
			{
				type: "PWL",
				price: 3462.1,
				status: "untouched"
			},
			{
				type: "EQH",
				price: 3512,
				status: "taken"
			},
			{
				type: "EQL",
				price: 3471,
				status: "untouched"
			}
		],
		primaryDraw: "PWH",
		secondaryDraw: "BSL",
		beforeDraw: "Price raided Asia lows first, then expanded to PWH.",
		notes: "Bullish week. External buy-side delivered late Thursday."
	}, {
		id: "wk-now",
		weekStart: week,
		market: "XAUUSD",
		dealingRange: {
			high: 3532.4,
			low: 3468.1,
			open: 3501.4,
			close: null,
			current: 3492.6
		},
		structure: "reversal",
		profile: "reversal",
		liquidity: [
			{
				type: "PWH",
				price: 3532.4,
				status: "taken"
			},
			{
				type: "PWL",
				price: 3468.1,
				status: "untouched"
			},
			{
				type: "EQH",
				price: 3524.8,
				status: "taken"
			},
			{
				type: "EQL",
				price: 3479.2,
				status: "untouched"
			},
			{
				type: "BSL",
				price: 3532.4,
				status: "taken"
			},
			{
				type: "SSL",
				price: 3468.1,
				status: "untouched"
			}
		],
		primaryDraw: "PWL",
		secondaryDraw: "SSL",
		beforeDraw: "PWL is the external draw. Before reaching it, price should raid Asia/PDL and rebalance a 1H bearish FVG.",
		notes: "Week opened at premium after last week’s expansion. Looking for distribution into discount."
	}];
	const dailyPlans = { [today]: {
		date: today,
		market: "XAUUSD",
		htfStructure: "reversal",
		previousDay: {
			pdh: 3518.4,
			pdl: 3484.2,
			pdc: 3496.8,
			dailyOpen: 3497.1,
			midnightOpen: 3498.6
		},
		location: "premium",
		liquidityCondition: "One side raided",
		expectedDraw: "PWL",
		expectedDelivery: "Raid then reverse",
		alignments: {
			htf: true,
			liquidity: true,
			location: true,
			time: true,
			narrative: true
		},
		amdPhase: "Manipulation",
		expectedManipulation: "Asia high / PDH raid (Judas) into NY AM",
		expectedDistribution: "bearish",
		dealingRange: {
			high: 3518.4,
			low: 3484.2,
			open: 3497.1,
			current: 3492.6
		},
		scenarios: "A: Raid PDH/Asia high → MSS lower → 5m FVG short targeting PDL then PWL.\nB: If PDL taken first without displacement, stand down — mid-range.",
		maxTrades: 2,
		maxDailyLossPct: 1,
		riskPerTrade: .25,
		notes: "Only Model A or D. No continuation longs from premium."
	} };
	const liquidity = [
		{
			id: "liq-pwh",
			date: addDaysISO(today, -2),
			market: "XAUUSD",
			timeframe: "1W",
			price: 3532.4,
			type: "PWH",
			scope: "external",
			status: "taken",
			dateSwept: addDaysISO(today, -1),
			reaction: "Immediate displacement lower, 1H FVG left.",
			consequence: "Daily bias flipped to distribution."
		},
		{
			id: "liq-asia",
			date: today,
			market: "XAUUSD",
			timeframe: "15m",
			price: 3506.2,
			type: "Asia High",
			scope: "internal",
			status: "untouched",
			dateSwept: "",
			reaction: "",
			consequence: ""
		},
		{
			id: "liq-pdl",
			date: today,
			market: "XAUUSD",
			timeframe: "1D",
			price: 3484.2,
			type: "PDL",
			scope: "external",
			status: "untouched",
			dateSwept: "",
			reaction: "",
			consequence: ""
		}
	];
	const trades = [
		baseTrade({
			id: "tr-1",
			date: addDaysISO(today, -7),
			time: "04:18",
			side: "long",
			modelId: "model-c",
			modelName: "Continuation",
			weeklyBias: "bullish",
			dailyBias: "bullish",
			drawOnLiquidity: "PWH",
			location: "discount",
			dealingRange: {
				high: 3518.6,
				low: 3462.1,
				current: 3478
			},
			taken: ["SSL", "PDL"],
			targetLiq: ["BSL", "PWH"],
			pdArray: "Order Block",
			pdTimeframe: "1H",
			pdCondition: "fresh",
			triggers: ["FVG retracement", "Displacement"],
			session: "London",
			killZone: "London Kill Zone",
			timeModel: "London expansion",
			structureBefore: "bullish",
			displacementQuality: "normal",
			entry: 3476.4,
			sl: 3468.8,
			tp1: 3492,
			tp2: 3508,
			tp3: 3518,
			exitPrice: 3491.8,
			exitTime: "07:40",
			exitReason: "Partial",
			rMultiple: 2.03,
			result: "win",
			maeR: -.35,
			mfeR: 2.4,
			notes: "Continuation off 1H bullish OB after PDL raid. Held to 2R, paid 2.03R."
		}),
		baseTrade({
			id: "tr-2",
			date: addDaysISO(today, -6),
			time: "09:42",
			side: "long",
			modelId: "model-b",
			modelName: "Buy-side raid reversal",
			weeklyBias: "bullish",
			dailyBias: "bullish",
			drawOnLiquidity: "EQH",
			location: "discount",
			taken: ["SSL", "Asia Low"],
			targetLiq: ["EQH"],
			pdArray: "Fair Value Gap",
			pdTimeframe: "15m",
			triggers: [
				"Liquidity sweep",
				"MSS",
				"Displacement",
				"FVG retracement"
			],
			session: "NY",
			killZone: "NY AM Kill Zone",
			timeModel: "NY AM reversal",
			smt: {
				present: "bullish",
				pair: "XAUUSD ↔ DXY",
				sweptMarket: "XAUUSD SSL",
				failedMarket: "DXY failed to make a higher high",
				beforeTrigger: true
			},
			entry: 3471.2,
			sl: 3464.5,
			tp1: 3485,
			tp2: 3498,
			exitPrice: 3482.6,
			exitTime: "11:05",
			exitReason: "TP",
			rMultiple: 1.7,
			result: "win",
			maeR: -.4,
			mfeR: 1.9,
			grade: "A+",
			notes: "SMT with DXY before the 5m MSS. Best A+ of the sample."
		}),
		baseTrade({
			id: "tr-3",
			date: addDaysISO(today, -5),
			time: "10:08",
			side: "short",
			modelId: "model-a",
			modelName: "Sell-side raid reversal",
			weeklyBias: "bullish",
			dailyBias: "neutral",
			drawOnLiquidity: "PDL",
			location: "equilibrium",
			taken: ["Session High"],
			targetLiq: ["PDL"],
			pdArray: "Fair Value Gap",
			pdTimeframe: "5m",
			pdCondition: "partial",
			triggers: ["Displacement"],
			session: "NY",
			killZone: "NY AM Kill Zone",
			timeModel: "NY AM continuation",
			structureBefore: "range",
			displacementQuality: "weak",
			fvgCreated: false,
			fvgTimeframe: "",
			entry: 3494.1,
			sl: 3499.6,
			tp1: 3482,
			exitPrice: 3499.6,
			exitTime: "10:22",
			exitReason: "SL",
			rMultiple: -1,
			result: "loss",
			maeR: -1,
			mfeR: .3,
			narrativeCorrect: false,
			locationCorrect: false,
			triggerCorrect: false,
			executionQuality: "chasing",
			errors: ["Location wrong", "Entry too late"],
			primaryError: "Location wrong",
			deliveryStatus: "late",
			grade: "D",
			emotion: "fomo",
			ruleFollowed: false,
			notes: "Mid-range stab. No HTF array. This is sightseeing."
		}),
		baseTrade({
			id: "tr-4",
			date: addDaysISO(today, -5),
			time: "10:41",
			side: "short",
			modelId: "model-a",
			modelName: "Sell-side raid reversal",
			weeklyBias: "bullish",
			dailyBias: "neutral",
			location: "equilibrium",
			taken: [],
			targetLiq: ["PDL"],
			pdArray: "Session FVG",
			pdTimeframe: "5m",
			triggers: ["FVG retracement"],
			session: "NY",
			killZone: "NY AM Kill Zone",
			entry: 3496.2,
			sl: 3502,
			tp1: 3484,
			exitPrice: 3502,
			exitTime: "10:55",
			exitReason: "SL",
			riskPct: .5,
			lots: .43,
			rMultiple: -1,
			result: "loss",
			maeR: -1,
			mfeR: .15,
			narrativeCorrect: false,
			liquidityCorrect: false,
			locationCorrect: false,
			triggerCorrect: false,
			executionQuality: "chasing",
			managementQuality: "poor",
			errors: ["Psychology", "Entry too late"],
			primaryError: "Psychology",
			deliveryStatus: "delivered",
			grade: "F",
			emotion: "revenge",
			ruleFollowed: false,
			notes: "Revenge size-up after the mid-range loss. The protocol exists to kill this trade."
		}),
		baseTrade({
			id: "tr-5",
			date: addDaysISO(today, -3),
			time: "03:52",
			side: "short",
			modelId: "model-d",
			modelName: "AMD / Judas",
			weeklyBias: "bearish",
			dailyBias: "bearish",
			drawOnLiquidity: "PDL",
			location: "premium",
			taken: ["Asia High", "PDH"],
			targetLiq: ["SSL", "PDL"],
			pdArray: "Session FVG",
			pdTimeframe: "15m",
			triggers: [
				"Session opening manipulation",
				"MSS",
				"Displacement"
			],
			session: "London",
			killZone: "London Kill Zone",
			timeModel: "London open",
			judas: {
				present: "yes",
				direction: "higher",
				aligned: true,
				after: "reversal"
			},
			entry: 3512.8,
			sl: 3519.4,
			tp1: 3498,
			tp2: 3486,
			exitPrice: 3494.6,
			exitTime: "06:10",
			exitReason: "Trailing stop",
			rMultiple: 2.76,
			result: "win",
			maeR: -.25,
			mfeR: 3.1,
			management: "Trailed",
			partialAtR: 1,
			be: true,
			grade: "A",
			notes: "Clean Judas above Asia high at London open. Distribution into PDL."
		}),
		baseTrade({
			id: "tr-6",
			date: addDaysISO(today, -2),
			time: "09:58",
			side: "short",
			modelId: "model-a",
			modelName: "Sell-side raid reversal",
			weeklyBias: "bearish",
			dailyBias: "bearish",
			drawOnLiquidity: "PWL",
			location: "premium",
			taken: [
				"PWH",
				"BSL",
				"EQH"
			],
			targetLiq: ["SSL", "PWL"],
			pdArray: "HTF FVG",
			pdTimeframe: "1H",
			pdCondition: "fresh",
			triggers: [
				"Liquidity sweep",
				"MSS",
				"Displacement",
				"FVG retracement"
			],
			session: "NY",
			killZone: "NY AM Kill Zone",
			timeModel: "NY AM reversal",
			ote: {
				used: "used",
				swingHigh: 3532.4,
				swingLow: 3498.1,
				retracement: 62,
				inside: true,
				confluence: true
			},
			entry: 3516.2,
			sl: 3524.8,
			tp1: 3498,
			tp2: 3480,
			exitPrice: 3502.4,
			exitTime: "11:18",
			exitReason: "Partial",
			rMultiple: 1.6,
			result: "win",
			maeR: -.55,
			mfeR: 2.8,
			executionQuality: "late",
			errors: ["Entry too late"],
			primaryError: "Entry too late",
			deliveryStatus: "mid",
			grade: "A-",
			emotion: "hesitation",
			notes: "Narrative and location correct. Entered the 5m FVG late — left 1R on the table vs MFE."
		}),
		baseTrade({
			id: "tr-7",
			date: addDaysISO(today, -1),
			time: "10:14",
			side: "long",
			modelId: "model-e",
			modelName: "CRT purge-reclaim",
			weeklyBias: "bearish",
			dailyBias: "neutral",
			drawOnLiquidity: "PDH",
			location: "discount",
			dealingRange: {
				high: 3518.4,
				low: 3472.6,
				current: 3476
			},
			dealingRangeLabel: "Daily",
			taken: ["PDL", "SSL"],
			targetLiq: ["PDH"],
			pdArray: "Fair Value Gap",
			pdTimeframe: "15m",
			triggers: [
				"Liquidity sweep",
				"MSS",
				"Displacement"
			],
			session: "NY",
			killZone: "NY AM Kill Zone",
			timeModel: "NY AM reversal",
			crt: {
				used: true,
				reference: "4H",
				high: 3518.4,
				low: 3472.6,
				raidSide: "low",
				purge: true,
				reclaim: true,
				entryAfterReclaim: true,
				target: "Opposite side"
			},
			entry: 3478.5,
			sl: 3471.2,
			tp1: 3494,
			tp2: 3512,
			exitPrice: 3493.8,
			exitTime: "12:02",
			exitReason: "TP",
			rMultiple: 2.1,
			result: "win",
			maeR: -.3,
			mfeR: 2.3,
			grade: "A",
			notes: "4H CRT purge of the low, reclaim, opposite-side target paid."
		}),
		baseTrade({
			id: "tr-8",
			date: addDaysISO(today, -1),
			time: "14:22",
			side: "short",
			modelId: "model-a",
			modelName: "Sell-side raid reversal",
			weeklyBias: "bearish",
			dailyBias: "bearish",
			drawOnLiquidity: "PWL",
			location: "premium",
			taken: ["Session High"],
			targetLiq: ["PDL"],
			pdArray: "Inverse Fair Value Gap",
			pdTimeframe: "5m",
			pdCondition: "fresh",
			triggers: ["BOS", "Displacement"],
			session: "NY",
			killZone: "NY PM",
			timeModel: "NY PM",
			structureBefore: "bearish",
			displacementQuality: "normal",
			entry: 3504.6,
			sl: 3510.1,
			tp1: 3492,
			exitPrice: 3505.2,
			exitTime: "14:40",
			exitReason: "Narrative invalidated",
			rMultiple: -.11,
			result: "be",
			maeR: -.4,
			mfeR: .6,
			management: "BE",
			be: true,
			executionQuality: "late",
			errors: ["Timing wrong"],
			primaryError: "Timing wrong",
			deliveryStatus: "late",
			grade: "C",
			emotion: "pressure",
			notes: "NY PM is not the model. Scratched near BE. Should have been no-trade."
		})
	];
	const missed = [{
		id: "ms-1",
		date: addDaysISO(today, -4),
		time: "09:51",
		market: "XAUUSD",
		side: "short",
		narrativeValid: true,
		liquiditySwept: true,
		pdArrayPresent: true,
		triggerOccurred: true,
		why: "Hesitation",
		outcome: "Full TP",
		notes: "Waited for a second MSS. The first 5m FVG was the entry. 2.4R ran without me."
	}, {
		id: "ms-2",
		date: addDaysISO(today, -2),
		time: "03:40",
		market: "XAUUSD",
		side: "short",
		narrativeValid: true,
		liquiditySwept: true,
		pdArrayPresent: true,
		triggerOccurred: true,
		why: "Too much analysis",
		outcome: "Partial TP",
		notes: "Overlaid SMT + OTE + CRT until London already distributed. Delivery was mid when I was still tagging confluence."
	}];
	const newsEvents = [{
		id: "news-cpi",
		name: "CPI",
		date: addDaysISO(today, 1),
		time: "08:30",
		impact: "high",
		notes: "NY AM is compromised. If you are not a news trader, you are flat.",
		avoid: true
	}, {
		id: "news-nfp",
		name: "NFP",
		date: addDaysISO(today, 3),
		time: "08:30",
		impact: "high",
		notes: "Spreads and slippage. Protect the account.",
		avoid: true
	}];
	const protocolDays = buildProtocolDays(start).map((d) => ({
		...d,
		completed: d.date < today && d.day !== 4 && d.day !== 6,
		skipped: d.day === 4 || d.day === 6,
		notes: d.day === 6 ? "Platform closed after revenge day. Reviewed. Did not trade." : d.day === 5 ? "Broke rules. Revenge trade. This is why the lock exists." : ""
	}));
	const coreIds = checklistItems.filter((i) => i.group === "core").map((i) => i.id);
	const lifeIds = checklistItems.filter((i) => i.group === "lifestyle").map((i) => i.id);
	const checks = {};
	for (let i = 0; i < 8; i += 1) {
		const date = addDaysISO(start, i);
		if (date === addDaysISO(today, -5) || date === addDaysISO(today, -4)) continue;
		checks[date] = [...coreIds, ...lifeIds];
	}
	checks[today] = [...coreIds.slice(0, 4), ...lifeIds];
	return {
		hasBootstrapped: true,
		accountName: "Funded · First payout",
		phaseId: 1,
		phases: DEFAULT_PHASES.map((p) => ({ ...p })),
		rules,
		mantra: DEFAULT_MANTRA,
		instruments: DEFAULT_INSTRUMENTS.map((i) => ({ ...i })),
		models: DEFAULT_MODELS.map((m) => ({
			...m,
			validWhen: [...m.validWhen],
			invalidWhen: [...m.invalidWhen]
		})),
		recentlyDeletedModels: [{
			id: "model-f",
			code: "F",
			name: "London breakout fade",
			market: "XAUUSD",
			timeframe: "15m → 5m",
			htfNarrative: "Fade of false London breakout outside key dealing range.",
			liquidityCondition: "London high or low taken without displacement.",
			pdArray: "Breaker block + FVG.",
			trigger: "MSS back into range.",
			invalidation: "Continuation outside range.",
			target: "Asia mid-range / opposing extreme.",
			requiredTiming: "London session 08:30–10:30 GMT.",
			validWhen: [
				"False breakout",
				"Lack of displacement",
				"MSS back inside"
			],
			invalidWhen: ["Real trend expansion", "Major news release"],
			active: false,
			deletedAt: addDaysISO(today, -2)
		}],
		trades,
		missed,
		weeklies,
		dailyPlans,
		liquidity,
		checklistItems,
		checks,
		protocolDays,
		newsEvents,
		forceClosedDates: [],
		forceOpenDates: []
	};
}
function upsert(list, item) {
	const i = list.findIndex((x) => x.id === item.id);
	if (i === -1) return [...list, item];
	const next = list.slice();
	next[i] = item;
	return next;
}
var useDeskStore = create()(persist((set, get) => ({
	...emptyDesk(),
	bootstrapIfNeeded: () => {
		if (!get().hasBootstrapped) set(createInitialState());
	},
	resetAll: (data = createResetState()) => set({
		...data,
		hasBootstrapped: true
	}),
	replaceAll: (data) => set({
		...data,
		hasBootstrapped: true
	}),
	patchAccount: (patch) => set((s) => {
		const { accountName, phaseId, mantra, ...rest } = patch;
		return {
			accountName: accountName ?? s.accountName,
			phaseId: phaseId ?? s.phaseId,
			mantra: mantra ?? s.mantra,
			rules: {
				...s.rules,
				...rest
			}
		};
	}),
	setPhaseId: (id) => set({ phaseId: id }),
	updatePhase: (phase) => set((s) => ({ phases: s.phases.map((p) => p.id === phase.id ? phase : p) })),
	upsertTrade: (trade) => set((s) => ({ trades: upsert(s.trades, trade) })),
	removeTrade: (id) => set((s) => ({ trades: s.trades.filter((x) => x.id !== id) })),
	updateTradeReview: (id, reviewed) => set((s) => ({ trades: s.trades.map((t) => t.id === id ? {
		...t,
		reviewed
	} : t) })),
	updateTradeRule: (id, ruleKey, status) => set((s) => ({ trades: s.trades.map((t) => t.id === id ? {
		...t,
		rulesAssessment: {
			...t.rulesAssessment ?? {},
			[ruleKey]: status
		}
	} : t) })),
	updateTradeGrade: (id, grade) => set((s) => ({ trades: s.trades.map((t) => t.id === id ? {
		...t,
		grade
	} : t) })),
	updateTradeTags: (id, setupTags, mistakeTags) => set((s) => ({ trades: s.trades.map((t) => t.id === id ? {
		...t,
		setupTags,
		mistakeTags
	} : t) })),
	updateTradePlaybook: (id, modelId, modelName) => set((s) => ({ trades: s.trades.map((t) => t.id === id ? {
		...t,
		modelId,
		modelName
	} : t) })),
	upsertMissed: (row) => set((s) => ({ missed: upsert(s.missed, row) })),
	removeMissed: (id) => set((s) => ({ missed: s.missed.filter((x) => x.id !== id) })),
	upsertWeekly: (row) => set((s) => ({ weeklies: upsert(s.weeklies, row) })),
	removeWeekly: (id) => set((s) => ({ weeklies: s.weeklies.filter((x) => x.id !== id) })),
	setPlan: (date, plan) => set((s) => ({ dailyPlans: {
		...s.dailyPlans,
		[date]: plan
	} })),
	setDailyJournalNote: (date, note) => set((s) => {
		const currentPlan = s.dailyPlans[date] ?? {
			date,
			market: "XAUUSD",
			htfStructure: "consolidation",
			previousDay: {
				pdh: null,
				pdl: null,
				pdc: null,
				dailyOpen: null,
				midnightOpen: null
			},
			location: "equilibrium",
			liquidityCondition: "Both",
			expectedDraw: "",
			expectedDelivery: "",
			alignments: {
				htf: false,
				liquidity: false,
				location: false,
				time: false,
				narrative: false
			},
			amdPhase: "",
			expectedManipulation: "",
			expectedDistribution: "",
			dealingRange: {
				high: null,
				low: null,
				open: null,
				close: null,
				current: null
			},
			scenarios: "",
			maxTrades: s.rules.maxTrades,
			maxDailyLossPct: s.rules.maxDailyLossPct,
			riskPerTrade: s.rules.normalRiskPct,
			notes: ""
		};
		const now = /* @__PURE__ */ new Date();
		const timeStr = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
		return { dailyPlans: {
			...s.dailyPlans,
			[date]: {
				...currentPlan,
				notes: note,
				savedAt: timeStr
			}
		} };
	}),
	upsertLiquidity: (row) => set((s) => ({ liquidity: upsert(s.liquidity, row) })),
	removeLiquidity: (id) => set((s) => ({ liquidity: s.liquidity.filter((x) => x.id !== id) })),
	upsertModel: (model) => set((s) => ({ models: upsert(s.models, model) })),
	removeModel: (id) => set((s) => {
		const model = s.models.find((item) => item.id === id);
		if (!model) return {};
		const deleted = {
			model,
			deletedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		return {
			models: s.models.filter((item) => item.id !== id),
			recentlyDeletedModels: [...(s.recentlyDeletedModels ?? []).filter((item) => item.model.id !== id), deleted]
		};
	}),
	restoreModel: (id) => {
		const current = get();
		const deleted = (current.recentlyDeletedModels ?? []).find((item) => item.model.id === id);
		if (!deleted) return false;
		if (current.models.some((model) => model.id !== id && model.code.toLowerCase() === deleted.model.code.toLowerCase())) return false;
		set((s) => ({
			models: [...s.models, deleted.model],
			recentlyDeletedModels: (s.recentlyDeletedModels ?? []).filter((item) => item.model.id !== id)
		}));
		return true;
	},
	permanentlyDeleteModel: (id) => set((s) => ({ recentlyDeletedModels: (s.recentlyDeletedModels ?? []).filter((item) => item.model.id !== id) })),
	upsertChecklistItem: (item) => set((s) => ({ checklistItems: upsert(s.checklistItems, item) })),
	removeChecklistItem: (id) => set((s) => ({ checklistItems: s.checklistItems.filter((x) => x.id !== id) })),
	toggleCheck: (date, id) => set((s) => {
		const cur = new Set(s.checks[date] ?? []);
		if (cur.has(id)) cur.delete(id);
		else cur.add(id);
		return { checks: {
			...s.checks,
			[date]: [...cur]
		} };
	}),
	upsertNews: (event) => set((s) => ({ newsEvents: upsert(s.newsEvents, event) })),
	removeNews: (id) => set((s) => ({ newsEvents: s.newsEvents.filter((x) => x.id !== id) })),
	upsertProtocolDay: (day) => set((s) => ({ protocolDays: upsert(s.protocolDays, day) })),
	addProtocolDay: () => set((s) => {
		const last = s.protocolDays[s.protocolDays.length - 1];
		const day = (last?.day ?? 0) + 1;
		const date = s.rules.protocolStartDate ? addDaysISO(s.rules.protocolStartDate, day - 1) : addDaysISO((/* @__PURE__ */ new Date()).toISOString().slice(0, 10), day - 1);
		const next = {
			id: uid("day"),
			day,
			date,
			title: `Custom · Day ${day}`,
			focus: "Write the job for this day.",
			phase: last?.phase ?? 1,
			riskPct: last?.riskPct ?? s.rules.normalRiskPct,
			maxTrades: last?.maxTrades ?? s.rules.maxTrades,
			completed: false,
			skipped: false,
			notes: ""
		};
		return { protocolDays: [...s.protocolDays, next] };
	}),
	closeToday: (date) => set((s) => ({
		forceClosedDates: s.forceClosedDates.includes(date) ? s.forceClosedDates : [...s.forceClosedDates, date],
		forceOpenDates: s.forceOpenDates.filter((d) => d !== date)
	})),
	openToday: (date) => set((s) => ({
		forceOpenDates: s.forceOpenDates.includes(date) ? s.forceOpenDates : [...s.forceOpenDates, date],
		forceClosedDates: s.forceClosedDates.filter((d) => d !== date)
	})),
	rebuildProtocolDates: (startDate) => set((s) => ({
		rules: {
			...s.rules,
			protocolStartDate: startDate
		},
		protocolDays: s.protocolDays.map((d, i) => ({
			...d,
			date: addDaysISO(startDate, (d.day || i + 1) - 1)
		}))
	}))
}), {
	name: "ict-narrative-desk",
	skipHydration: true,
	version: 2,
	migrate: (persistedState, version) => {
		if (version >= 2 || typeof persistedState !== "object" || persistedState === null) return persistedState;
		const state = persistedState;
		if (!state.instruments) return state;
		return {
			...state,
			instruments: state.instruments.map((instrument) => instrument.id === "xau" && instrument.symbol === "XAUUSD" && instrument.tickSize === .01 && instrument.tickValuePerLot === 100 ? {
				...instrument,
				tickValuePerLot: 1
			} : instrument)
		};
	},
	partialize: (state) => ({
		hasBootstrapped: state.hasBootstrapped,
		accountName: state.accountName,
		phaseId: state.phaseId,
		phases: state.phases,
		rules: state.rules,
		mantra: state.mantra,
		instruments: state.instruments,
		models: state.models,
		recentlyDeletedModels: state.recentlyDeletedModels ?? [],
		trades: state.trades,
		missed: state.missed,
		weeklies: state.weeklies,
		dailyPlans: state.dailyPlans,
		liquidity: state.liquidity,
		checklistItems: state.checklistItems,
		checks: state.checks,
		protocolDays: state.protocolDays,
		newsEvents: state.newsEvents,
		forceClosedDates: state.forceClosedDates,
		forceOpenDates: state.forceOpenDates
	})
}));
function deskSnapshot() {
	const state = useDeskStore.getState();
	return {
		hasBootstrapped: state.hasBootstrapped,
		accountName: state.accountName,
		phaseId: state.phaseId,
		phases: state.phases,
		rules: state.rules,
		mantra: state.mantra,
		instruments: state.instruments,
		models: state.models,
		recentlyDeletedModels: state.recentlyDeletedModels ?? [],
		trades: state.trades,
		missed: state.missed,
		weeklies: state.weeklies,
		dailyPlans: state.dailyPlans,
		liquidity: state.liquidity,
		checklistItems: state.checklistItems,
		checks: state.checks,
		protocolDays: state.protocolDays,
		newsEvents: state.newsEvents,
		forceClosedDates: state.forceClosedDates,
		forceOpenDates: state.forceOpenDates
	};
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-down",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted-foreground",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-surface-2", className),
		...props
	});
}
var GUEST_SESSION_KEY = "first-payout-guest-session";
var GUEST_INITIALIZED_KEY = "first-payout-guest-initialized";
function isGuestSession() {
	if (typeof window === "undefined") return false;
	try {
		return window.sessionStorage.getItem(GUEST_SESSION_KEY) === "true";
	} catch (error) {
		console.error("[auth] could not read guest session:", error);
		return false;
	}
}
function startGuestSession() {
	window.sessionStorage.setItem(GUEST_SESSION_KEY, "true");
	window.sessionStorage.removeItem(GUEST_INITIALIZED_KEY);
}
function guestDataWasInitialized() {
	return window.sessionStorage.getItem(GUEST_INITIALIZED_KEY) === "true";
}
function markGuestDataInitialized() {
	window.sessionStorage.setItem(GUEST_INITIALIZED_KEY, "true");
}
function clearGuestSession() {
	window.sessionStorage.removeItem(GUEST_SESSION_KEY);
	window.sessionStorage.removeItem(GUEST_INITIALIZED_KEY);
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton({ collapsed = false }) {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	const canSignOut = !gateSession;
	const avatar = user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: user.profileImageUrl,
		alt: collapsed ? label : "",
		title: collapsed ? label : void 0,
		className: "h-8 w-8 rounded-full object-cover"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		role: collapsed ? "img" : void 0,
		"aria-label": collapsed ? label : void 0,
		title: collapsed ? label : void 0,
		className: "grid h-8 w-8 shrink-0 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
		children: label.charAt(0).toUpperCase()
	});
	const signOutButton = canSignOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled: signingOut,
		"aria-label": signingOut ? "Signing out" : "Sign out",
		title: signingOut ? "Signing out" : "Sign out",
		onClick: () => {
			setSigningOut(true);
			signOut().catch(() => setSigningOut(false));
		},
		className: collapsed ? "grid size-8 place-items-center rounded-lg text-muted-foreground opacity-70 transition hover:bg-white/[0.06] hover:text-foreground disabled:cursor-wait" : "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
		children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, {
			"aria-hidden": "true",
			className: "size-4"
		}) : signingOut ? "Signing out…" : "Sign out"
	}) : null;
	if (collapsed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [avatar, signOutButton]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 items-center gap-2",
		children: [
			avatar,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 truncate text-sm font-medium",
				title: label,
				children: label
			}),
			signOutButton
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function isDeskData(value) {
	if (typeof value !== "object" || value === null) return false;
	const data = value;
	return typeof data.hasBootstrapped === "boolean" && typeof data.accountName === "string" && typeof data.phaseId === "number" && typeof data.rules === "object" && data.rules !== null && Array.isArray(data.phases) && Array.isArray(data.instruments) && Array.isArray(data.models) && (data.recentlyDeletedModels === void 0 || Array.isArray(data.recentlyDeletedModels)) && Array.isArray(data.trades) && Array.isArray(data.missed) && Array.isArray(data.weeklies) && typeof data.dailyPlans === "object" && data.dailyPlans !== null && Array.isArray(data.liquidity) && Array.isArray(data.checklistItems) && typeof data.checks === "object" && data.checks !== null && Array.isArray(data.protocolDays) && Array.isArray(data.newsEvents) && Array.isArray(data.forceClosedDates) && Array.isArray(data.forceOpenDates);
}
var savePayloadSchema = custom(isDeskData, "Invalid desk data").refine((data) => JSON.stringify(data).length <= 1e6, { message: "Desk data exceeds the 1 MB limit" });
var loadDeskState = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9cc0910e1d367feb641e28f5340a5d14b71f26a744fbcc219b7e5cae5795816b"));
var saveDeskState = createServerFn({ method: "POST" }).validator((input) => savePayloadSchema.parse(input)).middleware([authMiddleware]).handler(createSsrRpc("18354d890fcaee1e9770deb489d6433e8a878a6e3d6d5bf9543932f0c650b4c0"));
async function syncDeskToServer() {
	try {
		const { deskSnapshot } = await import("./ict-store-DyasqRdx.mjs");
		return await saveDeskState({ data: deskSnapshot() });
	} catch (error) {
		console.warn("[desk-sync] server sync notice:", error);
		return { saved: false };
	}
}
var DeskSyncContext = (0, import_react.createContext)("local");
function useDeskSyncStatus() {
	return (0, import_react.useContext)(DeskSyncContext);
}
function DeskProvider({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const { user, isPending } = useCurrentUserState();
	const userId = user?.id ?? null;
	const guestSession = !userId && isGuestSession();
	const [localReady, setLocalReady] = (0, import_react.useState)(false);
	const [loadedUserId, setLoadedUserId] = (0, import_react.useState)(null);
	const [syncStatus, setSyncStatus] = (0, import_react.useState)("loading");
	const [loadError, setLoadError] = (0, import_react.useState)(null);
	const [retryCount, setRetryCount] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		{
			if (isPending) return;
			if (!userId) {
				if (!guestSession) return;
				let cancelled = false;
				setSyncStatus("local");
				(async () => {
					try {
						if (guestDataWasInitialized()) {
							await useDeskStore.persist.rehydrate();
							if (cancelled) return;
							const state = useDeskStore.getState();
							const normalized = ensureMinimumDeskData(state);
							if (normalized !== state) useDeskStore.getState().replaceAll(normalized);
						} else {
							useDeskStore.getState().replaceAll(ensureMinimumDeskData(createInitialState()));
							markGuestDataInitialized();
						}
						if (!cancelled) setLocalReady(true);
					} catch (error) {
						if (cancelled) return;
						console.error("[desk-sync] failed to initialize local demo:", error);
						toast.error("Could not open the local demo desk.");
					}
				})();
				return () => {
					cancelled = true;
				};
			}
			let cancelled = false;
			setSyncStatus("loading");
			setLoadError(null);
			try {
				clearGuestSession();
			} catch (error) {
				console.error("[auth] could not clear guest session after sign-in:", error);
			}
			(async () => {
				try {
					const remoteState = await loadDeskState();
					if (cancelled) return;
					const state = ensureMinimumDeskData(remoteState ?? createInitialState());
					useDeskStore.getState().replaceAll(state);
					if (!remoteState || state !== remoteState) await saveDeskState({ data: deskSnapshot() });
					if (cancelled) return;
					setLoadedUserId(userId);
					setSyncStatus("saved");
				} catch (error) {
					if (cancelled) return;
					console.error("[desk-sync] failed to load desk data:", error);
					const message = error instanceof Error ? error.message : "Could not connect to secure storage.";
					setLoadError({
						userId,
						message
					});
					setSyncStatus("error");
				}
			})();
			return () => {
				cancelled = true;
			};
		}
	}, [
		userId,
		isPending,
		retryCount,
		guestSession
	]);
	(0, import_react.useEffect)(() => {
		if (!userId || loadedUserId !== userId) return;
		let timer;
		let cancelled = false;
		let saveQueue = Promise.resolve();
		const unsubscribe = useDeskStore.subscribe(() => {
			if (timer) clearTimeout(timer);
			setSyncStatus("saving");
			timer = setTimeout(() => {
				const snapshot = deskSnapshot();
				saveQueue = saveQueue.catch(() => void 0).then(async () => {
					await saveDeskState({ data: snapshot });
					if (!cancelled) setSyncStatus("saved");
				}).catch((error) => {
					if (cancelled) return;
					console.error("[desk-sync] failed to save desk data:", error);
					setSyncStatus("error");
					toast.error("Could not sync your latest changes. Check your connection and try again.");
				});
			}, 400);
		});
		return () => {
			cancelled = true;
			if (timer) clearTimeout(timer);
			unsubscribe();
		};
	}, [userId, loadedUserId]);
	const isLoginRoute = pathname === "/login";
	const isReady = userId ? loadedUserId === userId : isLoginRoute || guestSession && localReady;
	const currentLoadError = userId && loadError?.userId === userId ? loadError : null;
	let content;
	if (isPending) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDesk, {});
	else if (!user && !isLoginRoute && !guestSession) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	else if (currentLoadError) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-background p-6 text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "w-full max-w-md rounded-2xl border border-down/25 bg-card/80 p-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: "Desk sync unavailable"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Your private desk could not be loaded from the backend."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 break-words text-xs text-down/90",
					children: currentLoadError.message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5",
					onClick: () => setRetryCount((count) => count + 1),
					children: "Retry connection"
				})
			]
		})
	});
	else if (!isReady) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingDesk, {});
	else content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [guestSession ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-center gap-x-2 gap-y-1 border-b border-warn/25 bg-warn/[0.07] px-4 py-2 text-center text-[11px] text-warn",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Demo mode · saved only in this browser; cloud sync is off." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "/login",
			className: "font-semibold underline underline-offset-2",
			children: "Sign in to sync your private desk"
		})]
	}) : null, children] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskSyncContext.Provider, {
		value: syncStatus,
		children: content
	});
}
function LoadingDesk() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh bg-background p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl text-foreground",
					children: "First Payout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Connecting your private desk…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-48" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })
			]
		})
	});
}
var TooltipProvider = Provider;
var styles_default = "/assets/styles-Gr1M7x56.css";
var APP_NAME = "First Payout";
var Route$11 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0d0b"
			},
			{
				name: "description",
				content: "ICT market narrative and execution research desk with a funded-account payout protocol."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
				delayDuration: 200,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-right"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$8 = () => import("./routes-Cn3bejRg.mjs");
var Route$10 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./analytics-CXCX0qZk.mjs");
var Route$9 = createFileRoute("/analytics")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./daily-C8sc_yNE.mjs");
var Route$8 = createFileRoute("/daily")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./journal-ARL0ldVZ.mjs");
var Route$7 = createFileRoute("/journal")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./login-B_y6q5RJ.mjs");
var Route$6 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./playbook-C9XzNpZl.mjs");
var Route$5 = createFileRoute("/playbook")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./protocol-Cfibi3Hx.mjs");
var Route$4 = createFileRoute("/protocol")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./replay-kSOX87Tx.mjs");
var Route$3 = createFileRoute("/replay")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./weekly-Bg_laWeu.mjs");
var Route$2 = createFileRoute("/weekly")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var ID_SCHEMA = string().min(1).max(64).regex(/^[a-zA-Z0-9_-]{1,64}$/, "ID must contain 1-64 alphanumeric, dash, or underscore characters");
var SignalKindSchema = _enum([
	"offer",
	"answer",
	"ice"
]);
/** Payload size limit (32KB). SDP offers/answers are usually 3-10KB. */
var MAX_SIGNAL_PAYLOAD_BYTES = 32768;
var SignalOpSchema = object({
	op: literal("signal"),
	room: ID_SCHEMA,
	from: ID_SCHEMA,
	to: ID_SCHEMA,
	kind: SignalKindSchema,
	payload: unknown().refine((v) => {
		if (v === void 0) return false;
		try {
			return JSON.stringify(v).length <= MAX_SIGNAL_PAYLOAD_BYTES;
		} catch {
			return false;
		}
	}, { message: "payload must be valid JSON and <= 32KB" })
});
var LeaveOpSchema = object({
	op: literal("leave"),
	room: ID_SCHEMA,
	peer: ID_SCHEMA
});
var PostOpSchema = discriminatedUnion("op", [SignalOpSchema, LeaveOpSchema]);
var PollQuerySchema = object({
	room: ID_SCHEMA,
	peer: ID_SCHEMA,
	name: string().max(64).default(""),
	since: number$1().int().min(0).default(0)
});
var globalRef = globalThis;
/**
* Ensures required database tables and indexes exist on first use.
* Memoized across HMR reloads on globalThis.
*/
function ensureSchema(sql) {
	globalRef.__rtcSchemaPromise__ ??= (async () => {
		await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_peers (
         room TEXT NOT NULL,
         peer_id TEXT NOT NULL,
         name TEXT NOT NULL DEFAULT '',
         last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
         PRIMARY KEY (room, peer_id)
       );`);
		await sql.query(`CREATE INDEX IF NOT EXISTS webrtc_peers_lookup
         ON webrtc_peers (room, last_seen);`);
		await sql.query(`CREATE TABLE IF NOT EXISTS webrtc_signals (
         id BIGSERIAL PRIMARY KEY,
         room TEXT NOT NULL,
         to_peer TEXT NOT NULL,
         from_peer TEXT NOT NULL,
         kind TEXT NOT NULL,
         payload JSONB NOT NULL,
         created_at TIMESTAMPTZ NOT NULL DEFAULT now()
       );`);
		await sql.query(`CREATE INDEX IF NOT EXISTS webrtc_signals_inbox
         ON webrtc_signals (room, to_peer, id);`);
		await sql.query(`CREATE INDEX IF NOT EXISTS webrtc_signals_created_at
         ON webrtc_signals (created_at);`);
	})().catch((err) => {
		globalRef.__rtcSchemaPromise__ = void 0;
		throw err;
	});
	return globalRef.__rtcSchemaPromise__;
}
var MemoryStore = class {
	peers = /* @__PURE__ */ new Map();
	signals = [];
	nextSignalId = 1;
	touchPeer(room, peerId, name) {
		let roomPeers = this.peers.get(room);
		if (!roomPeers) {
			roomPeers = /* @__PURE__ */ new Map();
			this.peers.set(room, roomPeers);
		}
		roomPeers.set(peerId, {
			id: peerId,
			name,
			lastSeen: Date.now()
		});
	}
	getRoster(room, ttlMs = 3e4) {
		const roomPeers = this.peers.get(room);
		if (!roomPeers) return [];
		const now = Date.now();
		const active = [];
		for (const [id, peer] of roomPeers.entries()) if (now - peer.lastSeen <= ttlMs) active.push({
			id: peer.id,
			name: peer.name
		});
		else roomPeers.delete(id);
		return active.sort((a, b) => a.id.localeCompare(b.id)).slice(0, 32);
	}
	removePeer(room, peerId) {
		const roomPeers = this.peers.get(room);
		if (roomPeers) {
			roomPeers.delete(peerId);
			if (roomPeers.size === 0) this.peers.delete(room);
		}
	}
	pushSignal(room, from, to, kind, payload) {
		this.signals.push({
			id: this.nextSignalId++,
			room,
			from,
			to,
			kind,
			payload,
			createdAt: Date.now()
		});
	}
	pollSignals(room, peerId, since) {
		return this.signals.filter((s) => s.room === room && s.to === peerId && s.id > since).slice(0, 200).map((s) => ({
			id: s.id,
			from: s.from,
			kind: s.kind,
			payload: s.payload
		}));
	}
	prune(ttlPeerMs = 3e4, ttlSignalMs = 6e4) {
		const now = Date.now();
		for (const [room, roomPeers] of this.peers.entries()) {
			for (const [id, peer] of roomPeers.entries()) if (now - peer.lastSeen > ttlPeerMs) roomPeers.delete(id);
			if (roomPeers.size === 0) this.peers.delete(room);
		}
		this.signals = this.signals.filter((s) => now - s.createdAt <= ttlSignalMs);
	}
	getStats(room) {
		const roster = this.getRoster(room);
		const roomSignals = this.signals.filter((s) => s.room === room);
		return {
			room,
			peerCount: roster.length,
			activeSignals: roomSignals.length,
			lastActivity: roomSignals.length > 0 ? new Date(roomSignals[roomSignals.length - 1].createdAt) : null
		};
	}
};
var memStore = new MemoryStore();
async function getSqlWithSchema() {
	const sql = await getSql();
	await ensureSchema(sql);
	return sql;
}
async function touchPeer(room, peerId, name) {
	try {
		await (await getSqlWithSchema()).query(`INSERT INTO webrtc_peers (room, peer_id, name, last_seen)
       VALUES ($1, $2, $3, now())
       ON CONFLICT (room, peer_id)
       DO UPDATE SET last_seen = now(), name = EXCLUDED.name`, [
			room,
			peerId,
			name
		]);
	} catch (err) {
		console.warn("[multiplayer/store] Database touchPeer fallback to memory:", err);
		memStore.touchPeer(room, peerId, name);
	}
}
async function getRoster(room, ttlSeconds = 30) {
	try {
		return (await (await getSqlWithSchema()).query(`SELECT peer_id, name FROM webrtc_peers
       WHERE room = $1 AND last_seen > now() - make_interval(secs => $2)
       ORDER BY peer_id LIMIT 32`, [room, ttlSeconds])).map((r) => ({
			id: r.peer_id,
			name: r.name
		}));
	} catch (err) {
		console.warn("[multiplayer/store] Database getRoster fallback to memory:", err);
		return memStore.getRoster(room, ttlSeconds * 1e3);
	}
}
async function removePeer(room, peerId) {
	try {
		await (await getSqlWithSchema()).query(`DELETE FROM webrtc_peers WHERE room = $1 AND peer_id = $2`, [room, peerId]);
	} catch (err) {
		console.warn("[multiplayer/store] Database removePeer fallback to memory:", err);
		memStore.removePeer(room, peerId);
	}
}
async function pushSignal(room, from, to, kind, payload) {
	try {
		await (await getSqlWithSchema()).query(`INSERT INTO webrtc_signals (room, to_peer, from_peer, kind, payload)
       VALUES ($1, $2, $3, $4, $5)`, [
			room,
			to,
			from,
			kind,
			JSON.stringify(payload)
		]);
	} catch (err) {
		console.warn("[multiplayer/store] Database pushSignal fallback to memory:", err);
		memStore.pushSignal(room, from, to, kind, payload);
	}
}
async function pollSignals(room, peerId, since) {
	try {
		return (await (await getSqlWithSchema()).query(`SELECT id, from_peer, kind, payload FROM webrtc_signals
       WHERE room = $1 AND to_peer = $2 AND id > $3
       ORDER BY id LIMIT 200`, [
			room,
			peerId,
			since
		])).map((r) => ({
			id: r.id,
			from: r.from_peer,
			kind: r.kind,
			payload: r.payload
		}));
	} catch (err) {
		console.warn("[multiplayer/store] Database pollSignals fallback to memory:", err);
		return memStore.pollSignals(room, peerId, since);
	}
}
async function pruneStale(ttlPeerSecs = 30, ttlSignalSecs = 60) {
	try {
		const sql = await getSqlWithSchema();
		await Promise.all([sql.query(`DELETE FROM webrtc_signals WHERE created_at < now() - make_interval(secs => $1)`, [ttlSignalSecs]), sql.query(`DELETE FROM webrtc_peers WHERE last_seen < now() - make_interval(secs => $1)`, [ttlPeerSecs])]);
	} catch (err) {
		console.warn("[multiplayer/store] Database prune fallback to memory:", err);
		memStore.prune(ttlPeerSecs * 1e3, ttlSignalSecs * 1e3);
	}
}
function jsonResponse(body, status = 200) {
	return new Response(JSON.stringify(body), {
		status,
		headers: {
			"content-type": "application/json; charset=utf-8",
			"cache-control": "no-store, no-cache, must-revalidate"
		}
	});
}
/**
* Handles GET /api/rtc?room&peer&name&since
* Used for:
* 1. Joining a room (since=0)
* 2. Heartbeat to keep peer alive in roster
* 3. Polling incoming signals (offer, answer, ICE candidates)
*/
async function handleGet(url) {
	const parsed = PollQuerySchema.safeParse({
		room: url.searchParams.get("room"),
		peer: url.searchParams.get("peer"),
		name: url.searchParams.get("name") ?? "",
		since: url.searchParams.get("since") ?? 0
	});
	if (!parsed.success) return jsonResponse({
		error: "invalid query parameters",
		details: parsed.error.flatten().fieldErrors
	}, 400);
	const { room, peer, name, since } = parsed.data;
	if (since === 0 || Math.random() < .02) await pruneStale();
	await touchPeer(room, peer, name);
	const [peers, signals] = await Promise.all([getRoster(room), pollSignals(room, peer, since)]);
	return jsonResponse({
		peers,
		signals
	});
}
/**
* Handles POST /api/rtc
* Used for:
* 1. op: "signal" - send WebRTC offer, answer, or ICE candidate to a specific remote peer
* 2. op: "leave" - remove peer from the active room roster immediately
*/
async function handlePost(request) {
	let body;
	try {
		body = await request.json();
	} catch {
		return jsonResponse({ error: "malformed JSON body" }, 400);
	}
	const parsed = PostOpSchema.safeParse(body);
	if (!parsed.success) return jsonResponse({
		error: "invalid request payload",
		details: parsed.error.flatten().fieldErrors
	}, 400);
	const msg = parsed.data;
	if (msg.op === "signal") {
		await pushSignal(msg.room, msg.from, msg.to, msg.kind, msg.payload);
		return jsonResponse({ ok: true });
	}
	if (msg.op === "leave") {
		await removePeer(msg.room, msg.peer);
		return jsonResponse({ ok: true });
	}
	return jsonResponse({ error: "unhandled operation" }, 400);
}
/**
* Main request router for /api/rtc signaling endpoint.
*/
async function handleSignaling(request) {
	try {
		if (request.method === "OPTIONS") return new Response(null, {
			status: 204,
			headers: {
				"allow": "GET, POST, OPTIONS",
				"access-control-allow-methods": "GET, POST, OPTIONS",
				"access-control-allow-headers": "content-type"
			}
		});
		if (request.method === "GET") return await handleGet(new URL(request.url));
		if (request.method === "POST") return await handlePost(request);
		return jsonResponse({ error: `method ${request.method} not allowed` }, 405);
	} catch (error) {
		console.error("[rtc/signaling] Unexpected error in signaling handler:", error);
		return jsonResponse({ error: "internal signaling relay error" }, 500);
	}
}
var handle = ({ request }) => handleSignaling(request);
var Route$1 = createFileRoute("/api/rtc")({ server: { handlers: {
	GET: handle,
	POST: handle
} } });
var Route = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var rootRouteChildren = {
	IndexRoute: Route$10.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$11
	}),
	AnalyticsRoute: Route$9.update({
		id: "/analytics",
		path: "/analytics",
		getParentRoute: () => Route$11
	}),
	DailyRoute: Route$8.update({
		id: "/daily",
		path: "/daily",
		getParentRoute: () => Route$11
	}),
	JournalRoute: Route$7.update({
		id: "/journal",
		path: "/journal",
		getParentRoute: () => Route$11
	}),
	LoginRoute: Route$6.update({
		id: "/login",
		path: "/login",
		getParentRoute: () => Route$11
	}),
	PlaybookRoute: Route$5.update({
		id: "/playbook",
		path: "/playbook",
		getParentRoute: () => Route$11
	}),
	ProtocolRoute: Route$4.update({
		id: "/protocol",
		path: "/protocol",
		getParentRoute: () => Route$11
	}),
	ReplayRoute: Route$3.update({
		id: "/replay",
		path: "/replay",
		getParentRoute: () => Route$11
	}),
	WeeklyRoute: Route$2.update({
		id: "/weekly",
		path: "/weekly",
		getParentRoute: () => Route$11
	}),
	ApiRtcRoute: Route$1.update({
		id: "/api/rtc",
		path: "/api/rtc",
		getParentRoute: () => Route$11
	}),
	ApiAuthSplatRoute: Route.update({
		id: "/api/auth/$",
		path: "/api/auth/$",
		getParentRoute: () => Route$11
	})
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { TRIGGERS as A, inWindow as B, MANAGEMENT as C, SESSIONS as D, PD_ARRAYS as E, addDaysISO as F, uid as G, parseNum as H, cn as I, weekStartISO as K, formatMoney as L, buttonVariants as M, useCurrentUserState as N, TIMEFRAMES as O, TRADING_TZ as P, formatPct as R, LIQUIDITY_TYPES as S, MISS_REASONS as T, todayISO as U, nowHHMM as V, todayISO$1 as W, DRAWS as _, syncDeskToServer as a, EXIT_REASONS as b, deskSnapshot as c, defaultPlanFrom as d, emptyMissed as f, DELIVERIES as g, AMD_PHASES as h, saveDeskState as i, Button as j, TIME_MODELS as k, useDeskStore as l, emptyWeekly as m, useDeskSyncStatus as n, UserButton as o, emptyTrade as p, weekdayShort as q, isDeskData as r, startGuestSession as s, router_exports as t, createResetState as u, EMOTIONS as v, MISS_OUTCOMES as w, KILL_ZONES as x, ERRORS as y, formatR as z };
