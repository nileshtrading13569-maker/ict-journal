import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { M as custom } from "../_libs/@better-auth/core+[...].mjs";
import { i as getSql, t as authMiddleware } from "./middleware-B9Dz24Ph.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desk-sync-D-w4gRD2.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function isDeskData(value) {
	if (typeof value !== "object" || value === null) return false;
	const data = value;
	return typeof data.hasBootstrapped === "boolean" && typeof data.accountName === "string" && typeof data.phaseId === "number" && typeof data.rules === "object" && data.rules !== null && Array.isArray(data.phases) && Array.isArray(data.instruments) && Array.isArray(data.models) && (data.recentlyDeletedModels === void 0 || Array.isArray(data.recentlyDeletedModels)) && Array.isArray(data.trades) && Array.isArray(data.missed) && Array.isArray(data.weeklies) && typeof data.dailyPlans === "object" && data.dailyPlans !== null && Array.isArray(data.liquidity) && Array.isArray(data.checklistItems) && typeof data.checks === "object" && data.checks !== null && Array.isArray(data.protocolDays) && Array.isArray(data.newsEvents) && Array.isArray(data.forceClosedDates) && Array.isArray(data.forceOpenDates);
}
var savePayloadSchema = custom(isDeskData, "Invalid desk data").refine((data) => JSON.stringify(data).length <= 1e6, { message: "Desk data exceeds the 1 MB limit" });
var loadDeskState_createServerFn_handler = createServerRpc({
	id: "9cc0910e1d367feb641e28f5340a5d14b71f26a744fbcc219b7e5cae5795816b",
	name: "loadDeskState",
	filename: "src/lib/desk-sync.ts"
}, (opts) => loadDeskState.__executeServer(opts));
var loadDeskState = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(loadDeskState_createServerFn_handler, async ({ context }) => {
	const rows = await (await getSql())`
      select state
      from user_desk_state
      where user_id = ${context.userId}
      limit 1
    `;
	if (!rows[0]) return null;
	if (!isDeskData(rows[0].state)) throw new Error("Stored desk state is invalid");
	return rows[0].state;
});
var saveDeskState_createServerFn_handler = createServerRpc({
	id: "18354d890fcaee1e9770deb489d6433e8a878a6e3d6d5bf9543932f0c650b4c0",
	name: "saveDeskState",
	filename: "src/lib/desk-sync.ts"
}, (opts) => saveDeskState.__executeServer(opts));
var saveDeskState = createServerFn({ method: "POST" }).validator((input) => savePayloadSchema.parse(input)).middleware([authMiddleware]).handler(saveDeskState_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into user_desk_state (user_id, state, updated_at)
      values (${context.userId}, ${JSON.stringify(data)}::jsonb, now())
      on conflict (user_id)
      do update set state = excluded.state, updated_at = now()
    `;
	return { saved: true };
});
//#endregion
export { loadDeskState_createServerFn_handler, saveDeskState_createServerFn_handler };
