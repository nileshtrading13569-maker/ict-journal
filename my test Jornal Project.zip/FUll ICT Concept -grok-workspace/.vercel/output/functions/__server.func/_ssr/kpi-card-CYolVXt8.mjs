import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as cn } from "./router-CdjogOIb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kpi-card-CYolVXt8.js
var import_jsx_runtime = require_jsx_runtime();
function KpiCard({ label, value, hint, icon: Icon, variant = "default", className }) {
	const tone = variant === "up" ? "text-up" : variant === "down" ? "text-down" : variant === "warn" ? "text-warn" : "text-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("group relative overflow-hidden rounded-xl border border-white/[0.09] bg-card/85 p-4 transition-all duration-300 ease-[var(--ease-cinema)] before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-white/25 before:to-transparent hover:-translate-y-0.5 hover:border-white/[0.2] hover:bg-surface-2/80 sm:p-5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-semibold tracking-[0.16em] text-muted-foreground uppercase",
					children: label
				}), Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-6 items-center justify-center rounded-sm border border-white/[0.08] text-muted-foreground transition-colors group-hover:border-accent/40 group-hover:text-accent",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 font-mono text-2xl font-bold tracking-tight tabular-nums sm:text-3xl", tone),
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2.5 flex items-center gap-1.5 border-t border-white/[0.05] pt-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-block size-1 rounded-full", variant === "up" ? "bg-up" : variant === "down" ? "bg-down" : "bg-accent") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-[11px] font-medium text-subtle",
					children: hint
				})]
			})
		]
	});
}
//#endregion
export { KpiCard as t };
