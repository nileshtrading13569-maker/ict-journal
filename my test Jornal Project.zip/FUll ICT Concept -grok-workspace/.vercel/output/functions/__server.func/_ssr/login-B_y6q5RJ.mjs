import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as signIn, t as authClient } from "./client-B40BzJxt.mjs";
import { t as GROK_PROVIDERS } from "./server-C59QZTrp.mjs";
import { $ as ArrowRight, f as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { N as useCurrentUserState, j as Button, s as startGuestSession } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-B_y6q5RJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	const navigate = useNavigate();
	const [pendingProvider, setPendingProvider] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("sign-in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-background p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Checking secure session…"
		})
	});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	const beginSignIn = async (providerId) => {
		setPendingProvider(providerId);
		try {
			await signIn(providerId, { callbackURL: "/" });
		} catch (error) {
			console.error("[auth] sign-in failed:", error);
			toast.error(error instanceof Error ? error.message : "Sign-in failed. Please try again.");
			setPendingProvider(null);
		}
	};
	const submitEmail = async (event) => {
		event.preventDefault();
		setPendingProvider("email");
		try {
			const result = mode === "sign-up" ? await authClient.signUp.email({
				name: name.trim(),
				email: email.trim(),
				password
			}) : await authClient.signIn.email({
				email: email.trim(),
				password
			});
			if (result.error) throw new Error(result.error.message ?? "Authentication failed.");
			const session = await authClient.getSession();
			if (session.error || !session.data?.user) throw new Error(session.error?.message ?? "Your session could not be started.");
			await navigate({ to: "/" });
		} catch (error) {
			console.error("[auth] email authentication failed:", error);
			toast.error(error instanceof Error ? error.message : "Could not authenticate. Please try again.");
		} finally {
			setPendingProvider(null);
		}
	};
	const skipSignIn = async () => {
		try {
			startGuestSession();
			await navigate({ to: "/" });
		} catch (error) {
			console.error("[auth] could not start local demo session:", error);
			toast.error("Could not start guest mode. Check browser storage settings and try again.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative grid min-h-dvh place-items-center overflow-hidden bg-background p-5 text-foreground sm:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(229,9,20,0.18),transparent_58%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative w-full max-w-md overflow-hidden rounded-2xl border border-white/[0.1] bg-card/85 p-6 shadow-[0_40px_120px_-40px_rgba(0,0,0,1)] before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-accent/70 before:to-transparent sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-sm bg-accent text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none",
						children: "First Payout"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[10px] font-semibold tracking-[0.2em] text-accent uppercase",
						children: "Private ICT desk"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-semibold tracking-[0.18em] text-muted-foreground uppercase",
					children: "Secure workspace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl leading-tight",
					children: "Your desk, synced."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "Sign in to access your private trade journal, account rules, and daily plans across sessions."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-7 space-y-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex rounded-xl border border-white/[0.08] bg-black/20 p-1",
							children: ["sign-in", "sign-up"].map((nextMode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(nextMode),
								className: `h-9 flex-1 rounded-lg text-xs font-medium transition ${mode === nextMode ? "bg-white/[0.08] text-foreground" : "text-muted-foreground hover:text-foreground"}`,
								children: nextMode === "sign-in" ? "Sign in" : "Create account"
							}, nextMode))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (event) => void submitEmail(event),
							className: "space-y-3",
							children: [
								mode === "sign-up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									autoComplete: "name",
									value: name,
									onChange: (event) => setName(event.target.value),
									placeholder: "Full name",
									required: true
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									autoComplete: "email",
									value: email,
									onChange: (event) => setEmail(event.target.value),
									placeholder: "Email address",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									autoComplete: mode === "sign-up" ? "new-password" : "current-password",
									minLength: 8,
									value: password,
									onChange: (event) => setPassword(event.target.value),
									placeholder: "Password (at least 8 characters)",
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									className: "h-11 w-full justify-between rounded-xl px-4",
									disabled: pendingProvider !== null,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pendingProvider === "email" ? "Connecting…" : mode === "sign-up" ? "Create private account" : "Sign in with email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 py-1 text-[10px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-white/[0.08]" }),
								"or continue with",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-white/[0.08]" })
							]
						}),
						GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "h-11 w-full justify-between rounded-xl border-white/[0.12] bg-white/[0.03] px-4 hover:border-accent/40 hover:bg-accent/[0.06]",
							disabled: pendingProvider !== null,
							onClick: () => void beginSignIn(provider.providerId),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pendingProvider === provider.providerId ? "Connecting…" : `Continue with ${provider.label}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-accent" })]
						}, provider.providerId)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 py-1 text-[10px] font-medium tracking-[0.16em] text-muted-foreground uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-white/[0.08]" }),
								"or explore first",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-white/[0.08]" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "h-11 w-full justify-center rounded-xl border-white/[0.12] bg-white/[0.03]",
							disabled: pendingProvider !== null,
							onClick: () => void skipSignIn(),
							children: "Skip sign-in · Explore demo"
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-center text-xs text-muted-foreground/75",
					children: "Demo mode stays in this browser and does not sync. Sign in to access your private desk."
				})
			]
		})]
	});
}
//#endregion
export { LoginPage as component };
