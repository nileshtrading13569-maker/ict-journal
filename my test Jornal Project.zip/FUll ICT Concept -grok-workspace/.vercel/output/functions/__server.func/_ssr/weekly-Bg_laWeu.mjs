import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { K as weekStartISO, S as LIQUIDITY_TYPES, W as todayISO$1, _ as DRAWS, j as Button, l as useDeskStore, m as emptyWeekly } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { N as dealingMeta, R as fmtPx, S as RangeBar, b as NumField, i as Chips, n as Badge, t as AppShell, w as Textarea, x as Panel, y as Field } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/weekly-Bg_laWeu.js
var import_jsx_runtime = require_jsx_runtime();
function one(v) {
	return Array.isArray(v) ? v[0] : v;
}
function WeeklyPage() {
	const weeklies = useDeskStore((s) => s.weeklies);
	const upsert = useDeskStore((s) => s.upsertWeekly);
	const today = todayISO$1();
	const start = weekStartISO(today);
	const current = weeklies.find((w) => w.weekStart === start) ?? weeklies[0];
	const others = weeklies.filter((w) => w.id !== current?.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Weekly map",
			title: "Where is the draw?",
			description: "Daily bias sits inside the weekly profile. Mark the dealing range, name the liquidity, then write what price must do first.",
			aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: ["Week of ", start]
			})
		}),
		current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {
			week: current,
			onSave: upsert
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => upsert(emptyWeekly(start)),
			children: "Create this week"
		}),
		others.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted-foreground uppercase",
				children: "Prior weeks"
			}), others.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: `${w.weekStart} · ${w.structure}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						w.primaryDraw,
						" draw. ",
						w.beforeDraw
					]
				})
			}, w.id))]
		}) : null
	] });
}
function Editor({ week, onSave }) {
	const meta = dealingMeta(week.dealingRange);
	function patch(partial) {
		onSave({
			...week,
			...partial
		});
	}
	function patchLiq(type, next) {
		patch({ liquidity: week.liquidity.some((l) => l.type === type) ? week.liquidity.map((l) => l.type === type ? {
			...l,
			...next
		} : l) : [...week.liquidity, {
			type,
			price: null,
			status: "untouched",
			...next
		}] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: week.market,
				title: "Weekly dealing range",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Week open",
							value: week.dealingRange.open ?? null,
							onChange: (n) => patch({ dealingRange: {
								...week.dealingRange,
								open: n
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "PWH / high",
							value: week.dealingRange.high,
							onChange: (n) => patch({ dealingRange: {
								...week.dealingRange,
								high: n
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "PWL / low",
							value: week.dealingRange.low,
							onChange: (n) => patch({ dealingRange: {
								...week.dealingRange,
								low: n
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Close",
							value: week.dealingRange.close ?? null,
							onChange: (n) => patch({ dealingRange: {
								...week.dealingRange,
								close: n
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Current",
							value: week.dealingRange.current ?? null,
							onChange: (n) => patch({ dealingRange: {
								...week.dealingRange,
								current: n
							} })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Midpoint",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "flex h-11 items-center font-mono",
								children: fmtPx(meta.eq)
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeBar, { range: week.dealingRange })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Structure",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "HTF structure",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"bullish",
							"bearish",
							"consolidation",
							"expansion",
							"reversal"
						],
						value: week.structure,
						onChange: (v) => patch({ structure: one(v) })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Weekly profile",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"normal",
								"expansion",
								"reversal",
								"consolidation",
								"double-distribution"
							],
							value: week.profile,
							onChange: (v) => patch({ profile: one(v) })
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Weekly liquidity",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: [
						"PWH",
						"PWL",
						"EQH",
						"EQL",
						"BSL",
						"SSL"
					].map((type) => {
						const row = week.liquidity.find((l) => l.type === type);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[4.5rem_1fr_auto] items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium",
									children: type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "decimal",
									value: row?.price ?? "",
									onChange: (e) => patchLiq(type, { price: e.target.value === "" ? null : Number(e.target.value) })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-9 rounded-full px-3 text-xs shadow-border",
									onClick: () => patchLiq(type, { status: row?.status === "taken" ? "untouched" : "taken" }),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: row?.status === "taken" ? "down" : "up",
										children: row?.status === "taken" ? "taken" : "untouched"
									})
								})
							]
						}, type);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Draw on liquidity",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Primary draw",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: DRAWS,
							value: week.primaryDraw,
							onChange: (v) => patch({ primaryDraw: one(v) })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Secondary draw",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: DRAWS,
								value: week.secondaryDraw,
								onChange: (v) => patch({ secondaryDraw: one(v) })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What must price do first?",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: week.beforeDraw,
								onChange: (e) => patch({ beforeDraw: e.target.value }),
								placeholder: "PWL is the external draw. Before it, raid Asia/PDL and rebalance a 1H bearish FVG."
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Weekly review",
							hint: "Record your strongest execution, rule breaks, and one adjustment for next week.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: week.notes,
								onChange: (e) => patch({ notes: e.target.value }),
								placeholder: "What was repeatable? Where did I break rules? What is next week's focus?",
								rows: 4
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle",
				children: [
					"Autosaved. Extra types: ",
					LIQUIDITY_TYPES.length,
					" liquidity objects in the journal."
				]
			})
		]
	});
}
//#endregion
export { WeeklyPage as component };
