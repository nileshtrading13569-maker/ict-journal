import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { G as Check, X as CalendarClock, a as TriangleAlert, b as Plus, c as Target, k as Flame, p as ShieldAlert, r as Wallet, s as Trash2, y as Quote } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { F as addDaysISO, G as uid, I as cn, L as formatMoney, R as formatPct, U as todayISO, V as nowHHMM, j as Button, l as useDeskStore, z as formatR } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { $ as tradesOn, B as lockInfo, C as Switch, D as biasConfidence, K as protocolDayNumber, S as RangeBar, U as payoutProgress, W as planFor, Y as sumPnlPct, Z as todayProtocol, a as ConfirmDelete, c as DialogDescription, d as DialogTitle, et as weeklyFor, j as currentBalance, n as Badge, o as Dialog, q as remainingRToDanger, s as DialogContent, t as AppShell, u as DialogHeader, x as Panel, y as Field } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
import { t as KpiCard } from "./kpi-card-CYolVXt8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cn3bejRg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Progress({ value = 0, className }) {
	const v = Math.min(100, Math.max(0, value));
	const danger = v > 80;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "progressbar",
		"aria-valuenow": Math.round(v),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		className: cn("relative h-1 w-full overflow-hidden rounded-full bg-white/[0.07]", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("h-full rounded-full transition-all duration-300 ease-[var(--ease-cinema)]", danger ? "bg-gradient-to-r from-warn to-accent shadow-[0_0_10px_rgba(229,9,20,0.45)]" : "bg-accent shadow-[0_0_10px_rgba(229,9,20,0.35)]"),
			style: { width: `${v}%` }
		})
	});
}
function buildActivityCalendar({ endDate, weeks = 26, coreChecklistIds, checks, trades }) {
	const weekCount = Number.isFinite(weeks) ? Math.max(1, Math.floor(weeks)) : 26;
	const endWeekday = (/* @__PURE__ */ new Date(`${endDate}T00:00:00.000Z`)).getUTCDay();
	const lastDate = addDaysISO(endDate, 6 - endWeekday);
	const firstDate = addDaysISO(lastDate, 1 - weekCount * 7);
	const coreIds = new Set(coreChecklistIds);
	const tradesByDate = /* @__PURE__ */ new Map();
	for (const trade of trades) {
		const day = tradesByDate.get(trade.date) ?? {
			count: 0,
			netR: 0
		};
		day.count += 1;
		if (trade.result !== "open" && typeof trade.rMultiple === "number" && Number.isFinite(trade.rMultiple)) day.netR += trade.rMultiple;
		tradesByDate.set(trade.date, day);
	}
	return Array.from({ length: weekCount }, (_, weekIndex) => Array.from({ length: 7 }, (_, dayIndex) => {
		const date = addDaysISO(firstDate, weekIndex * 7 + dayIndex);
		const isFuture = date > endDate;
		const checkedIds = new Set(checks[date] ?? []);
		const checked = isFuture ? 0 : [...coreIds].filter((id) => checkedIds.has(id)).length;
		const activity = isFuture ? void 0 : tradesByDate.get(date);
		const total = coreIds.size;
		const progressLevel = total > 0 ? Math.ceil(checked / total * 4) : 0;
		const level = Math.min(4, Math.max(progressLevel, activity?.count ? 1 : 0));
		return {
			date,
			checked,
			total,
			trades: activity?.count ?? 0,
			netR: activity?.netR ?? 0,
			level,
			isFuture
		};
	}));
}
var WEEKDAYS = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
var LEVEL_STYLES = [
	"bg-white/[0.04]",
	"bg-accent/25",
	"bg-accent/45",
	"bg-accent/70",
	"bg-accent"
];
function formatCalendarDate(date, options) {
	return new Intl.DateTimeFormat("en-US", {
		...options,
		timeZone: "UTC"
	}).format(/* @__PURE__ */ new Date(`${date}T12:00:00.000Z`));
}
function dayDescription(day) {
	const tradeLabel = `${day.trades} trade${day.trades === 1 ? "" : "s"}`;
	const result = day.trades ? `, ${formatR(day.netR)} realized` : "";
	return `${formatCalendarDate(day.date, {
		month: "short",
		day: "numeric",
		year: "numeric"
	})}: ${day.checked}/${day.total} core checks, ${tradeLabel}${result}`;
}
function ProgressTracker({ data, today, selectedDate, onSelectDate, onOpenChecklist }) {
	const [showFullYear, setShowFullYear] = (0, import_react.useState)(false);
	const coreChecklistIds = data.checklistItems.filter((item) => item.group === "core").map((item) => item.id);
	const weeks = buildActivityCalendar({
		endDate: today,
		weeks: showFullYear ? 52 : 26,
		coreChecklistIds,
		checks: data.checks,
		trades: data.trades
	});
	const checkedIds = new Set(data.checks[selectedDate] ?? []);
	const checked = coreChecklistIds.filter((id) => checkedIds.has(id)).length;
	const total = coreChecklistIds.length;
	const scoreLabel = selectedDate === today ? "Today's score" : `${formatCalendarDate(selectedDate, {
		month: "short",
		day: "numeric"
	})} score`;
	const monthLabels = weeks.flatMap((week, weekIndex) => {
		const month = week[0].date.slice(0, 7);
		const previousMonth = weeks[weekIndex - 1]?.[0].date.slice(0, 7);
		if (weekIndex === 0 || month !== previousMonth) return [{
			weekIndex,
			date: week[0].date
		}];
		return [];
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "mb-5",
		kicker: `Consistency · last ${showFullYear ? "12" : "6"} months`,
		title: "Progress tracker",
		titleAction: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "secondary",
			size: "sm",
			onClick: onOpenChecklist,
			"aria-controls": "daily-checklist",
			children: "Daily checklist"
		}),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			onClick: () => setShowFullYear((expanded) => !expanded),
			"aria-expanded": showFullYear,
			children: showFullYear ? "Show less" : "View more"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto pb-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-max gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex shrink-0 flex-col gap-1 pt-4",
						"aria-hidden": "true",
						children: WEEKDAYS.map((weekday) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-3 w-7 items-center text-[9px] leading-none text-muted-foreground",
							children: weekday
						}, weekday))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative mb-1 h-3",
						style: { width: `${weeks.length * 20 - 8}px` },
						"aria-hidden": "true",
						children: monthLabels.map(({ weekIndex, date }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute whitespace-nowrap text-[9px] leading-none tracking-wider text-muted-foreground uppercase",
							style: { left: `${weekIndex * 20}px` },
							children: formatCalendarDate(date, { month: "short" })
						}, date))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: weeks.map((week) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex w-3 flex-col gap-1",
							children: week.map((day) => day.isFuture ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-3 rounded-xs bg-white/[0.02]",
								"aria-hidden": "true"
							}, day.date) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: dayDescription(day),
								"aria-label": dayDescription(day),
								"aria-pressed": selectedDate === day.date,
								onClick: () => onSelectDate(day.date),
								className: `size-3 rounded-xs ${LEVEL_STYLES[day.level]} transition-colors hover:ring-1 hover:ring-accent/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent ${selectedDate === day.date ? "ring-1 ring-accent" : ""}`
							}, day.date))
						}, week[0].date))
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-3 border-t border-white/[0.06] pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-28 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-muted-foreground uppercase",
						children: scoreLabel
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-base font-semibold leading-tight text-foreground",
						children: [
							checked,
							"/",
							total
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: total ? checked / total * 100 : 0,
					className: "min-w-40 flex-1"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-end gap-1.5 text-[9px] tracking-wider text-muted-foreground uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Less" }),
					LEVEL_STYLES.map((style) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `size-2 rounded-xs ${style}`,
						"aria-hidden": "true"
					}, style)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "More" })
				]
			})
		]
	});
}
var GROUPS = [
	{
		value: "core",
		label: "Core",
		hint: "Checked every session"
	},
	{
		value: "conditional",
		label: "Conditional",
		hint: "Only when the model needs it"
	},
	{
		value: "lifestyle",
		label: "Lifestyle",
		hint: "The state you trade in"
	}
];
function ChecklistManager({ open, onOpenChange }) {
	const items = useDeskStore((s) => s.checklistItems);
	const upsertChecklistItem = useDeskStore((s) => s.upsertChecklistItem);
	const removeChecklistItem = useDeskStore((s) => s.removeChecklistItem);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [draftGroup, setDraftGroup] = (0, import_react.useState)("core");
	const [deleteId, setDeleteId] = (0, import_react.useState)(null);
	const pending = items.find((item) => item.id === deleteId);
	const addItem = () => {
		const label = draft.trim();
		if (!label) return;
		const item = {
			id: uid("check"),
			group: draftGroup,
			label
		};
		upsertChecklistItem(item);
		setDraft("");
		toast.success("Checklist item added");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Checklist items" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Core items count toward the daily gate score. Conditional and lifestyle items are recorded but never block execution." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "-mx-1 flex-1 overflow-y-auto px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-lg border border-white/[0.09] bg-white/[0.02] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "New checklist item",
								placeholder: "Add a gate condition…",
								value: draft,
								onChange: (event) => setDraft(event.target.value),
								onKeyDown: (event) => {
									if (event.key === "Enter") addItem();
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								onClick: addItem,
								disabled: !draft.trim(),
								className: "shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "aria-hidden": "true" }), " Add"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2.5 flex flex-wrap gap-1.5",
							role: "group",
							"aria-label": "Group for the new item",
							children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": draftGroup === group.value,
								onClick: () => setDraftGroup(group.value),
								className: cn("rounded-md border px-2.5 py-1 text-[11px] font-medium transition-colors", draftGroup === group.value ? "border-accent bg-accent/15 text-accent" : "border-white/[0.1] text-muted-foreground hover:border-white/[0.24] hover:text-foreground"),
								children: group.label
							}, group.value))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-5",
						children: GROUPS.map((group) => {
							const groupItems = items.filter((item) => item.group === group.value);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-baseline justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-[10px] font-semibold tracking-[0.16em] text-accent uppercase",
									children: group.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground",
									children: [
										groupItems.length,
										" · ",
										group.hint
									]
								})]
							}), groupItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-lg border border-dashed border-white/[0.1] px-3 py-2.5 text-xs text-muted-foreground",
								children: "Nothing here yet."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1.5",
								children: groupItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											"aria-label": `Label for ${item.label}`,
											value: item.label,
											onChange: (event) => upsertChecklistItem({
												...item,
												label: event.target.value
											}),
											className: "h-9"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											"aria-label": `Group for ${item.label}`,
											value: item.group,
											onChange: (event) => upsertChecklistItem({
												...item,
												group: event.target.value
											}),
											className: "h-9 shrink-0 rounded-md border border-white/[0.09] bg-surface-2/80 px-2 text-xs text-foreground outline-none focus-visible:border-accent/60",
											children: GROUPS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: option.value,
												children: option.label
											}, option.value))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "ghost",
											size: "icon-sm",
											"aria-label": `Delete ${item.label}`,
											onClick: () => setDeleteId(item.id),
											className: "shrink-0 text-muted-foreground hover:text-down",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { "aria-hidden": "true" })
										})
									]
								}, item.id))
							})] }, group.value);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
					open: !!deleteId,
					onOpenChange: (next) => !next && setDeleteId(null),
					title: "Delete checklist item?",
					description: `"${pending?.label ?? ""}" will be removed from every future checklist. Past days keep their recorded checks.`,
					confirmLabel: "Delete item",
					onConfirm: () => {
						if (deleteId) {
							removeChecklistItem(deleteId);
							toast.success("Checklist item deleted");
						}
						setDeleteId(null);
					}
				})
			]
		})
	});
}
var IMPACTS = [
	"high",
	"medium",
	"low"
];
var emptyEvent = (date) => ({
	id: uid("news"),
	name: "",
	date,
	time: "08:30",
	impact: "high",
	notes: "",
	avoid: true
});
function NewsManager({ open, onOpenChange, today }) {
	const events = useDeskStore((s) => s.newsEvents);
	const upsertNews = useDeskStore((s) => s.upsertNews);
	const removeNews = useDeskStore((s) => s.removeNews);
	const [draft, setDraft] = (0, import_react.useState)(() => emptyEvent(today));
	const [deleteId, setDeleteId] = (0, import_react.useState)(null);
	const sorted = events.slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
	const pending = events.find((event) => event.id === deleteId);
	const save = () => {
		if (!draft.name.trim()) return;
		upsertNews({
			...draft,
			name: draft.name.trim()
		});
		setDraft(emptyEvent(today));
		toast.success("Event saved to the calendar");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Economic calendar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "High-impact prints set the default to flat. Events flagged “stay flat” raise a warning on the circuit breaker for that date." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "-mx-1 flex-1 overflow-y-auto px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 rounded-lg border border-white/[0.09] bg-white/[0.02] p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2.5 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Event",
										className: "sm:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											placeholder: "US CPI y/y",
											value: draft.name,
											onChange: (event) => setDraft({
												...draft,
												name: event.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Date",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "date",
											value: draft.date,
											onChange: (event) => setDraft({
												...draft,
												date: event.target.value
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Time (NY)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "time",
											value: draft.time,
											onChange: (event) => setDraft({
												...draft,
												time: event.target.value
											})
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2.5 flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex gap-1.5",
									role: "group",
									"aria-label": "Event impact",
									children: IMPACTS.map((impact) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-pressed": draft.impact === impact,
										onClick: () => setDraft({
											...draft,
											impact
										}),
										className: cn("rounded-md border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.1em] transition-colors", draft.impact === impact ? impact === "high" ? "border-accent bg-accent/15 text-accent" : impact === "medium" ? "border-warn/50 bg-warn/10 text-warn" : "border-white/25 bg-white/[0.06] text-foreground" : "border-white/[0.1] text-muted-foreground hover:border-white/[0.24] hover:text-foreground"),
										children: impact
									}, impact))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "inline-flex items-center gap-2 text-xs text-muted-foreground",
									children: ["Stay flat around the print", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										"aria-label": "Stay flat around the print",
										checked: draft.avoid,
										onCheckedChange: (avoid) => setDraft({
											...draft,
											avoid
										})
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								size: "sm",
								onClick: save,
								disabled: !draft.name.trim(),
								className: "mt-3 w-full sm:w-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "aria-hidden": "true" }), " Add event"]
							})
						]
					}), sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg border border-dashed border-white/[0.1] px-3 py-6 text-center text-sm text-muted-foreground",
						children: "No events on the calendar."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1.5",
						children: sorted.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-[11px] tabular-nums text-muted-foreground",
									children: [
										event.date,
										" · ",
										event.time
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate text-sm font-medium text-foreground",
									children: event.name || "Untitled event"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("rounded-sm border px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em]", event.impact === "high" ? "border-accent/40 bg-accent/10 text-accent" : event.impact === "medium" ? "border-warn/40 bg-warn/10 text-warn" : "border-white/[0.12] text-muted-foreground"),
									children: event.impact
								}),
								event.avoid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-sm border border-down/35 bg-down/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-down",
									children: "Flat"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "sm",
										onClick: () => setDraft({ ...event }),
										children: "Edit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon-sm",
										"aria-label": `Delete ${event.name}`,
										onClick: () => setDeleteId(event.id),
										className: "text-muted-foreground hover:text-down",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { "aria-hidden": "true" })
									})]
								})
							]
						}, event.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
					open: !!deleteId,
					onOpenChange: (next) => !next && setDeleteId(null),
					title: "Delete event?",
					description: `${pending?.name ?? "This event"} will be removed from the calendar.`,
					confirmLabel: "Delete event",
					onConfirm: () => {
						if (deleteId) {
							removeNews(deleteId);
							toast.success("Event removed");
						}
						setDeleteId(null);
					}
				})
			]
		})
	});
}
function Checkbox({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
		className: cn("peer size-5 shrink-0 rounded-sm border border-white/[0.18] bg-surface-2/80 transition-all duration-150 hover:border-white/35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 data-[state=checked]:border-accent data-[state=checked]:bg-accent data-[state=checked]:text-primary-foreground data-[state=checked]:shadow-[0_0_12px_rgba(229,9,20,0.4)]", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
			className: "flex items-center justify-center text-current",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "size-3.5",
				strokeWidth: 3
			})
		})
	});
}
function Home() {
	const [showConditionalRequirements, setShowConditionalRequirements] = (0, import_react.useState)(true);
	const [checklistOpen, setChecklistOpen] = (0, import_react.useState)(false);
	const [newsOpen, setNewsOpen] = (0, import_react.useState)(false);
	const data = useDeskStore();
	const toggleCheck = useDeskStore((s) => s.toggleCheck);
	const closeToday = useDeskStore((s) => s.closeToday);
	const openToday = useDeskStore((s) => s.openToday);
	const today = todayISO();
	const [selectedChecklistDate, setSelectedChecklistDate] = (0, import_react.useState)(today);
	const checklistRef = (0, import_react.useRef)(null);
	const day = protocolDayNumber(data);
	const proto = todayProtocol(data);
	const plan = planFor(data, today);
	const week = weeklyFor(data, today);
	const lock = lockInfo(data, today);
	const pay = payoutProgress(data);
	const danger = remainingRToDanger(data, today);
	const todays = tradesOn(data.trades, today);
	const todayR = todays.reduce((a, t) => a + (t.rMultiple ?? 0), 0);
	const conf = biasConfidence(plan.alignments);
	const checked = new Set(data.checks[selectedChecklistDate] ?? []);
	const core = data.checklistItems.filter((i) => i.group === "core");
	const cond = data.checklistItems.filter((i) => i.group === "conditional");
	const life = data.checklistItems.filter((i) => i.group === "lifestyle");
	const news = data.newsEvents.filter((n) => n.date === today);
	const upcoming = data.newsEvents.filter((n) => n.date > today).slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`))[0];
	const models = data.models.filter((m) => m.active);
	const coreDone = core.filter((item) => checked.has(item.id)).length;
	const lossUsedPct = Math.min(100, Math.round((plan.maxDailyLossPct - danger.dailyLeftPct) / Math.max(plan.maxDailyLossPct, .01) * 100));
	function revealDailyChecklist() {
		const target = checklistRef.current;
		if (!target) return;
		target.focus({ preventScroll: true });
		target.scrollIntoView({
			behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth",
			block: "start"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Today",
			title: "Was the read correct?",
			description: `Narrative → liquidity → location → timing → trigger → risk.${proto ? ` ${proto.title}: ${proto.focus}` : ` Day ${day}.`}`,
			aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5 rounded-sm border border-up/30 bg-up/10 px-2 py-0.5 text-[10px] font-semibold tracking-[0.1em] text-up uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "size-1.5 rounded-full bg-up animate-pulse",
					"aria-hidden": "true"
				}), "Live New York"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: [
					today,
					" · ",
					nowHHMM(),
					" NY"
				]
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 grid grid-cols-2 gap-2.5 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Equity",
					value: formatMoney(currentBalance(data)),
					hint: formatPct(sumPnlPct(data.trades)),
					icon: Wallet,
					variant: currentBalance(data) >= data.rules.startingBalance ? "up" : "down"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Today",
					value: formatR(todayR),
					hint: `${todays.length} execution${todays.length === 1 ? "" : "s"}`,
					icon: Flame,
					variant: todayR > 0 ? "up" : todayR < 0 ? "down" : "default"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "R to danger",
					value: `${danger.dailyR.toFixed(0)}R`,
					hint: `${danger.dailyLeftPct.toFixed(2)}% daily cap left`,
					icon: ShieldAlert,
					variant: danger.dailyR <= 2 ? "down" : "default"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
					label: "Payout path",
					value: `${Math.max(0, Math.round(pay.pct))}%`,
					hint: `Target ${formatPct(data.rules.payoutThresholdPct, 0)}`,
					icon: Target,
					variant: "up"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mb-5",
			kicker: "Progress markers",
			title: "Account milestones",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: lock.locked ? "down" : "up",
				children: lock.locked ? "Locked" : "Open"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-4",
				children: [
					25,
					50,
					75,
					100
				].map((milestone) => {
					const progress = pay.target > 0 ? Math.min(100, Math.max(0, pay.pct / milestone * 100)) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-white/[0.07] bg-white/[0.02] p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] font-medium text-foreground/85",
								children: [milestone, "% target"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[11px] tabular-nums text-muted-foreground",
								children: [Math.round(progress), "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: progress })]
					}, milestone);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: "Progress is measured on closed results toward the configured payout threshold."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressTracker, {
			data,
			today,
			selectedDate: selectedChecklistDate,
			onSelectDate: setSelectedChecklistDate,
			onOpenChecklist: revealDailyChecklist
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mb-5",
			kicker: "Circuit breaker",
			title: lock.locked ? "Platform lock active" : "Execution open",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				variant: lock.locked ? "down" : "up",
				className: "gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("size-1.5 rounded-full", lock.locked ? "bg-down" : "bg-up animate-pulse"),
					"aria-hidden": "true"
				}), lock.locked ? "Circuit tripped" : "Ready to execute"]
			}),
			children: [
				lock.reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1.5 flex items-center gap-2 rounded-md border border-down/30 bg-down/[0.07] px-3 py-2 text-sm text-down",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "size-3.5 shrink-0",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: reason })]
				}, reason)),
				lock.warnings.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1.5 flex items-center gap-2 rounded-md border border-warn/30 bg-warn/[0.07] px-3 py-2 text-sm text-warn",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "size-3.5 shrink-0",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: reason })]
				}, reason)),
				!lock.reasons.length && !lock.warnings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No lockout triggers detected. Execute only the written playbook models."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center gap-2.5",
					children: [lock.locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => openToday(today),
						children: "Override lock & open"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "destructive",
						onClick: () => closeToday(today),
						children: "Close platform now"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[11px] text-muted-foreground",
						children: [
							plan.maxTrades - todays.length,
							" of ",
							plan.maxTrades,
							" trades left"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1.5 flex items-center justify-between text-[10px] font-semibold tracking-[0.14em] uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Daily loss used"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-foreground",
							children: [lossUsedPct, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: lossUsedPct })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				kicker: "Weekly map",
				title: week ? `${week.structure} week` : "No weekly narrative",
				children: week ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-3 text-sm text-muted-foreground",
						children: [
							"Draw: ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: week.primaryDraw || "—"
							}),
							week.secondaryDraw ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [" → ", week.secondaryDraw] }) : null,
							". ",
							week.beforeDraw
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeBar, { range: week.dealingRange }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: week.liquidity.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: level.status === "taken" ? "down" : "default",
							children: [
								level.type,
								" ",
								level.status
							]
						}, level.type))
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Open Weekly to write PWH/PWL and the draw."
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				kicker: "Daily bias",
				title: plan.expectedDelivery || "No delivery model",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: conf >= 80 ? "up" : conf >= 60 ? "warn" : "default",
					children: [conf, "% aligned"]
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-2 gap-x-3 gap-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "HTF structure",
							v: plan.htfStructure
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Location",
							v: plan.location
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Liquidity",
							v: plan.liquidityCondition
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Draw",
							v: plan.expectedDraw || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "AMD phase",
							v: plan.amdPhase || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							k: "Risk params",
							v: `${plan.riskPerTrade}% · ${plan.maxTrades} trades`
						})
					]
				}), plan.scenarios ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 whitespace-pre-line rounded-md border border-white/[0.07] bg-black/40 p-3 text-xs leading-relaxed text-muted-foreground",
					children: plan.scenarios
				}) : null]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: checklistRef,
			id: "daily-checklist",
			tabIndex: -1,
			className: "scroll-mt-6 outline-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "mb-5",
				kicker: `Execution gate · ${selectedChecklistDate}`,
				title: "Daily checklist",
				meta: `${coreDone}/${core.length} core conditions met`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => setChecklistOpen(true),
					children: "Edit items"
				}),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						items: core,
						checked,
						onToggle: (id) => toggleCheck(selectedChecklistDate, id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 mb-2 flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.06] pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-[10px] font-semibold tracking-[0.16em] text-muted-foreground uppercase",
							children: "Conditional requirements"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "inline-flex items-center gap-2 text-[11px] text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: showConditionalRequirements ? "Shown" : "Hidden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								"aria-label": "Show conditional requirements",
								checked: showConditionalRequirements,
								onCheckedChange: setShowConditionalRequirements
							})]
						})]
					}),
					showConditionalRequirements ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						items: cond,
						checked,
						onToggle: (id) => toggleCheck(selectedChecklistDate, id)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 mb-2 text-[10px] font-semibold tracking-[0.16em] text-muted-foreground uppercase",
						children: "Lifestyle & mental state"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, {
						items: life,
						checked,
						onToggle: (id) => toggleCheck(selectedChecklistDate, id)
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-5",
			kicker: "Playbook models",
			title: "Permitted setups",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-3 transition-colors hover:border-white/[0.2] hover:bg-white/[0.04]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[11px] font-semibold text-accent",
								children: model.code
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] tracking-[0.12em] text-muted-foreground uppercase",
								children: model.market
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold text-foreground",
							children: model.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs text-muted-foreground",
							children: [
								model.trigger,
								" → ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-foreground/90",
									children: model.target
								})
							]
						})
					]
				}, model.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-5",
			kicker: "Economic calendar",
			title: news.length ? "High-impact events" : "No prints today",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => setNewsOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { "aria-hidden": "true" }), " Manage"]
			}),
			children: news.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-1.5",
				children: news.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-md border border-white/[0.07] bg-white/[0.02] px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[11px] font-semibold text-accent",
							children: [event.time, " NY"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium text-foreground",
							children: event.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: event.avoid ? "down" : "default",
						children: event.avoid ? "Stay flat" : event.impact
					})]
				}, event.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Nothing scheduled for ",
					today,
					".",
					upcoming ? ` Next: ${upcoming.name} on ${upcoming.date} at ${upcoming.time} NY.` : ""
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-2xl border border-white/[0.09] bg-card/70 p-6 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-accent/70 before:to-transparent",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
					className: "mb-2 size-6 text-accent/50",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-2xl leading-snug tracking-wide text-foreground italic sm:text-3xl",
					children: [
						"“",
						data.mantra,
						"”"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[10px] font-semibold tracking-[0.16em] text-accent/80 uppercase",
					children: "Core operating principle · ICT disciplines"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChecklistManager, {
			open: checklistOpen,
			onOpenChange: setChecklistOpen
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsManager, {
			open: newsOpen,
			onOpenChange: setNewsOpen,
			today
		})
	] });
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-white/[0.05] bg-white/[0.02] px-2.5 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[9px] font-semibold tracking-[0.12em] text-muted-foreground uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 truncate text-[13px] font-medium text-foreground capitalize",
			children: v
		})]
	});
}
function Group({ items, checked, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-1.5",
		children: items.map((item) => {
			const isChecked = checked.has(item.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("flex items-start gap-3 rounded-md border px-3 py-2.5 transition-colors", isChecked ? "border-white/[0.12] bg-white/[0.035]" : "border-white/[0.06] hover:border-white/[0.14] hover:bg-white/[0.02]"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					checked: isChecked,
					onClick: (event) => event.stopPropagation(),
					onCheckedChange: () => onToggle(item.id),
					"aria-label": item.label,
					className: "mt-0.5"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onToggle(item.id),
					className: cn("flex-1 text-left text-sm font-medium leading-5 transition-colors", isChecked ? "text-muted-foreground line-through" : "text-foreground/90"),
					children: item.label
				})]
			}, item.id);
		})
	});
}
//#endregion
export { Home as component };
