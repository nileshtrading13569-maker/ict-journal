import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { B as CircleCheck, C as Paperclip, G as Check, H as ChevronRight, J as Calendar, N as Compass, O as Image, P as Columns3, Q as ArrowUp, R as Clock, S as Pencil, U as ChevronLeft, V as ChevronUp, W as ChevronDown, b as Plus, et as ArrowDown, g as Search, j as Ellipsis, q as Camera, s as Trash2, t as X, u as SlidersHorizontal, z as CircleX } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { I as cn, T as MISS_REASONS, U as todayISO, V as nowHHMM, W as todayISO$1, a as syncDeskToServer, f as emptyMissed, j as Button, l as useDeskStore, p as emptyTrade, w as MISS_OUTCOMES, z as formatR } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { L as fmtCurrency, O as calcTradeMetrics, Q as tradeDollarPnl, _ as DropdownMenuSeparator, a as ConfirmDelete, c as DialogDescription, d as DialogTitle, f as DropdownMenu, g as DropdownMenuLabel, i as Chips, l as DialogFooter, m as DropdownMenuContent, n as Badge, o as Dialog, p as DropdownMenuCheckboxItem, r as BoolRow, s as DialogContent, t as AppShell, u as DialogHeader, v as DropdownMenuTrigger, w as Textarea, x as Panel, y as Field, z as instrumentOf } from "./app-shell-x0M2IuoN.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal-ARL0ldVZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("flex w-full items-center gap-1 overflow-x-auto border-b border-white/[0.1]", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("relative inline-flex h-10 shrink-0 items-center gap-1.5 whitespace-nowrap px-3 text-[11px] font-semibold tracking-[0.12em] text-muted-foreground uppercase transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 after:absolute after:inset-x-2 after:bottom-0 after:h-0.5 after:rounded-full after:bg-accent after:opacity-0 after:transition-opacity data-[state=active]:text-foreground data-[state=active]:after:opacity-100", className),
		...props
	});
}
function TabsContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
		className: cn("outline-none", className),
		...props
	});
}
function AllView({ trades, selectedTradeId, onSelectTrade }) {
	const data = useDeskStore();
	const models = useDeskStore((s) => s.models);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filterSide, setFilterSide] = (0, import_react.useState)("all");
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("all");
	const [filterReviewed, setFilterReviewed] = (0, import_react.useState)("all");
	const [sortDirection, setSortDirection] = (0, import_react.useState)("desc");
	const [currentPage, setCurrentPage] = (0, import_react.useState)(1);
	const pageSize = 12;
	const filtered = (0, import_react.useMemo)(() => {
		return trades.filter((t) => {
			if (query.trim()) {
				const q = query.toLowerCase();
				const matchSymbol = t.market.toLowerCase().includes(q);
				const matchPlaybook = t.modelName.toLowerCase().includes(q);
				const matchNotes = (t.notes || "").toLowerCase().includes(q);
				const matchTags = (t.tags || []).some((tag) => tag.toLowerCase().includes(q));
				if (!matchSymbol && !matchPlaybook && !matchNotes && !matchTags) return false;
			}
			if (filterSide !== "all" && t.side !== filterSide) return false;
			if (filterStatus !== "all" && t.result !== filterStatus) return false;
			if (filterReviewed === "reviewed" && !t.reviewed) return false;
			if (filterReviewed === "unreviewed" && t.reviewed) return false;
			return true;
		}).sort((a, b) => {
			const timeA = `${a.date}T${a.time || "00:00"}`;
			const timeB = `${b.date}T${b.time || "00:00"}`;
			return sortDirection === "desc" ? timeB.localeCompare(timeA) : timeA.localeCompare(timeB);
		});
	}, [
		trades,
		query,
		filterSide,
		filterStatus,
		filterReviewed,
		sortDirection
	]);
	const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
	const startIndex = (currentPage - 1) * pageSize;
	const paginated = filtered.slice(startIndex, startIndex + pageSize);
	const totalClosed = trades.filter((t) => t.result !== "open");
	const totalNetPnL = totalClosed.reduce((sum, t) => {
		return sum + (tradeDollarPnl(t, instrumentOf(data, t.market)).net ?? 0);
	}, 0);
	const getModelCode = (trade) => {
		const m = models.find((mod) => mod.id === trade.modelId || mod.name === trade.modelName);
		if (m?.code) return m.code;
		return (trade.modelName || "A").trim().charAt(0).toUpperCase() || "A";
	};
	const formatOpenTime = (trade) => {
		if (!trade.date) return "—";
		const d = new Date(trade.date);
		return `${d.toLocaleDateString("en-US", { month: "short" })} ${d.getDate()}, ${trade.time || "00:00"}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-10 w-[300px] items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 text-[#6f6f6d]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						placeholder: "Search symbol, playbook, tag, note",
						value: query,
						onChange: (e) => {
							setQuery(e.target.value);
							setCurrentPage(1);
						},
						className: "w-full bg-transparent text-[13px] placeholder-[#6f6f6d] outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-10 items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-[#d6d6d4]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-[#a2a2a0]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Oct 1 – Oct 29, 2026" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: cn("flex h-10 items-center gap-2 rounded-md border border-white/[0.09] px-3 text-[13px] font-medium text-[#d6d6d4] transition-colors hover:bg-white/[0.06]", (filterSide !== "all" || filterStatus !== "all" || filterReviewed !== "all") && "border-[#e50914]/50 bg-[#e50914]/10 text-white", filterSide === "all" && filterStatus === "all" && filterReviewed === "all" && "bg-white/[0.03]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Filters", filterSide !== "all" || filterStatus !== "all" || filterReviewed !== "all" ? " (Active)" : ""] })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
					className: "w-56 border-white/[0.1] bg-[#121212] text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
							className: "text-xs text-[#a2a2a0] uppercase",
							children: "Side"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterSide === "all",
							onCheckedChange: () => setFilterSide("all"),
							children: "All sides"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterSide === "long",
							onCheckedChange: () => setFilterSide("long"),
							children: "Long only"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterSide === "short",
							onCheckedChange: () => setFilterSide("short"),
							children: "Short only"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, { className: "bg-white/[0.08]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
							className: "text-xs text-[#a2a2a0] uppercase",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterStatus === "all",
							onCheckedChange: () => setFilterStatus("all"),
							children: "All statuses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterStatus === "win",
							onCheckedChange: () => setFilterStatus("win"),
							children: "Wins"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterStatus === "loss",
							onCheckedChange: () => setFilterStatus("loss"),
							children: "Losses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterStatus === "be",
							onCheckedChange: () => setFilterStatus("be"),
							children: "Break-even"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterStatus === "open",
							onCheckedChange: () => setFilterStatus("open"),
							children: "Open positions"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, { className: "bg-white/[0.08]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
							className: "text-xs text-[#a2a2a0] uppercase",
							children: "Review"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterReviewed === "all",
							onCheckedChange: () => setFilterReviewed("all"),
							children: "All"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterReviewed === "reviewed",
							onCheckedChange: () => setFilterReviewed("reviewed"),
							children: "Reviewed only"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuCheckboxItem, {
							checked: filterReviewed === "unreviewed",
							onCheckedChange: () => setFilterReviewed("unreviewed"),
							children: "To review only"
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-10 items-center gap-2 rounded-md border border-white/[0.09] bg-white/[0.03] px-3 text-[13px] font-medium text-[#d6d6d4] transition-colors hover:bg-white/[0.06]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Columns3, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Columns" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "More options",
						className: "flex size-10 items-center justify-center rounded-md border border-white/[0.09] bg-white/[0.03] text-[15px] text-[#d6d6d4] transition-colors hover:bg-white/[0.06]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e50914]/60 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[960px] table-fixed text-[13px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "128px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "76px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "58px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "88px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "56px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "84px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "84px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "96px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "66px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "120px" } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "70px" } })
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "h-9 border-b border-white/[0.07] text-left text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setSortDirection((d) => d === "desc" ? "asc" : "desc"),
											className: "inline-flex items-center gap-1 text-white hover:text-[#e50914]",
											children: ["Open (ET)", sortDirection === "desc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3 text-[#e50914]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3 text-[#e50914]" })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Symbol"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Side"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Lots"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Entry"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Exit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Net P&L"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "R"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Playbook"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Tags"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-center font-semibold",
										children: "Reviewed"
									})
								]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "[&>tr]:h-10 [&>tr]:border-b [&>tr]:border-white/[0.05]",
								children: paginated.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 12,
									className: "py-12 text-center text-sm text-[#a2a2a0]",
									children: trades.length === 0 ? "No trades recorded yet. Click 'Log trade' to add one." : "No trades match these filters."
								}) }) : paginated.map((trade) => {
									const inst = instrumentOf(data, trade.market);
									const pnl = tradeDollarPnl(trade, inst);
									const isSelected = trade.id === selectedTradeId;
									const code = getModelCode(trade);
									const tagLabel = trade.tags?.[0] || trade.setupTags?.[0] || trade.killZone || "";
									const hasWarningTag = trade.mistakeTags && trade.mistakeTags.length > 0 || (trade.tags || []).some((t) => t.toLowerCase().includes("outside") || t.toLowerCase().includes("early") || t.toLowerCase().includes("late"));
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										onClick: () => onSelectTrade(isSelected ? null : trade),
										className: cn("cursor-pointer transition-colors hover:bg-white/[0.04]", isSelected && "bg-white/[0.05] shadow-[inset_2px_0_0_#e50914]"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "font-mono px-3 text-[12px] text-[#d6d6d4]",
												children: formatOpenTime(trade)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 font-semibold text-white",
												children: trade.market
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 capitalize text-[#d6d6d4]",
												children: trade.side
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: cn("rounded-sm px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.08em] uppercase", trade.result === "win" ? "border border-[#3ddc84]/30 bg-[#3ddc84]/10 text-[#3ddc84]" : trade.result === "loss" ? "border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 text-[#ff6b7d]" : trade.result === "be" ? "whitespace-nowrap border border-white/[0.14] bg-white/[0.05] text-[#d6d6d4]" : "border border-[#f5b942]/30 bg-[#f5b942]/10 text-[#f5b942]"),
													children: trade.result === "win" ? "Win" : trade.result === "loss" ? "Loss" : trade.result === "be" ? "Break-even" : "Open"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "font-mono px-3 text-right text-white",
												children: trade.lots != null ? trade.lots.toFixed(2) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "font-mono px-3 text-right text-white",
												children: trade.entry != null ? trade.entry.toFixed(inst?.digits ?? 2) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "font-mono px-3 text-right text-white",
												children: trade.exitPrice != null ? trade.exitPrice.toFixed(inst?.digits ?? 2) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: cn("font-mono px-3 text-right font-medium", pnl.net == null ? "text-[#6f6f6d]" : pnl.net >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
												children: fmtCurrency(pnl.net)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: cn("font-mono px-3 text-right", trade.rMultiple == null ? "text-[#6f6f6d]" : trade.rMultiple >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
												children: trade.rMultiple != null ? formatR(trade.rMultiple) : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "truncate px-3 text-white",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono mr-1.5 inline-block text-[11px] text-[#a2a2a0]",
													children: code
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: trade.modelName || "Continuation" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "truncate px-3 text-[12px]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: cn(hasWarningTag ? "text-[#f5b942]" : "text-[#a2a2a0]"),
													children: tagLabel || "—"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 text-center",
												children: trade.reviewed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mx-auto size-3.5 text-[#3ddc84]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#6f6f6d]",
													children: "—"
												})
											})
										]
									}, trade.id);
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-10 items-center justify-between border-t border-white/[0.07] px-3 text-[12px] text-[#a2a2a0]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[#d6d6d4]",
							children: trades.length
						}),
						" trades ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[#d6d6d4]",
							children: totalClosed.length
						}),
						" closed · Net P&L",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-mono font-medium", totalNetPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
							children: fmtCurrency(totalNetPnL)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: filtered.length === 0 ? "0–0 of 0" : `${startIndex + 1}–${Math.min(startIndex + pageSize, filtered.length)} of ${filtered.length}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1 text-[14px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: currentPage <= 1,
								onClick: () => setCurrentPage((p) => Math.max(1, p - 1)),
								"aria-label": "Previous page",
								className: "rounded p-1 text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white disabled:opacity-30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: currentPage >= totalPages,
								onClick: () => setCurrentPage((p) => Math.min(totalPages, p + 1)),
								"aria-label": "Next page",
								className: "rounded p-1 text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white disabled:opacity-30",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							})]
						})]
					})]
				})
			]
		})]
	});
}
var WEEKDAY_LABELS = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
	"Sun"
];
function formatDateKey(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function getQuarterStart(date) {
	return new Date(date.getFullYear(), Math.floor(date.getMonth() / 3) * 3, 1);
}
function getCalendarDays(month) {
	const firstDay = new Date(month.getFullYear(), month.getMonth(), 1);
	const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
	const mondayOffset = (firstDay.getDay() + 6) % 7;
	const cellCount = Math.ceil((mondayOffset + daysInMonth) / 7) * 7;
	return Array.from({ length: cellCount }, (_, index) => {
		const day = index - mondayOffset + 1;
		return day > 0 && day <= daysInMonth ? new Date(month.getFullYear(), month.getMonth(), day) : null;
	});
}
/** One pass over both journals so every calendar shares the same lookup. */
function buildEntriesByDate(trades, missed) {
	const entries = /* @__PURE__ */ new Map();
	for (const trade of trades) {
		const counts = entries.get(trade.date) ?? {
			taken: 0,
			missed: 0
		};
		counts.taken += 1;
		entries.set(trade.date, counts);
	}
	for (const trade of missed) {
		const counts = entries.get(trade.date) ?? {
			taken: 0,
			missed: 0
		};
		counts.missed += 1;
		entries.set(trade.date, counts);
	}
	return entries;
}
function netROf(trades) {
	return trades.reduce((total, trade) => total + (trade.rMultiple ?? 0), 0);
}
function activeDayCount(trades, missed) {
	return new Set([...trades, ...missed].map((row) => row.date)).size;
}
function formatLongDate(dateKey) {
	return (/* @__PURE__ */ new Date(`${dateKey}T12:00:00`)).toLocaleDateString(void 0, {
		weekday: "long",
		month: "long",
		day: "numeric",
		year: "numeric"
	});
}
function DayView({ trades, selectedDate, onSelectDate, onSelectTrade }) {
	const data = useDeskStore();
	const models = useDeskStore((s) => s.models);
	const dailyPlans = useDeskStore((s) => s.dailyPlans);
	const setDailyJournalNote = useDeskStore((s) => s.setDailyJournalNote);
	const [currentMonth, setCurrentMonth] = (0, import_react.useState)(() => {
		if (selectedDate) {
			const d = new Date(selectedDate);
			if (!Number.isNaN(d.getTime())) return new Date(d.getFullYear(), d.getMonth(), 1);
		}
		const now = /* @__PURE__ */ new Date();
		return new Date(now.getFullYear(), now.getMonth(), 1);
	});
	const activePlan = dailyPlans[selectedDate];
	const savedNoteText = activePlan?.notes ?? "";
	const [noteContent, setNoteContent] = (0, import_react.useState)(savedNoteText);
	const [isSavingNote, setIsSavingNote] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setNoteContent(savedNoteText);
	}, [selectedDate, savedNoteText]);
	const tradesByDate = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const t of trades) {
			if (!t.date) continue;
			const list = map.get(t.date) ?? [];
			list.push(t);
			map.set(t.date, list);
		}
		return map;
	}, [trades]);
	const monthKey = formatDateKey(currentMonth).slice(0, 7);
	const monthDays = (0, import_react.useMemo)(() => {
		const datesSet = /* @__PURE__ */ new Set();
		trades.forEach((t) => {
			if (t.date && t.date.startsWith(monthKey)) datesSet.add(t.date);
		});
		Object.keys(dailyPlans).forEach((d) => {
			if (d.startsWith(monthKey)) datesSet.add(d);
		});
		if (selectedDate.startsWith(monthKey)) datesSet.add(selectedDate);
		return Array.from(datesSet).sort((a, b) => b.localeCompare(a));
	}, [
		trades,
		dailyPlans,
		monthKey,
		selectedDate
	]);
	(0, import_react.useEffect)(() => {
		if (monthDays.length > 0 && !monthDays.includes(selectedDate)) onSelectDate(monthDays[0]);
	}, [
		monthDays,
		selectedDate,
		onSelectDate
	]);
	const shiftMonth = (delta) => {
		const next = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + delta, 1);
		setCurrentMonth(next);
	};
	const dayTrades = tradesByDate.get(selectedDate) ?? [];
	const closedDayTrades = dayTrades.filter((t) => t.result !== "open");
	const dayStats = (0, import_react.useMemo)(() => {
		let netPnL = 0;
		let netR = 0;
		let totalFees = 0;
		let wins = 0;
		for (const t of closedDayTrades) {
			const inst = instrumentOf(data, t.market);
			const pnl = tradeDollarPnl(t, inst);
			netPnL += pnl.net ?? 0;
			netR += t.rMultiple ?? 0;
			totalFees += t.fees ?? 1.75;
			if (t.result === "win") wins += 1;
		}
		const winRatePct = closedDayTrades.length > 0 ? Math.round(wins / closedDayTrades.length * 100) : 0;
		return {
			netPnL,
			netR,
			tradesCount: dayTrades.length,
			winRatePct,
			fees: totalFees
		};
	}, [
		dayTrades,
		closedDayTrades,
		data
	]);
	const handleSaveNote = async () => {
		setIsSavingNote(true);
		try {
			setDailyJournalNote(selectedDate, noteContent);
			await syncDeskToServer();
			toast.success("Daily journal note saved");
		} catch (err) {
			console.error("[day-view] note save error:", err);
			toast.error("Saved locally. Could not sync with server.");
		} finally {
			setIsSavingNote(false);
		}
	};
	const handleDiscardNote = () => {
		setNoteContent(savedNoteText);
		toast.info("Changes discarded");
	};
	const formatSelectedHeadline = (dateStr) => {
		if (!dateStr) return "Today";
		const d = new Date(dateStr);
		if (Number.isNaN(d.getTime())) return dateStr;
		return d.toLocaleDateString("en-US", {
			weekday: "long",
			month: "long",
			day: "numeric"
		});
	};
	const formatDayListItem = (dateStr) => {
		const d = new Date(dateStr);
		if (Number.isNaN(d.getTime())) return dateStr;
		return d.toLocaleDateString("en-US", {
			weekday: "short",
			month: "short",
			day: "numeric"
		});
	};
	const monthLabel = currentMonth.toLocaleDateString("en-US", {
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full shrink-0 lg:w-[196px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between px-1 text-[12px] text-[#a2a2a0]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-[#d6d6d4]",
					children: monthLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1 text-[14px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => shiftMonth(-1),
						"aria-label": "Previous month",
						className: "rounded p-0.5 hover:bg-white/[0.08] hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => shiftMonth(1),
						"aria-label": "Next month",
						className: "rounded p-0.5 hover:bg-white/[0.08] hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-1",
				children: monthDays.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-2 py-4 text-center text-xs text-[#a2a2a0]",
					children: "No journal days this month"
				}) : monthDays.map((dateKey) => {
					const isSelected = dateKey === selectedDate;
					const dateTrades = tradesByDate.get(dateKey) ?? [];
					const closed = dateTrades.filter((t) => t.result !== "open");
					const openCount = dateTrades.filter((t) => t.result === "open").length;
					const unreviewed = dateTrades.filter((t) => !t.reviewed).length;
					const dateNetPnL = closed.reduce((acc, t) => {
						return acc + (tradeDollarPnl(t, instrumentOf(data, t.market)).net ?? 0);
					}, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						onClick: () => onSelectDate(dateKey),
						className: cn("cursor-pointer rounded-md px-2.5 py-2 transition-colors", isSelected ? "border border-white/[0.12] bg-white/[0.06]" : "hover:bg-white/[0.03]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("text-[13px]", isSelected ? "font-semibold text-white" : "font-medium text-[#d6d6d4]"),
								children: formatDayListItem(dateKey)
							}), closed.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("font-mono text-[12px]", dateNetPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
								children: fmtCurrency(dateNetPnL)
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[11px] text-[#6f6f6d]",
								children: "—"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-0.5 flex justify-between text-[11px] text-[#a2a2a0]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: dateTrades.length === 0 ? "Plan only" : `${dateTrades.length} trade${dateTrades.length > 1 ? "s" : ""}${openCount > 0 ? ` · ${openCount} open` : ""}` }), unreviewed > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[#f5b942]",
								children: [unreviewed, " to review"]
							})]
						})]
					}, dateKey);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-w-0 flex-1 overflow-hidden rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e50914]/60 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between border-b border-white/[0.06] px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-[26px] leading-none text-white",
						children: formatSelectedHeadline(selectedDate)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[12px] text-[#a2a2a0]",
						children: "New York time (ET)"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 border-b border-white/[0.06] px-6 py-3.5 sm:grid-cols-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Net P&L"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono mt-1 text-[20px]", dayStats.netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
							children: fmtCurrency(dayStats.netPnL)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Net R"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono mt-1 text-[20px]", dayStats.netR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
							children: dayStats.netR !== 0 ? formatR(dayStats.netR) : "0.00R"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Trades"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono mt-1 text-[20px] text-white",
							children: dayStats.tradesCount
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Win rate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono mt-1 text-[20px] text-white",
							children: [dayStats.winRatePct, "%"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Fees"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono mt-1 text-[20px] text-[#d6d6d4]",
							children: ["$", dayStats.fees.toFixed(2)]
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-6 pt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[13px] font-semibold text-white",
								children: "Daily journal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[12px] text-[#a2a2a0]",
								children: activePlan?.savedAt ? `Saved ${activePlan.savedAt}` : "Autosave ready"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: noteContent,
							onChange: (e) => setNoteContent(e.target.value),
							placeholder: "Asia range 3,489.20 – 3,497.40. London swept Asia low, NY AM delivered from 15m FVG into PDH. Notes on execution, psychological triggers, or session reflections...",
							className: "h-[144px] w-full resize-y rounded-md border border-white/[0.09] bg-[#151515]/80 p-3.5 text-[13px] leading-relaxed text-[#e8e8e6] outline-none transition focus:border-white/[0.2]"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2.5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleDiscardNote,
								disabled: noteContent === savedNoteText,
								className: "flex h-8 items-center rounded-md px-3 text-[12px] font-medium text-[#a2a2a0] hover:bg-white/[0.04] hover:text-white disabled:opacity-30",
								children: "Discard"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: handleSaveNote,
								disabled: isSavingNote,
								className: "flex h-8 items-center rounded-md border border-white/[0.12] bg-white/[0.05] px-3 text-[12px] font-semibold text-white transition hover:bg-white/[0.1]",
								children: isSavingNote ? "Saving…" : "Save note"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 border-t border-white/[0.06]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[760px] text-[13px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "h-9 border-b border-white/[0.06] text-left text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pl-6 pr-3 font-semibold",
										children: "Time"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Side"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Lots"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Entry"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Exit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "Net P&L"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 text-right font-semibold",
										children: "R"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Playbook"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 font-semibold",
										children: "Rules"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pr-6 pl-3 text-center font-semibold",
										children: "Reviewed"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: dayTrades.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 11,
								className: "py-8 text-center text-xs text-[#a2a2a0]",
								children: "No trades logged on this date."
							}) }) : dayTrades.map((trade) => {
								const inst = instrumentOf(data, trade.market);
								const pnl = tradeDollarPnl(trade, inst);
								const code = models.find((m) => m.id === trade.modelId || m.name === trade.modelName)?.code || "A";
								const assessments = trade.rulesAssessment ?? {};
								const rulesFollowed = Object.values(assessments).filter((v) => v === "followed").length;
								const rulesTotal = Object.keys(assessments).length || 8;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									onClick: () => onSelectTrade(trade),
									className: "h-10 cursor-pointer border-b border-white/[0.05] transition-colors hover:bg-white/[0.04] last:border-b-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "font-mono pl-6 pr-3 text-[12px] text-white",
											children: trade.time || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 capitalize text-[#d6d6d4]",
											children: trade.side
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("rounded-sm px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.08em] uppercase", trade.result === "win" ? "border border-[#3ddc84]/30 bg-[#3ddc84]/10 text-[#3ddc84]" : trade.result === "loss" ? "border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 text-[#ff6b7d]" : trade.result === "be" ? "whitespace-nowrap border border-white/[0.14] bg-white/[0.05] text-[#d6d6d4]" : "border border-[#f5b942]/30 bg-[#f5b942]/10 text-[#f5b942]"),
												children: trade.result === "win" ? "Win" : trade.result === "loss" ? "Loss" : trade.result === "be" ? "Break-even" : "Open"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "font-mono px-3 text-right text-white",
											children: trade.lots != null ? trade.lots.toFixed(2) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "font-mono px-3 text-right text-white",
											children: trade.entry != null ? trade.entry.toFixed(inst?.digits ?? 2) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "font-mono px-3 text-right text-white",
											children: trade.exitPrice != null ? trade.exitPrice.toFixed(inst?.digits ?? 2) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: cn("font-mono px-3 text-right", pnl.net == null ? "text-[#6f6f6d]" : pnl.net >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
											children: fmtCurrency(pnl.net)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: cn("font-mono px-3 text-right", trade.rMultiple == null ? "text-[#6f6f6d]" : trade.rMultiple >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
											children: trade.rMultiple != null ? formatR(trade.rMultiple) : "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3 text-[#d6d6d4]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono mr-1.5 inline-block text-[11px] text-[#a2a2a0]",
												children: code
											}), trade.modelName || "Continuation"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "font-mono px-3 text-[12px] text-[#d6d6d4]",
											children: [
												rulesFollowed,
												" / ",
												rulesTotal
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "pr-6 pl-3 text-center",
											children: trade.reviewed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mx-auto size-3.5 text-[#3ddc84]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[#6f6f6d]",
												children: "—"
											})
										})
									]
								}, trade.id);
							}) })]
						})
					})
				})
			]
		})]
	});
}
var GRADES$1 = [
	"A+",
	"A",
	"A-",
	"B",
	"C",
	"D",
	"F"
];
function TradeInspector({ trade, onClose, onEdit, onPrev, onNext, hasPrev = false, hasNext = false }) {
	const data = useDeskStore();
	const models = useDeskStore((s) => s.models);
	const removeTrade = useDeskStore((s) => s.removeTrade);
	const updateTradeReview = useDeskStore((s) => s.updateTradeReview);
	const updateTradeRule = useDeskStore((s) => s.updateTradeRule);
	const updateTradeGrade = useDeskStore((s) => s.updateTradeGrade);
	const updateTradePlaybook = useDeskStore((s) => s.updateTradePlaybook);
	const updateTradeTags = useDeskStore((s) => s.updateTradeTags);
	const [activeTab, setActiveTab] = (0, import_react.useState)("review");
	const [deleteOpen, setDeleteOpen] = (0, import_react.useState)(false);
	const [newSetup, setNewSetup] = (0, import_react.useState)("");
	const [addingSetup, setAddingSetup] = (0, import_react.useState)(false);
	const [newMistake, setNewMistake] = (0, import_react.useState)("");
	const [addingMistake, setAddingMistake] = (0, import_react.useState)(false);
	if (!trade) return null;
	const inst = instrumentOf(data, trade.market);
	const pnl = tradeDollarPnl(trade, inst);
	const currentModel = models.find((m) => m.id === trade.modelId || m.name === trade.modelName) ?? models[0];
	const rules = trade.rulesAssessment ?? {};
	const defaultRulesList = [
		{
			key: "htf_bias",
			category: "Market conditions",
			label: "HTF bias aligned on 4H and 1H"
		},
		{
			key: "premium_discount",
			category: "Market conditions",
			label: "Price trading in premium/discount of the dealing range"
		},
		{
			key: "no_news",
			category: "Market conditions",
			label: "No high-impact news within 30 min"
		},
		{
			key: "sweep",
			category: "Entry criteria",
			label: "Liquidity swept before entry"
		},
		{
			key: "mss",
			category: "Entry criteria",
			label: "5m MSS with displacement"
		},
		{
			key: "fvg_entry",
			category: "Entry criteria",
			label: "Entry at 5m FVG inside kill zone"
		},
		{
			key: "target_opposing",
			category: "Exit criteria",
			label: "Target at opposing liquidity pool"
		},
		{
			key: "partial_at_2r",
			category: "Exit criteria",
			label: "Take partial at 2R or structural target"
		},
		{
			key: "risk_limit",
			category: "Risk",
			label: "Risk ≤ 0.25% of balance"
		},
		{
			key: "stop_placement",
			category: "Risk",
			label: "Stop beyond the swept structural high/low"
		}
	];
	const followedCount = defaultRulesList.filter((r) => (rules[r.key] ?? "followed") === "followed").length;
	const totalCount = defaultRulesList.length;
	const handleRuleToggle = (ruleKey, status) => {
		updateTradeRule(trade.id, ruleKey, status);
		syncDeskToServer();
	};
	const handleReviewToggle = () => {
		const next = !trade.reviewed;
		updateTradeReview(trade.id, next);
		syncDeskToServer();
		toast.success(next ? "Marked as reviewed" : "Unmarked reviewed");
	};
	const handleGradeChange = (g) => {
		updateTradeGrade(trade.id, g);
		syncDeskToServer();
	};
	const handlePlaybookChange = (nextModelId) => {
		const nextModel = models.find((m) => m.id === nextModelId);
		if (!nextModel) return;
		updateTradePlaybook(trade.id, nextModel.id, nextModel.name);
		syncDeskToServer();
		toast.success(`Assigned to ${nextModel.name}`);
	};
	const setupTags = trade.setupTags ?? trade.tags ?? [];
	const mistakeTags = trade.mistakeTags ?? [];
	const handleAddSetupTag = () => {
		const val = newSetup.trim();
		if (val && !setupTags.includes(val)) {
			updateTradeTags(trade.id, [...setupTags, val], mistakeTags);
			syncDeskToServer();
		}
		setNewSetup("");
		setAddingSetup(false);
	};
	const handleAddMistakeTag = () => {
		const val = newMistake.trim();
		if (val && !mistakeTags.includes(val)) {
			updateTradeTags(trade.id, setupTags, [...mistakeTags, val]);
			syncDeskToServer();
		}
		setNewMistake("");
		setAddingMistake(false);
	};
	const handleDelete = () => {
		removeTrade(trade.id);
		syncDeskToServer();
		toast.success("Trade deleted from journal");
		setDeleteOpen(false);
		onClose();
	};
	const openTimeFormatted = trade.date ? new Date(trade.date).toLocaleDateString("en-US", {
		weekday: "short",
		month: "short",
		day: "numeric",
		year: "numeric"
	}) : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		"aria-label": "Trade details inspector",
		className: "fixed top-16 right-0 bottom-0 z-30 flex w-full max-w-[560px] flex-col border-l border-white/[0.1] bg-[#0b0b0b] shadow-[-24px_0_48px_-12px_rgba(0,0,0,0.85)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-[72px] shrink-0 items-center justify-between border-b border-white/[0.07] px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-[28px] leading-none text-white",
						children: trade.market
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("rounded-sm px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.1em] uppercase", trade.side === "long" ? "border border-[#3ddc84]/30 bg-[#3ddc84]/10 text-[#3ddc84]" : "border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 text-[#ff6b7d]"),
						children: trade.side
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono mt-1.5 text-[11px] text-[#a2a2a0]",
					children: [
						openTimeFormatted,
						" · ",
						trade.time,
						" ",
						trade.exitTime ? `→ ${trade.exitTime}` : "",
						" ET"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 text-[16px] text-[#d6d6d4]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !hasPrev,
							onClick: onPrev,
							title: "Previous trade",
							"aria-label": "Previous trade",
							className: "flex size-8 items-center justify-center rounded-md border border-white/[0.09] transition-colors hover:bg-white/[0.05] disabled:opacity-30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !hasNext,
							onClick: onNext,
							title: "Next trade",
							"aria-label": "Next trade",
							className: "flex size-8 items-center justify-center rounded-md border border-white/[0.09] transition-colors hover:bg-white/[0.05] disabled:opacity-30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							title: "Close panel",
							"aria-label": "Close panel",
							className: "ml-1 flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid h-16 shrink-0 grid-cols-4 border-b border-white/[0.07] px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Lots"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono mt-0.5 text-[17px] text-[#f5f5f4]",
							children: trade.lots ?? "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Net P&L"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono mt-0.5 text-[17px]", pnl.net == null ? "text-[#6f6f6d]" : pnl.net >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
							children: fmtCurrency(pnl.net)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Realized R"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono mt-0.5 text-[17px]", trade.rMultiple == null ? "text-[#6f6f6d]" : trade.rMultiple >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
							children: trade.rMultiple != null ? formatR(trade.rMultiple) : "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
							children: "Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("rounded-sm px-1.5 py-0.5 text-[10px] font-semibold tracking-[0.08em] uppercase", trade.result === "win" ? "border border-[#3ddc84]/30 bg-[#3ddc84]/10 text-[#3ddc84]" : trade.result === "loss" ? "border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 text-[#ff6b7d]" : trade.result === "be" ? "border border-white/[0.14] bg-white/[0.05] text-[#d6d6d4]" : "border border-[#f5b942]/30 bg-[#f5b942]/10 text-[#f5b942]"),
								children: trade.result === "win" ? "Win" : trade.result === "loss" ? "Loss" : trade.result === "be" ? "Break-even" : "Open"
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-10 shrink-0 items-end gap-6 border-b border-white/[0.07] px-5 text-[11px] font-semibold tracking-[0.14em] uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveTab("review"),
						className: cn("pb-2.5 transition-colors", activeTab === "review" ? "border-b-2 border-[#e50914] text-white" : "text-[#a2a2a0] hover:text-white"),
						children: "Review"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveTab("execution"),
						className: cn("pb-2.5 transition-colors", activeTab === "execution" ? "border-b-2 border-[#e50914] text-white" : "text-[#a2a2a0] hover:text-white"),
						children: "Execution"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveTab("ict"),
						className: cn("pb-2.5 transition-colors", activeTab === "ict" ? "border-b-2 border-[#e50914] text-white" : "text-[#a2a2a0] hover:text-white"),
						children: "ICT"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-5 py-4",
				children: activeTab === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1.5 text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Playbook"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: currentModel.id,
										onChange: (e) => handlePlaybookChange(e.target.value),
										"aria-label": "Selected Playbook",
										className: "flex h-10 w-full appearance-none items-center justify-between rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 pr-8 text-[13px] text-white outline-none focus-visible:border-[#e50914]",
										children: models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: m.id,
											className: "bg-[#151515] text-white",
											children: [
												"[",
												m.code,
												"] ",
												m.name
											]
										}, m.id))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none absolute top-3 right-3 size-4 text-[#a2a2a0]" })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/playbook",
								className: "flex h-10 items-center gap-1 rounded-md border border-white/[0.09] bg-white/[0.03] px-3 text-[12px] font-medium text-[#d6d6d4] transition-colors hover:bg-white/[0.08] hover:text-white",
								children: ["Open playbook ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[13px] font-semibold text-white",
								children: "Rules"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[12px] text-[#a2a2a0]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[#f5f5f4]",
										children: followedCount
									}),
									" of",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[#f5f5f4]",
										children: totalCount
									}),
									" followed"
								]
							})]
						}), [
							"Market conditions",
							"Entry criteria",
							"Exit criteria",
							"Risk"
						].map((category) => {
							const items = defaultRulesList.filter((r) => r.category === category);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-1 text-[10px] font-semibold tracking-[0.14em] text-[#a2a2a0] uppercase",
									children: category
								}), items.map((r) => {
									const st = rules[r.key] ?? "followed";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex min-h-11 items-center justify-between gap-3 border-b border-white/[0.05] py-1.5 text-[13px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#e8e8e6]",
											children: r.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex shrink-0 overflow-hidden rounded-md border border-white/[0.1] text-[11px] font-medium",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleRuleToggle(r.key, "followed"),
													className: cn("px-2.5 py-1.5 transition-colors", st === "followed" ? "bg-[#3ddc84]/15 text-[#3ddc84]" : "text-[#a2a2a0] hover:text-white"),
													children: "Followed"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleRuleToggle(r.key, "not"),
													className: cn("border-l border-white/[0.1] px-2.5 py-1.5 transition-colors", st === "not" ? "bg-[#ff6b7d]/15 text-[#ff6b7d]" : "text-[#a2a2a0] hover:text-white"),
													children: "Not"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleRuleToggle(r.key, "na"),
													className: cn("border-l border-white/[0.1] px-2.5 py-1.5 transition-colors", st === "na" ? "bg-white/[0.1] text-white" : "text-[#a2a2a0] hover:text-white"),
													children: "N/A"
												})
											]
										})]
									}, r.key);
								})]
							}, category);
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-white/[0.07] pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[13px] font-semibold text-white",
								children: "Tags"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-[72px_1fr] items-center gap-y-2 text-[12px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#a2a2a0]",
										children: "Setups"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [setupTags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-md border border-white/[0.12] bg-white/[0.04] px-2 py-1 text-white",
											children: tag
										}, tag)), addingSetup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: newSetup,
												onChange: (e) => setNewSetup(e.target.value),
												onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), handleAddSetupTag()),
												placeholder: "Tag",
												className: "h-7 w-24 rounded border border-white/[0.2] bg-[#151515] px-2 text-xs text-white",
												autoFocus: true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: handleAddSetupTag,
												className: "text-xs text-[#3ddc84] hover:underline",
												children: "Save"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setAddingSetup(true),
											className: "rounded-md border border-dashed border-white/[0.14] px-2 py-1 text-[#a2a2a0] hover:border-white/[0.3] hover:text-white",
											children: "+ Add"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#a2a2a0]",
										children: "Mistakes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [mistakeTags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-md border border-[#f5b942]/30 bg-[#f5b942]/10 px-2 py-1 text-[#f5b942]",
											children: tag
										}, tag)), addingMistake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: newMistake,
												onChange: (e) => setNewMistake(e.target.value),
												onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), handleAddMistakeTag()),
												placeholder: "Mistake",
												className: "h-7 w-24 rounded border border-white/[0.2] bg-[#151515] px-2 text-xs text-white",
												autoFocus: true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: handleAddMistakeTag,
												className: "text-xs text-[#3ddc84] hover:underline",
												children: "Save"
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setAddingMistake(true),
											className: "rounded-md border border-dashed border-white/[0.14] px-2 py-1 text-[#a2a2a0] hover:border-white/[0.3] hover:text-white",
											children: "+ Add"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#a2a2a0]",
										children: "Grade"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-mono flex flex-wrap gap-1 text-[12px]",
										children: GRADES$1.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleGradeChange(g),
											className: cn("rounded-md border px-2 py-1 transition-colors", trade.grade === g ? "border-[#e50914] bg-[#e50914] font-semibold text-white" : "border-white/[0.1] text-[#a2a2a0] hover:border-white/[0.2] hover:text-white"),
											children: g
										}, g))
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-white/[0.07] pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-[13px] font-semibold text-white",
								children: "Trade note"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 rounded-md border border-white/[0.08] bg-[#151515]/70 p-3 text-[13px] leading-relaxed text-[#d6d6d4]",
								children: trade.notes || "No notes logged for this trade."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-t border-white/[0.07] pt-4 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-[13px] font-semibold text-white",
									children: "Attachments"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => onEdit(trade),
									className: "flex items-center gap-1 text-[12px] text-[#a2a2a0] hover:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-3.5" }), " Add"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex h-24 flex-col justify-end rounded-md border border-white/[0.08] bg-[#151515] p-2 text-[11px] text-[#a2a2a0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "mb-auto size-4 text-[#6f6f6d]" }), "HTF chart · 1H"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex h-24 flex-col justify-end rounded-md border border-white/[0.08] bg-[#151515] p-2 text-[11px] text-[#a2a2a0]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "mb-auto size-4 text-[#6f6f6d]" }), "Execution · 5m"]
								})]
							})]
						})
					]
				}) : activeTab === "execution" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 text-[13px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "Entry price"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[16px] text-white",
									children: trade.entry != null ? trade.entry.toFixed(inst?.digits ?? 2) : "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "Exit price"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[16px] text-white",
									children: trade.exitPrice != null ? trade.exitPrice.toFixed(inst?.digits ?? 2) : "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "Stop loss"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[16px] text-[#ff6b7d]",
									children: trade.sl != null ? trade.sl.toFixed(inst?.digits ?? 2) : "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "Target (TP)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[16px] text-[#3ddc84]",
									children: trade.tp1 != null ? trade.tp1.toFixed(inst?.digits ?? 2) : "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "MAE"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[15px] text-[#d6d6d4]",
									children: trade.maeR != null ? `${trade.maeR}R` : "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-[#a2a2a0] uppercase",
									children: "MFE"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono mt-1 text-[15px] text-[#d6d6d4]",
									children: trade.mfeR != null ? `${trade.mfeR}R` : "—"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-white/[0.07] bg-[#151515] p-3 text-[13px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[#a2a2a0] uppercase",
								children: "Fees & Risk summary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono mt-2 flex justify-between border-b border-white/[0.05] pb-1 text-[12px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#a2a2a0]",
									children: "Commissions / Fees:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-white",
									children: ["$", trade.fees != null ? trade.fees.toFixed(2) : "1.75"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono mt-1 flex justify-between border-b border-white/[0.05] pb-1 text-[12px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#a2a2a0]",
									children: "Gross P&L:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-white",
									children: fmtCurrency(pnl.gross)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono mt-1 flex justify-between text-[12px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#a2a2a0]",
									children: "Net P&L:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: pnl.net && pnl.net >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]",
									children: fmtCurrency(pnl.net)
								})]
							})
						]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-[13px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[#a2a2a0] uppercase",
								children: "Higher Timeframe Bias"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-medium capitalize text-white",
								children: [
									"Weekly ",
									trade.weeklyBias,
									" · Daily ",
									trade.dailyBias
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[#a2a2a0] uppercase",
								children: "Dealing Range & Location"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-medium capitalize text-white",
								children: [
									trade.location,
									" of ",
									trade.dealingRangeLabel || "Daily",
									" range"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[#a2a2a0] uppercase",
								children: "Liquidity Pools"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-white",
								children: [
									"Taken: ",
									trade.taken.length ? trade.taken.join(", ") : "None marked",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Target: ",
									trade.targetLiq.length ? trade.targetLiq.join(", ") : "None marked"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-[#a2a2a0] uppercase",
								children: "Timing & Session"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-white",
								children: [
									trade.session || "NY",
									" · ",
									trade.killZone || "NY AM Kill Zone"
								]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-16 shrink-0 items-center justify-between border-t border-white/[0.07] px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-2 text-[13px] text-[#d6d6d4]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: Boolean(trade.reviewed),
						onChange: handleReviewToggle,
						className: "size-4 rounded border-white/[0.25] bg-white/[0.04] text-[#e50914] focus:ring-[#e50914]"
					}), "Mark reviewed"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDeleteOpen(true),
						title: "Delete trade",
						"aria-label": "Delete trade",
						className: "flex size-9 items-center justify-center rounded-md text-[15px] text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-[#ff6b7d]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onEdit(trade),
						className: "flex h-9 items-center gap-1.5 rounded-md border-white/[0.12] bg-white/[0.04] px-3.5 text-[13px] font-semibold text-white hover:bg-white/[0.08]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" }), " Edit trade"]
					})]
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
		open: deleteOpen,
		onOpenChange: setDeleteOpen,
		title: "Delete trade?",
		description: "This removes the research row from your journal ledger.",
		onConfirm: handleDelete
	})] });
}
var GRADES = [
	"A+",
	"A",
	"A-",
	"B",
	"C",
	"D",
	"F"
];
function TradeFormModal({ open, onOpenChange, trade, onSaved }) {
	const models = useDeskStore((s) => s.models);
	const instruments = useDeskStore((s) => s.instruments);
	const rules = useDeskStore((s) => s.rules);
	const data = useDeskStore();
	const upsertTrade = useDeskStore((s) => s.upsertTrade);
	const [activeTab, setActiveTab] = (0, import_react.useState)("execution");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [symbol, setSymbol] = (0, import_react.useState)("XAUUSD");
	const [side, setSide] = (0, import_react.useState)("long");
	const [position, setPosition] = (0, import_react.useState)("closed");
	const [entryDate, setEntryDate] = (0, import_react.useState)(() => todayISO$1());
	const [entryTime, setEntryTime] = (0, import_react.useState)(() => nowHHMM());
	const [exitDate, setExitDate] = (0, import_react.useState)(() => todayISO$1());
	const [exitTime, setExitTime] = (0, import_react.useState)("");
	const [lots, setLots] = (0, import_react.useState)("0.25");
	const [entryPrice, setEntryPrice] = (0, import_react.useState)("");
	const [exitPrice, setExitPrice] = (0, import_react.useState)("");
	const [fees, setFees] = (0, import_react.useState)("1.75");
	const [stopLoss, setStopLoss] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)("");
	const [maeR, setMaeR] = (0, import_react.useState)("");
	const [mfeR, setMfeR] = (0, import_react.useState)("");
	const [modelId, setModelId] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [grade, setGrade] = (0, import_react.useState)("");
	const [reviewed, setReviewed] = (0, import_react.useState)(false);
	const [setupTags, setSetupTags] = (0, import_react.useState)([]);
	const [mistakeTags, setMistakeTags] = (0, import_react.useState)([]);
	const [newSetupTag, setNewSetupTag] = (0, import_react.useState)("");
	const [newMistakeTag, setNewMistakeTag] = (0, import_react.useState)("");
	const [addingSetup, setAddingSetup] = (0, import_react.useState)(false);
	const [addingMistake, setAddingMistake] = (0, import_react.useState)(false);
	const [rulesAssessment, setRulesAssessment] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setActiveTab("execution");
		if (trade) {
			setSymbol(trade.market || "XAUUSD");
			setSide(trade.side || "long");
			setPosition(trade.result === "open" ? "open" : "closed");
			setEntryDate(trade.date || todayISO$1());
			setEntryTime(trade.time || nowHHMM());
			setExitDate(trade.exitDate || trade.date || todayISO$1());
			setExitTime(trade.exitTime || "");
			setLots(trade.lots != null ? String(trade.lots) : "0.25");
			setEntryPrice(trade.entry != null ? String(trade.entry) : "");
			setExitPrice(trade.exitPrice != null ? String(trade.exitPrice) : "");
			setFees(trade.fees != null ? String(trade.fees) : "1.75");
			setStopLoss(trade.sl != null ? String(trade.sl) : "");
			setTarget(trade.tp1 != null ? String(trade.tp1) : "");
			setMaeR(trade.maeR != null ? String(trade.maeR) : "");
			setMfeR(trade.mfeR != null ? String(trade.mfeR) : "");
			setModelId(trade.modelId || (models[0]?.id ?? ""));
			setNotes(trade.notes || "");
			setGrade(trade.grade || "");
			setReviewed(Boolean(trade.reviewed));
			setSetupTags(trade.setupTags ? [...trade.setupTags] : trade.tags ? [...trade.tags] : []);
			setMistakeTags(trade.mistakeTags ? [...trade.mistakeTags] : []);
			setRulesAssessment(trade.rulesAssessment ? { ...trade.rulesAssessment } : {});
		} else {
			const activeModel = models.find((m) => m.active) ?? models[0];
			setSymbol("XAUUSD");
			setSide("long");
			setPosition("closed");
			setEntryDate(todayISO$1());
			setEntryTime(nowHHMM());
			setExitDate(todayISO$1());
			setExitTime("");
			setLots("0.25");
			setEntryPrice("");
			setExitPrice("");
			setFees("1.75");
			setStopLoss("");
			setTarget("");
			setMaeR("");
			setMfeR("");
			setModelId(activeModel?.id ?? "");
			setNotes("");
			setGrade("");
			setReviewed(false);
			setSetupTags(["NY AM"]);
			setMistakeTags([]);
			setRulesAssessment({});
		}
	}, [
		open,
		trade,
		models
	]);
	const activeInstrument = instrumentOf(data, symbol) ?? instruments[0];
	const parsedEntry = entryPrice.trim() !== "" ? Number(entryPrice) : null;
	const parsedExit = exitPrice.trim() !== "" ? Number(exitPrice) : null;
	const parsedSl = stopLoss.trim() !== "" ? Number(stopLoss) : null;
	const parsedTarget = target.trim() !== "" ? Number(target) : null;
	const parsedLots = lots.trim() !== "" ? Number(lots) : null;
	const parsedFees = fees.trim() !== "" ? Number(fees) : 0;
	const metrics = (0, import_react.useMemo)(() => {
		return calcTradeMetrics({
			side,
			entry: parsedEntry,
			sl: parsedSl,
			exitPrice: position === "open" ? null : parsedExit,
			tp1: parsedTarget,
			lots: parsedLots,
			fees: parsedFees
		}, activeInstrument);
	}, [
		side,
		parsedEntry,
		parsedSl,
		parsedExit,
		parsedTarget,
		parsedLots,
		parsedFees,
		position,
		activeInstrument
	]);
	const selectedModel = models.find((m) => m.id === modelId) ?? models[0];
	const handleSave = async () => {
		const numericLots = parsedLots && !Number.isNaN(parsedLots) ? parsedLots : .25;
		const numericEntry = parsedEntry && !Number.isNaN(parsedEntry) ? parsedEntry : null;
		const numericExit = position === "closed" && parsedExit && !Number.isNaN(parsedExit) ? parsedExit : null;
		const numericSl = parsedSl && !Number.isNaN(parsedSl) ? parsedSl : null;
		const numericTarget = parsedTarget && !Number.isNaN(parsedTarget) ? parsedTarget : null;
		const numericMae = maeR.trim() !== "" && !Number.isNaN(Number(maeR)) ? Number(maeR) : null;
		const numericMfe = mfeR.trim() !== "" && !Number.isNaN(Number(mfeR)) ? Number(mfeR) : null;
		let tradeResult = "open";
		if (position === "closed") {
			if (metrics.realizedR != null) {
				if (metrics.realizedR > .15) tradeResult = "win";
				else if (metrics.realizedR < -.15) tradeResult = "loss";
				else tradeResult = "be";
			} else tradeResult = "win";
		}
		const calculatedR = position === "closed" ? metrics.realizedR : null;
		const updatedTrade = {
			...trade ?? emptyTrade(entryDate, entryTime, rules.normalRiskPct, selectedModel),
			id: trade?.id ?? `tr-${Date.now()}`,
			date: entryDate,
			time: entryTime,
			exitDate: position === "closed" ? exitDate : void 0,
			exitTime: position === "closed" ? exitTime : "",
			market: symbol,
			side,
			modelId: selectedModel?.id ?? "",
			modelName: selectedModel?.name ?? "",
			lots: numericLots,
			entry: numericEntry,
			exitPrice: numericExit,
			fees: parsedFees,
			sl: numericSl,
			tp1: numericTarget,
			targetPrice: numericTarget,
			maeR: numericMae,
			mfeR: numericMfe,
			result: tradeResult,
			rMultiple: calculatedR,
			notes: notes.trim(),
			grade: grade || "",
			reviewed,
			tags: [...setupTags, ...mistakeTags],
			setupTags: [...setupTags],
			mistakeTags: [...mistakeTags],
			rulesAssessment: { ...rulesAssessment },
			ruleFollowed: Object.values(rulesAssessment).filter((v) => v === "not").length === 0
		};
		setSaving(true);
		try {
			upsertTrade(updatedTrade);
			await syncDeskToServer();
			toast.success(trade ? "Trade updated successfully" : "Trade logged successfully");
			onSaved?.(updatedTrade);
			onOpenChange(false);
		} catch (error) {
			console.error("[trade-form] error saving trade:", error);
			toast.error("Saved locally. Could not sync with server.");
			onOpenChange(false);
		} finally {
			setSaving(false);
		}
	};
	const addSetupTagItem = () => {
		const val = newSetupTag.trim();
		if (val && !setupTags.includes(val)) setSetupTags([...setupTags, val]);
		setNewSetupTag("");
		setAddingSetup(false);
	};
	const addMistakeTagItem = () => {
		const val = newMistakeTag.trim();
		if (val && !mistakeTags.includes(val)) setMistakeTags([...mistakeTags, val]);
		setNewMistakeTag("");
		setAddingMistake(false);
	};
	const toggleRule = (key, value) => {
		setRulesAssessment((prev) => ({
			...prev,
			[key]: prev[key] === value ? "na" : value
		}));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			"aria-describedby": "trade-form-description",
			className: "max-h-[90vh] w-[95vw] max-w-[740px] overflow-hidden rounded-xl border border-white/[0.1] bg-[#0e0e0e] p-0 text-[#f5f5f4] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.95)] sm:max-w-[720px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "sr-only",
					children: trade ? "Edit trade" : "Log trade"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					id: "trade-form-description",
					className: "sr-only",
					children: "Fill in execution and ICT review details for this trade."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 shrink-0 items-center justify-between border-b border-white/[0.07] px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-[26px] leading-none text-white",
							children: trade ? "Edit trade" : "Log trade"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[12px] text-[#a2a2a0]",
							children: [
								entryDate ? new Date(entryDate).toLocaleDateString("en-US", {
									month: "short",
									day: "numeric"
								}) : "Today",
								",",
								" ",
								entryTime || "09:48",
								" ET"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						"aria-label": "Close",
						className: "flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-10 shrink-0 items-end gap-6 border-b border-white/[0.07] px-6 text-[11px] font-semibold tracking-[0.14em] uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveTab("execution"),
						className: cn("pb-2.5 transition-colors", activeTab === "execution" ? "border-b-2 border-[#e50914] text-white" : "text-[#a2a2a0] hover:text-white"),
						children: "Execution"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveTab("ict"),
						className: cn("pb-2.5 transition-colors", activeTab === "ict" ? "border-b-2 border-[#e50914] text-white" : "text-[#a2a2a0] hover:text-white"),
						children: "ICT & review"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[calc(90vh-140px)] min-h-0 flex-1 overflow-y-auto px-6 py-5",
					children: activeTab === "execution" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Symbol"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											value: symbol,
											onChange: (e) => setSymbol(e.target.value),
											"aria-label": "Symbol",
											className: "flex h-10 w-full appearance-none items-center justify-between rounded-md border border-white/[0.09] bg-[#151515]/90 px-3 pr-8 text-[13px] font-semibold text-white outline-none focus-visible:border-[#e50914]",
											children: instruments.map((inst) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: inst.symbol,
												className: "bg-[#151515] text-white",
												children: inst.symbol
											}, inst.id))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none absolute top-3 right-3 size-4 text-[#a2a2a0]" })]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Side"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid h-10 grid-cols-2 overflow-hidden rounded-md border border-white/[0.1] text-[13px] font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setSide("long"),
											className: cn("flex items-center justify-center transition-colors", side === "long" ? "bg-[#3ddc84]/15 font-semibold text-[#3ddc84]" : "text-[#a2a2a0] hover:text-white"),
											children: "Long"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setSide("short"),
											className: cn("flex items-center justify-center border-l border-white/[0.1] transition-colors", side === "short" ? "bg-[#ff6b7d]/15 font-semibold text-[#ff6b7d]" : "text-[#a2a2a0] hover:text-white"),
											children: "Short"
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Position"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid h-10 grid-cols-2 overflow-hidden rounded-md border border-white/[0.1] text-[13px] font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPosition("open"),
											className: cn("flex items-center justify-center transition-colors", position === "open" ? "bg-[#f5b942]/15 font-semibold text-[#f5b942]" : "text-[#a2a2a0] hover:text-white"),
											children: "Open"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPosition("closed"),
											className: cn("flex items-center justify-center border-l border-white/[0.1] transition-colors", position === "closed" ? "bg-white/[0.08] font-semibold text-white" : "text-[#a2a2a0] hover:text-white"),
											children: "Closed"
										})]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Entry date & time (ET)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[1fr_96px] gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "date",
											value: entryDate,
											onChange: (e) => setEntryDate(e.target.value),
											className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										placeholder: "09:48",
										value: entryTime,
										onChange: (e) => setEntryTime(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Exit date & time (ET)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[1fr_96px] gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										value: exitDate,
										disabled: position === "open",
										onChange: (e) => setExitDate(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white disabled:opacity-40"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										placeholder: "10:36",
										value: exitTime,
										disabled: position === "open",
										onChange: (e) => setExitTime(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white disabled:opacity-40"
									})]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Lots"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "0.25",
										value: lots,
										onChange: (e) => setLots(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Entry price"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "3512.40",
										value: entryPrice,
										onChange: (e) => setEntryPrice(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Exit price"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "3500.20",
										disabled: position === "open",
										value: exitPrice,
										onChange: (e) => setExitPrice(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white disabled:opacity-40"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Fees ($)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "1.75",
										value: fees,
										onChange: (e) => setFees(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Stop loss"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "3517.40",
										value: stopLoss,
										onChange: (e) => setStopLoss(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Target"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "3498.00",
										value: target,
										onChange: (e) => setTarget(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "MAE (R)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "-0.34",
										value: maeR,
										onChange: (e) => setMaeR(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "MFE (R)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "0.01",
										placeholder: "2.62",
										value: mfeR,
										onChange: (e) => setMfeR(e.target.value),
										className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-3 rounded-md border border-white/[0.08] bg-white/[0.025] p-3 sm:grid-cols-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Risk"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono mt-1 text-[15px] text-[#d6d6d4]",
										children: metrics.risk != null ? `$${metrics.risk.toFixed(2)}` : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Gross P&L"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("font-mono mt-1 text-[15px]", metrics.grossPnL == null ? "text-[#6f6f6d]" : metrics.grossPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
										children: fmtCurrency(metrics.grossPnL)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Fees"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono mt-1 text-[15px] text-[#d6d6d4]",
										children: metrics.fees > 0 ? `−$${metrics.fees.toFixed(2)}` : "$0.00"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Net P&L"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("font-mono mt-1 text-[15px] font-semibold", metrics.netPnL == null ? "text-[#6f6f6d]" : metrics.netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
										children: fmtCurrency(metrics.netPnL)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Planned R"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono mt-1 text-[15px] text-[#d6d6d4]",
										children: metrics.plannedR != null ? `${metrics.plannedR}R` : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: "Realized R"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: cn("font-mono mt-1 text-[15px]", metrics.realizedR == null ? "text-[#6f6f6d]" : metrics.realizedR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"),
										children: metrics.realizedR != null ? formatR(metrics.realizedR) : "—"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-[11px] text-[#6f6f6d]",
								children: [
									activeInstrument.symbol,
									" · tick ",
									activeInstrument.tickSize,
									" · $",
									activeInstrument.tickValuePerLot.toFixed(2),
									" per tick per lot"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Playbook"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: modelId,
									onChange: (e) => setModelId(e.target.value),
									"aria-label": "Playbook",
									className: "flex h-10 w-full appearance-none items-center justify-between rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 pr-8 text-[13px] text-white outline-none focus-visible:border-[#e50914]",
									children: models.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: m.id,
										className: "bg-[#151515] text-white",
										children: [
											"[",
											m.code,
											"] ",
											m.name
										]
									}, m.id))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none absolute top-3 right-3 size-4 text-[#a2a2a0]" })]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Trade note"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								placeholder: "Asia high and PDH swept at 09:31. 5m MSS at 09:44, filled the FVG at 3,512.40...",
								className: "min-h-24 resize-y border-white/[0.09] bg-[#151515]/80 p-3 text-[13px] leading-relaxed text-[#e8e8e6]"
							})] })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-2 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Trade Grade"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-1.5",
								children: [GRADES.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setGrade(g),
									className: cn("font-mono flex h-8 min-w-9 items-center justify-center rounded-md border px-2.5 text-[12px] font-semibold transition-colors", grade === g ? "border-[#e50914] bg-[#e50914] text-white" : "border-white/[0.1] bg-white/[0.03] text-[#a2a2a0] hover:border-white/[0.2] hover:text-white"),
									children: g
								}, g)), grade && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setGrade(""),
									className: "ml-2 text-[12px] text-[#6f6f6d] hover:text-white",
									children: "Clear"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Setup Tags"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5",
								children: [setupTags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-md border border-white/[0.12] bg-white/[0.04] px-2.5 py-1 text-[12px] text-white",
									children: [tag, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSetupTags(setupTags.filter((t) => t !== tag)),
										className: "text-[#a2a2a0] hover:text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
									})]
								}, tag)), addingSetup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										placeholder: "Tag name",
										value: newSetupTag,
										onChange: (e) => setNewSetupTag(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), addSetupTagItem()),
										className: "h-8 w-28 text-[12px]",
										autoFocus: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										type: "button",
										onClick: addSetupTagItem,
										className: "h-8 px-2 text-xs",
										children: "Add"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAddingSetup(true),
									className: "rounded-md border border-dashed border-white/[0.14] px-2.5 py-1 text-[12px] text-[#a2a2a0] transition-colors hover:border-white/[0.3] hover:text-white",
									children: "+ Add tag"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Mistake Tags"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5",
								children: [mistakeTags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1 rounded-md border border-[#f5b942]/30 bg-[#f5b942]/10 px-2.5 py-1 text-[12px] text-[#f5b942]",
									children: [tag, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMistakeTags(mistakeTags.filter((t) => t !== tag)),
										className: "text-[#f5b942]/80 hover:text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
									})]
								}, tag)), addingMistake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										placeholder: "Mistake",
										value: newMistakeTag,
										onChange: (e) => setNewMistakeTag(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), addMistakeTagItem()),
										className: "h-8 w-28 text-[12px]",
										autoFocus: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										type: "button",
										onClick: addMistakeTagItem,
										className: "h-8 px-2 text-xs",
										children: "Add"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAddingMistake(true),
									className: "rounded-md border border-dashed border-white/[0.14] px-2.5 py-1 text-[12px] text-[#a2a2a0] transition-colors hover:border-white/[0.3] hover:text-white",
									children: "+ Add mistake"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 rounded-xl border border-white/[0.08] bg-[#121212] p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-[13px] font-semibold text-white",
											children: "Execution Rules Checklist"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-[11px] text-[#a2a2a0]",
											children: [
												Object.values(rulesAssessment).filter((v) => v === "followed").length,
												" of",
												" ",
												Object.keys(rulesAssessment).length || 10,
												" followed"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold tracking-[0.14em] text-[#a2a2a0] uppercase",
											children: "Market conditions"
										}), [
											{
												key: "htf_bias",
												label: "HTF bias aligned on 4H and 1H"
											},
											{
												key: "premium_discount",
												label: "Price trading in premium/discount of dealing range"
											},
											{
												key: "no_news",
												label: "No high-impact news within 30 min"
											}
										].map((r) => {
											const st = rulesAssessment[r.key] ?? "followed";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-h-10 items-center justify-between gap-3 border-b border-white/[0.05] py-1.5 text-[13px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#e8e8e6]",
													children: r.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex shrink-0 overflow-hidden rounded-md border border-white/[0.1] text-[11px] font-medium",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "followed"),
															className: cn("px-2.5 py-1 transition-colors", st === "followed" ? "bg-[#3ddc84]/15 text-[#3ddc84]" : "text-[#a2a2a0]"),
															children: "Followed"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "not"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "not" ? "bg-[#ff6b7d]/15 text-[#ff6b7d]" : "text-[#a2a2a0]"),
															children: "Not"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "na"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "na" ? "bg-white/[0.1] text-white" : "text-[#a2a2a0]"),
															children: "N/A"
														})
													]
												})]
											}, r.key);
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold tracking-[0.14em] text-[#a2a2a0] uppercase",
											children: "Entry criteria"
										}), [
											{
												key: "sweep",
												label: "Liquidity swept before entry"
											},
											{
												key: "mss",
												label: "5m MSS with displacement"
											},
											{
												key: "fvg_entry",
												label: "Entry at 5m FVG inside Kill Zone"
											}
										].map((r) => {
											const st = rulesAssessment[r.key] ?? "followed";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-h-10 items-center justify-between gap-3 border-b border-white/[0.05] py-1.5 text-[13px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#e8e8e6]",
													children: r.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex shrink-0 overflow-hidden rounded-md border border-white/[0.1] text-[11px] font-medium",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "followed"),
															className: cn("px-2.5 py-1 transition-colors", st === "followed" ? "bg-[#3ddc84]/15 text-[#3ddc84]" : "text-[#a2a2a0]"),
															children: "Followed"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "not"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "not" ? "bg-[#ff6b7d]/15 text-[#ff6b7d]" : "text-[#a2a2a0]"),
															children: "Not"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "na"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "na" ? "bg-white/[0.1] text-white" : "text-[#a2a2a0]"),
															children: "N/A"
														})
													]
												})]
											}, r.key);
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-semibold tracking-[0.14em] text-[#a2a2a0] uppercase",
											children: "Exit & Risk"
										}), [
											{
												key: "target_opposing",
												label: "Target opposing liquidity pool"
											},
											{
												key: "partial_at_2r",
												label: "Take partial at 2R or logical level"
											},
											{
												key: "risk_limit",
												label: "Risk ≤ 0.25% of balance"
											},
											{
												key: "stop_placement",
												label: "Stop beyond swept structural extreme"
											}
										].map((r) => {
											const st = rulesAssessment[r.key] ?? "followed";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-h-10 items-center justify-between gap-3 border-b border-white/[0.05] py-1.5 text-[13px] last:border-b-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#e8e8e6]",
													children: r.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex shrink-0 overflow-hidden rounded-md border border-white/[0.1] text-[11px] font-medium",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "followed"),
															className: cn("px-2.5 py-1 transition-colors", st === "followed" ? "bg-[#3ddc84]/15 text-[#3ddc84]" : "text-[#a2a2a0]"),
															children: "Followed"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "not"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "not" ? "bg-[#ff6b7d]/15 text-[#ff6b7d]" : "text-[#a2a2a0]"),
															children: "Not"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => toggleRule(r.key, "na"),
															className: cn("border-l border-white/[0.1] px-2.5 py-1 transition-colors", st === "na" ? "bg-white/[0.1] text-white" : "text-[#a2a2a0]"),
															children: "N/A"
														})
													]
												})]
											}, r.key);
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									id: "trade-modal-reviewed",
									checked: reviewed,
									onChange: (e) => setReviewed(e.target.checked),
									className: "size-4 rounded border-white/[0.2] bg-white/[0.04] text-[#e50914] focus:ring-[#e50914]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "trade-modal-reviewed",
									className: "cursor-pointer text-[13px] text-[#d6d6d4]",
									children: "Mark trade as reviewed"
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 shrink-0 items-center justify-end gap-2 border-t border-white/[0.07] px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						className: "h-10 border-white/[0.1] bg-white/[0.03] px-4 text-[13px] text-white hover:bg-white/[0.08]",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: handleSave,
						disabled: saving,
						className: "h-10 bg-[#e50914] px-4 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] hover:brightness-110",
						children: saving ? "Saving…" : trade ? "Save changes" : "Log trade"
					})]
				})
			]
		})
	});
}
var TONE = {
	default: "text-foreground",
	up: "text-up",
	down: "text-down",
	warn: "text-warn",
	accent: "text-accent"
};
/**
* Label-over-value tile used for every inline metric across the desk, so a
* figure in the journal reads the same weight as one in analytics.
*/
function StatTile({ label, value, tone = "default", hint, className, mono = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-md border border-white/[0.06] bg-white/[0.02] px-2.5 py-2", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[9px] font-semibold tracking-[0.14em] text-muted-foreground uppercase sm:text-[10px]",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-0.5 truncate text-sm font-semibold", mono && "font-mono tabular-nums", TONE[tone]),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate text-[10px] text-subtle",
				children: hint
			}) : null
		]
	});
}
/**
* Returns net dollar P&L for a trade.
*/
function getTradePnL(trade, riskDollars = 250) {
	if (trade.netPnL != null) return trade.netPnL;
	if (trade.rMultiple != null) return Math.round(trade.rMultiple * riskDollars * 100) / 100;
	if (trade.entry != null && trade.exitPrice != null && trade.lots != null) {
		const diff = trade.side === "long" ? trade.exitPrice - trade.entry : trade.entry - trade.exitPrice;
		return Math.round(diff * trade.lots * 100 * 100) / 100;
	}
	return 0;
}
/**
* Format dollar amount with sign and currency.
*/
function formatCurrency(amount) {
	return `${amount > 0 ? "+" : amount < 0 ? "-" : ""}$${Math.abs(amount).toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	})}`;
}
/**
* Returns holding duration string (e.g. "42m", "1h 15m").
*/
function getTradeHoldDuration(trade) {
	if (trade.holdDuration) return trade.holdDuration;
	if (!trade.time || !trade.exitTime) return "—";
	const [eh, em] = trade.time.split(":").map(Number);
	const [xh, xm] = trade.exitTime.split(":").map(Number);
	if (Number.isNaN(eh) || Number.isNaN(em) || Number.isNaN(xh) || Number.isNaN(xm)) return "—";
	let totalMinutes = xh * 60 + xm - (eh * 60 + em);
	if (totalMinutes < 0) totalMinutes += 1440;
	if (totalMinutes < 60) return `${totalMinutes}m`;
	const hours = Math.floor(totalMinutes / 60);
	const mins = totalMinutes % 60;
	return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}
/**
* Trade Efficiency % = Realized R / MFE R.
* Indicates whether the trader extracted maximum value or left money on the table.
*/
function getTradeEfficiency(trade) {
	if (trade.tradeEfficiency != null) return trade.tradeEfficiency;
	if (trade.mfeR && trade.mfeR > 0 && trade.rMultiple != null && trade.rMultiple > 0) return Math.min(100, Math.max(0, Math.round(trade.rMultiple / trade.mfeR * 100)));
	return trade.result === "win" ? 80 : 0;
}
/**
* Return structured 5-phase rules for a setup model.
* If not already set on the model, synthesizes standard ICT confluences.
*/
function getPlaybookRules(model) {
	if (model.rulesList && model.rulesList.length > 0) return model.rulesList;
	const rules = [];
	let order = 1;
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "context",
		text: model.htfNarrative ? `HTF Narrative: ${model.htfNarrative}` : "Higher timeframe bias and draw on liquidity confirmed",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "context",
		text: model.requiredTiming ? `Timing Window: ${model.requiredTiming}` : "Session Killzone active (no red folder news within 15m)",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "trigger",
		text: model.liquidityCondition ? `Liquidity Raid: ${model.liquidityCondition}` : "Key liquidity pool swept (Buy-side / Sell-side)",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "trigger",
		text: model.pdArray ? `PD Array: ${model.pdArray}` : "Fair Value Gap (FVG) or Order Block displacement confirmed",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "trigger",
		text: model.trigger ? `Trigger: ${model.trigger}` : "Market Structure Shift (MSS) with energetic displacement candle body",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "entry_risk",
		text: "Order placed at limit within PD Array / OTE 62%–79% retracement",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "entry_risk",
		text: model.invalidation ? `Stop Loss anchored: ${model.invalidation}` : "Stop loss strictly anchored behind displacement swing extreme",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "management",
		text: model.target ? `Target Objective: ${model.target}` : "Primary profit target set at opposing dealing range liquidity",
		isMandatory: true
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "management",
		text: "Partial profit taken at 1:2 R; stop moved to Breakeven",
		isMandatory: false
	});
	rules.push({
		id: `${model.id}-r${order++}`,
		category: "invalidation",
		text: model.invalidation ? `Hard Invalidation: ${model.invalidation}` : "Candle body close through anchor candle invalidates setup before fill",
		isMandatory: true
	});
	return rules;
}
/**
* Calculates rule adherence percentage (0-100%) for a trade against its model.
*/
function calculateTradeRuleAdherence(trade, model) {
	if (!model) return {
		adherencePct: trade.ruleFollowed ? 100 : 50,
		followed: trade.ruleFollowed ? 5 : 2,
		total: 5
	};
	const rules = getPlaybookRules(model);
	const checklist = trade.ruleChecklist ?? {};
	if (Object.keys(checklist).length === 0) {
		const defaultPct = trade.ruleFollowed ? 100 : 40;
		return {
			adherencePct: defaultPct,
			followed: Math.round(rules.length * defaultPct / 100),
			total: rules.length
		};
	}
	let followed = 0;
	for (const rule of rules) if (checklist[rule.id] === true) followed += 1;
	else if (checklist[rule.id] === void 0 && trade.ruleFollowed) followed += 1;
	return {
		adherencePct: rules.length > 0 ? Math.round(followed / rules.length * 100) : 100,
		followed,
		total: rules.length
	};
}
/**
* Synthesizes realistic, clean OHLCV candlestick bars for a trade so the interactive
* Canvas chart can plot exact entries, exits, stop loss, take profit, MFE, and MAE.
*/
function generateTradeCandles(trade) {
	if (trade.candlestickData && trade.candlestickData.length >= 10) return trade.candlestickData.map((b) => ({
		...b,
		volume: b.volume ?? 150
	}));
	const isLong = trade.side === "long";
	const entry = trade.entry ?? 3500;
	const sl = trade.sl ?? (isLong ? entry - 10 : entry + 10);
	const exit = trade.exitPrice ?? (trade.result === "win" ? isLong ? entry + 20 : entry - 20 : sl);
	const riskDist = Math.abs(entry - sl) || 5;
	const mfeOffset = (trade.mfeR ?? (trade.result === "win" ? 2.2 : .4)) * riskDist;
	const maeOffset = Math.abs(trade.maeR ?? -.35) * riskDist;
	const mfePrice = isLong ? entry + mfeOffset : entry - mfeOffset;
	const maePrice = isLong ? entry - maeOffset : entry + maeOffset;
	const bars = [];
	const [sh, sm] = (trade.time || "09:30").split(":").map(Number);
	const startTotalMins = (Number.isNaN(sh) ? 9 : sh) * 60 + (Number.isNaN(sm) ? 30 : sm);
	let currentPrice = isLong ? entry - riskDist * .8 : entry + riskDist * .8;
	for (let i = 0; i < 6; i++) {
		const mins = startTotalMins - (6 - i) * 5;
		const h = String(Math.floor((mins + 1440) % 1440 / 60)).padStart(2, "0");
		const m = String(Math.floor((mins + 1440) % 60)).padStart(2, "0");
		const move = (isLong ? 1 : -1) * (riskDist * .15) * (i % 2 === 0 ? 1 : -.5);
		const o = currentPrice;
		const c = o + move;
		const high = Math.max(o, c) + riskDist * .12;
		const low = Math.min(o, c) - riskDist * .12;
		currentPrice = c;
		bars.push({
			time: `${h}:${m}`,
			open: round(o),
			high: round(high),
			low: round(low),
			close: round(c),
			volume: Math.floor(120 + Math.random() * 80)
		});
	}
	const entryOpen = isLong ? entry - riskDist * .2 : entry + riskDist * .2;
	bars.push({
		time: trade.time || "09:30",
		open: round(entryOpen),
		high: round(Math.max(entryOpen, entry) + riskDist * .1),
		low: round(Math.min(entryOpen, entry) - riskDist * .1),
		close: round(entry),
		volume: 340,
		isEntryBar: true
	});
	currentPrice = entry;
	for (let i = 1; i <= 10; i++) {
		const mins = startTotalMins + i * 5;
		const h = String(Math.floor((mins + 1440) % 1440 / 60)).padStart(2, "0");
		const m = String(Math.floor((mins + 1440) % 60)).padStart(2, "0");
		let target = entry;
		if (i <= 3) target = maePrice;
		else if (i <= 8) {
			const progress = (i - 3) / 5;
			target = entry + (mfePrice - entry) * progress;
		} else target = exit;
		const o = currentPrice;
		const c = target + (Math.random() - .5) * (riskDist * .2);
		const high = Math.max(o, c, isLong ? i === 8 ? mfePrice : o : o) + riskDist * .08;
		const low = Math.min(o, c, !isLong ? i === 8 ? mfePrice : o : i === 2 ? maePrice : o) - riskDist * .08;
		currentPrice = c;
		bars.push({
			time: `${h}:${m}`,
			open: round(o),
			high: round(high),
			low: round(low),
			close: round(c),
			volume: Math.floor(180 + Math.random() * 120)
		});
	}
	const exitTime = trade.exitTime || "10:55";
	bars.push({
		time: exitTime,
		open: round(currentPrice),
		high: round(Math.max(currentPrice, exit) + riskDist * .1),
		low: round(Math.min(currentPrice, exit) - riskDist * .1),
		close: round(exit),
		volume: 290,
		isExitBar: true
	});
	currentPrice = exit;
	const [xh, xm] = exitTime.split(":").map(Number);
	const exitTotalMins = (Number.isNaN(xh) ? 10 : xh) * 60 + (Number.isNaN(xm) ? 55 : xm);
	for (let i = 1; i <= 4; i++) {
		const mins = exitTotalMins + i * 5;
		const h = String(Math.floor((mins + 1440) % 1440 / 60)).padStart(2, "0");
		const m = String(Math.floor((mins + 1440) % 60)).padStart(2, "0");
		const move = (Math.random() - .45) * (riskDist * .3);
		const o = currentPrice;
		const c = o + move;
		const high = Math.max(o, c) + riskDist * .1;
		const low = Math.min(o, c) - riskDist * .1;
		currentPrice = c;
		bars.push({
			time: `${h}:${m}`,
			open: round(o),
			high: round(high),
			low: round(low),
			close: round(c),
			volume: Math.floor(110 + Math.random() * 60)
		});
	}
	return bars;
}
function round(val) {
	return Math.round(val * 100) / 100;
}
function MonthGrid({ month, counts, trades = [], selectedDate, todayKey, onSelectDate, compact = false }) {
	const days = getCalendarDays(month);
	const dayStats = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const t of trades) {
			const cur = map.get(t.date) ?? {
				pnl: 0,
				r: 0,
				wins: 0,
				losses: 0,
				count: 0
			};
			cur.pnl += getTradePnL(t);
			cur.r += t.rMultiple ?? 0;
			if (t.result === "win") cur.wins += 1;
			else if (t.result === "loss") cur.losses += 1;
			cur.count += 1;
			map.set(t.date, cur);
		}
		return map;
	}, [trades]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid grid-cols-7", compact ? "gap-1" : "gap-1.5"),
		children: [WEEKDAY_LABELS.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pb-1 text-center text-[10px] font-semibold tracking-[0.1em] text-muted-foreground uppercase",
			children: day
		}, day)), days.map((date, index) => {
			if (!date) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { "aria-hidden": "true" }, `empty-${index}`);
			const dateKey = formatDateKey(date);
			const entry = counts.get(dateKey);
			const stats = dayStats.get(dateKey);
			const isSelected = dateKey === selectedDate;
			const isToday = dateKey === todayKey;
			const hasTrades = stats && stats.count > 0;
			const isProfitable = hasTrades && stats.pnl > 0;
			const isLoss = hasTrades && stats.pnl < 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-pressed": isSelected,
				onClick: () => onSelectDate(dateKey),
				className: cn("group relative flex min-w-0 flex-col justify-between rounded-md border p-1 text-left transition-all", compact ? "min-h-12" : "min-h-16 sm:min-h-20", isSelected ? "border-accent ring-1 ring-accent bg-accent/10" : isProfitable ? "border-up/25 bg-up/[0.04] hover:border-up/50 hover:bg-up/[0.08]" : isLoss ? "border-down/25 bg-down/[0.04] hover:border-down/50 hover:bg-down/[0.08]" : entry && entry.missed > 0 ? "border-warn/25 bg-warn/[0.03] hover:border-warn/50" : "border-white/[0.06] bg-white/[0.01] hover:border-white/20 hover:bg-white/[0.03]", isToday && !isSelected && "border-accent/40"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-mono text-[11px] font-medium leading-none", isToday ? "text-accent font-bold" : "text-muted-foreground group-hover:text-foreground"),
							children: date.getDate()
						}), hasTrades && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded bg-black/40 px-1 py-0.2 text-[9px] font-mono text-muted-foreground",
							children: [stats.count, "t"]
						})]
					}),
					hasTrades ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-auto w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono text-[11px] font-bold leading-tight truncate sm:text-xs", isProfitable ? "text-up" : isLoss ? "text-down" : "text-foreground"),
							children: formatCurrency(stats.pnl)
						}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-[9px] font-mono text-muted-foreground mt-0.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatR(stats.r) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								stats.wins,
								"W-",
								stats.losses,
								"L"
							] })]
						})]
					}) : entry && entry.missed > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-auto text-[10px] text-warn font-mono",
						children: [entry.missed, " missed"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-auto" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 h-1",
						children: [entry && entry.taken > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1 rounded-full bg-up" }), entry && entry.missed > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1 rounded-full bg-warn" })]
					})
				]
			}, dateKey);
		})]
	});
}
/**
* The day detail shared by the month and quarter views: what was taken, what
* was missed, and the net R for that session.
*/
function SelectedDay({ date, trades, missed, onLogTrade, onLogMissed, className }) {
	const netR = netROf(trades);
	const empty = trades.length === 0 && missed.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("border-t border-white/[0.08] pt-4", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-semibold tracking-[0.16em] text-accent uppercase",
				children: "Selected day"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-display text-lg tracking-wide text-foreground",
				children: formatLongDate(date)
			})] }), empty ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-1.5 text-[11px] font-medium",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-sm border border-up/30 bg-up/10 px-2 py-1 text-up",
						children: [trades.length, " taken"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-sm border border-warn/30 bg-warn/10 px-2 py-1 text-warn",
						children: [missed.length, " missed"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("rounded-sm border border-white/[0.1] bg-white/[0.03] px-2 py-1 font-mono tabular-nums", netR > 0 ? "text-up" : netR < 0 ? "text-down" : "text-muted-foreground"),
						children: formatR(netR)
					})
				]
			})]
		}), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap items-center justify-between gap-3 rounded-md border border-dashed border-white/[0.12] px-3.5 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No journal entries for this day."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: onLogTrade,
					children: "Log trade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: onLogMissed,
					children: "Log missed"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-3 space-y-1.5",
			children: [trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-2 rounded-md border border-up/20 bg-up/[0.05] px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm font-medium text-foreground",
					children: [
						trade.market,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground uppercase",
							children: trade.side
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-[11px] text-muted-foreground",
					children: [
						trade.time,
						" NY · ",
						trade.rMultiple == null ? "Open" : formatR(trade.rMultiple)
					]
				})]
			}, `taken-${trade.id}`)), missed.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-2 rounded-md border border-warn/20 bg-warn/[0.05] px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm font-medium text-foreground",
					children: [
						row.market,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground uppercase",
							children: row.side
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-[11px] text-muted-foreground",
					children: [row.time, " NY · Missed"]
				})]
			}, `missed-${row.id}`))]
		})]
	});
}
function DailyDrawer({ date, open, onOpenChange, trades, missed, onSelectTrade, onLogTrade, onLogMissed }) {
	if (!date) return null;
	const dayTrades = (0, import_react.useMemo)(() => trades.filter((t) => t.date === date), [trades, date]);
	const dayMissed = (0, import_react.useMemo)(() => missed.filter((m) => m.date === date), [missed, date]);
	const netR = netROf(dayTrades);
	const totalDollarPnL = dayTrades.reduce((sum, t) => sum + getTradePnL(t), 0);
	const wins = dayTrades.filter((t) => t.result === "win").length;
	const losses = dayTrades.filter((t) => t.result === "loss").length;
	const winRate = dayTrades.length > 0 ? Math.round(wins / dayTrades.length * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl bg-[#0a0a0a] border-white/10 p-5 text-foreground max-h-[85vh] overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "border-b border-white/[0.08] pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-mono font-semibold tracking-widest text-accent uppercase",
						children: "TradeZella Daily Journal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "mt-1 font-display text-xl tracking-tight text-foreground",
						children: formatLongDate(date)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							className: "h-8 border-white/15 text-xs",
							onClick: () => {
								onOpenChange(false);
								onLogTrade(date);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 size-3.5" }), " Log Trade"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							className: "h-8 text-xs text-muted-foreground hover:text-foreground",
							onClick: () => {
								onOpenChange(false);
								onLogMissed(date);
							},
							children: "Log Missed"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-4 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-wider text-muted-foreground",
								children: "Net P&L"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-0.5 font-mono text-sm font-bold ${totalDollarPnL > 0 ? "text-up" : totalDollarPnL < 0 ? "text-down" : "text-muted-foreground"}`,
								children: formatCurrency(totalDollarPnL)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-wider text-muted-foreground",
								children: "Net R"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-0.5 font-mono text-sm font-bold ${netR > 0 ? "text-up" : netR < 0 ? "text-down" : "text-muted-foreground"}`,
								children: formatR(netR)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-wider text-muted-foreground",
								children: "Win Rate"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 font-mono text-sm font-bold text-foreground",
								children: dayTrades.length > 0 ? `${winRate}%` : "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[9px] uppercase tracking-wider text-muted-foreground",
								children: "Trades"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 font-mono text-sm font-bold text-foreground",
								children: [
									dayTrades.length,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground text-xs font-normal",
										children: [
											"(",
											wins,
											"W / ",
											losses,
											"L)"
										]
									})
								]
							})]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
						className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
						children: [
							"Executed Trades (",
							dayTrades.length,
							")"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: "Click trade to inspect canvas chart"
					})]
				}), dayTrades.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-md border border-dashed border-white/10 p-4 text-center text-xs text-muted-foreground",
					children: "No trades logged for this date."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: dayTrades.map((trade) => {
						const pnl = getTradePnL(trade);
						const isLong = trade.side === "long";
						trade.result;
						trade.result;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								onOpenChange(false);
								onSelectTrade(trade);
							},
							className: "group flex w-full items-center justify-between rounded-md border border-white/[0.08] bg-white/[0.02] p-3 text-left transition-all hover:border-accent/40 hover:bg-white/[0.05]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `flex size-6 items-center justify-center rounded text-[10px] font-bold uppercase ${isLong ? "bg-up/20 text-up" : "bg-down/20 text-down"}`,
									children: isLong ? "B" : "S"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs font-semibold text-foreground",
											children: trade.market
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-mono text-muted-foreground",
											children: [trade.time, " NY"]
										}),
										trade.modelName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-muted-foreground",
											children: trade.modelName
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] text-muted-foreground",
									children: [
										"Entry: ",
										trade.entry?.toFixed(2) ?? "—",
										" · Exit: ",
										trade.exitPrice?.toFixed(2) ?? "—"
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `font-mono text-xs font-bold ${pnl > 0 ? "text-up" : pnl < 0 ? "text-down" : "text-muted-foreground"}`,
										children: formatCurrency(pnl)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `text-[10px] font-mono ${trade.rMultiple && trade.rMultiple > 0 ? "text-up" : trade.rMultiple && trade.rMultiple < 0 ? "text-down" : "text-muted-foreground"}`,
										children: trade.rMultiple != null ? formatR(trade.rMultiple) : "Open"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground group-hover:text-foreground transition-colors" })]
							})]
						}, trade.id);
					})
				})] }), dayMissed.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
					className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2",
					children: [
						"Missed Setups (",
						dayMissed.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-1.5",
					children: dayMissed.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-md border border-warn/20 bg-warn/[0.03] p-2.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-medium text-foreground",
								children: m.market
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-muted-foreground",
								children: [m.time, " NY"]
							}),
							m.why && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 rounded bg-warn/15 px-1.5 py-0.5 text-[10px] text-warn",
								children: ["Hesitation: ", m.why]
							})
						] }), m.outcome && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[11px] text-muted-foreground",
							children: ["Potential: ", m.outcome]
						})]
					}, m.id))
				})] })]
			})]
		})
	});
}
function TradeCanvasChart({ trade, height = 360, className = "", showExcursions = true }) {
	const canvasRef = (0, import_react.useRef)(null);
	const containerRef = (0, import_react.useRef)(null);
	const [timeframe, setTimeframe] = (0, import_react.useState)("5m");
	const [hoverBar, setHoverBar] = (0, import_react.useState)(null);
	const [hoverPos, setHoverPos] = (0, import_react.useState)(null);
	const candles = (0, import_react.useMemo)(() => generateTradeCandles(trade), [trade]);
	const downloadSnapshot = () => {
		if (!canvasRef.current) return;
		const link = document.createElement("a");
		link.download = `${trade.market}-${trade.date}-${trade.time}-execution.png`;
		link.href = canvasRef.current.toDataURL("image/png");
		link.click();
	};
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const dpr = window.devicePixelRatio || 1;
		const width = canvas.parentElement?.clientWidth || 700;
		canvas.width = width * dpr;
		canvas.height = height * dpr;
		canvas.style.width = `${width}px`;
		canvas.style.height = `${height}px`;
		ctx.save();
		ctx.scale(dpr, dpr);
		ctx.fillStyle = "#070707";
		ctx.fillRect(0, 0, width, height);
		if (candles.length === 0) {
			ctx.restore();
			return;
		}
		const paddingLeft = 16;
		const paddingRight = 80;
		const paddingTop = 28;
		const paddingBottom = 32;
		const chartWidth = width - paddingLeft - paddingRight;
		const chartHeight = height - paddingTop - paddingBottom;
		let minPrice = Infinity;
		let maxPrice = -Infinity;
		for (const b of candles) {
			if (b.low < minPrice) minPrice = b.low;
			if (b.high > maxPrice) maxPrice = b.high;
		}
		if (trade.entry) {
			minPrice = Math.min(minPrice, trade.entry);
			maxPrice = Math.max(maxPrice, trade.entry);
		}
		if (trade.sl) {
			minPrice = Math.min(minPrice, trade.sl);
			maxPrice = Math.max(maxPrice, trade.sl);
		}
		if (trade.tp1) {
			minPrice = Math.min(minPrice, trade.tp1);
			maxPrice = Math.max(maxPrice, trade.tp1);
		}
		if (trade.exitPrice) {
			minPrice = Math.min(minPrice, trade.exitPrice);
			maxPrice = Math.max(maxPrice, trade.exitPrice);
		}
		const priceSpan = maxPrice - minPrice || 1;
		const yMin = minPrice - priceSpan * .08;
		const yRange = maxPrice + priceSpan * .08 - yMin;
		const priceToY = (price) => paddingTop + chartHeight - (price - yMin) / yRange * chartHeight;
		const barCount = candles.length;
		const barWidth = Math.max(4, Math.floor(chartWidth / barCount * .65));
		const barSpacing = chartWidth / barCount;
		const gridLines = 6;
		ctx.lineWidth = 1;
		ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
		ctx.fillStyle = "rgba(162, 162, 160, 0.6)";
		ctx.font = "10px \"IBM Plex Mono\", monospace";
		ctx.textAlign = "left";
		ctx.textBaseline = "middle";
		for (let i = 0; i <= gridLines; i++) {
			const price = yMin + yRange / gridLines * i;
			const y = priceToY(price);
			ctx.beginPath();
			ctx.moveTo(paddingLeft, y);
			ctx.lineTo(width - paddingRight, y);
			ctx.stroke();
			ctx.fillText(price.toFixed(2), width - paddingRight + 8, y);
		}
		const maxVol = Math.max(...candles.map((c) => c.volume || 100), 400);
		const volAreaHeight = chartHeight * .18;
		for (let i = 0; i < barCount; i++) {
			const b = candles[i];
			const x = paddingLeft + i * barSpacing + barSpacing / 2;
			const vHeight = (b.volume || 100) / maxVol * volAreaHeight;
			const vY = paddingTop + chartHeight - vHeight;
			ctx.fillStyle = b.close >= b.open ? "rgba(61, 220, 132, 0.12)" : "rgba(255, 107, 125, 0.12)";
			ctx.fillRect(x - barWidth / 2, vY, barWidth, vHeight);
		}
		for (let i = 0; i < barCount; i++) {
			const b = candles[i];
			const x = paddingLeft + i * barSpacing + barSpacing / 2;
			const isUp = b.close >= b.open;
			const yOpen = priceToY(b.open);
			const yClose = priceToY(b.close);
			const yHigh = priceToY(b.high);
			const yLow = priceToY(b.low);
			const candleTop = Math.min(yOpen, yClose);
			const candleHeight = Math.max(1.5, Math.abs(yClose - yOpen));
			ctx.strokeStyle = isUp ? "#3ddc84" : "#ff6b7d";
			ctx.lineWidth = 1.2;
			ctx.beginPath();
			ctx.moveTo(x, yHigh);
			ctx.lineTo(x, yLow);
			ctx.stroke();
			ctx.fillStyle = isUp ? "#3ddc84" : "#ff6b7d";
			ctx.fillRect(x - barWidth / 2, candleTop, barWidth, candleHeight);
			if (i % 4 === 0 || i === barCount - 1) {
				ctx.fillStyle = "rgba(162, 162, 160, 0.5)";
				ctx.textAlign = "center";
				ctx.fillText(b.time, x, height - 12);
			}
		}
		if (trade.sl != null) {
			const slY = priceToY(trade.sl);
			ctx.save();
			ctx.strokeStyle = "rgba(255, 107, 125, 0.75)";
			ctx.lineWidth = 1.5;
			ctx.setLineDash([4, 4]);
			ctx.beginPath();
			ctx.moveTo(paddingLeft, slY);
			ctx.lineTo(width - paddingRight, slY);
			ctx.stroke();
			ctx.fillStyle = "#ff6b7d";
			ctx.fillRect(width - paddingRight + 4, slY - 8, 72, 16);
			ctx.fillStyle = "#000000";
			ctx.font = "bold 9px \"IBM Plex Mono\", monospace";
			ctx.textAlign = "center";
			ctx.fillText(`SL ${trade.sl.toFixed(1)}`, width - paddingRight + 40, slY + 3);
			ctx.restore();
		}
		const targetPrice = trade.tp1 ?? trade.targetPrice;
		if (targetPrice != null) {
			const tpY = priceToY(targetPrice);
			ctx.save();
			ctx.strokeStyle = "rgba(61, 220, 132, 0.75)";
			ctx.lineWidth = 1.5;
			ctx.setLineDash([4, 4]);
			ctx.beginPath();
			ctx.moveTo(paddingLeft, tpY);
			ctx.lineTo(width - paddingRight, tpY);
			ctx.stroke();
			ctx.fillStyle = "#3ddc84";
			ctx.fillRect(width - paddingRight + 4, tpY - 8, 72, 16);
			ctx.fillStyle = "#000000";
			ctx.font = "bold 9px \"IBM Plex Mono\", monospace";
			ctx.textAlign = "center";
			ctx.fillText(`TP ${targetPrice.toFixed(1)}`, width - paddingRight + 40, tpY + 3);
			ctx.restore();
		}
		let entryX = paddingLeft + 6 * barSpacing + barSpacing / 2;
		let exitX = paddingLeft + (barCount - 5) * barSpacing + barSpacing / 2;
		const foundEntryIdx = candles.findIndex((c) => c.isEntryBar);
		if (foundEntryIdx !== -1) entryX = paddingLeft + foundEntryIdx * barSpacing + barSpacing / 2;
		const foundExitIdx = candles.findIndex((c) => c.isExitBar);
		if (foundExitIdx !== -1) exitX = paddingLeft + foundExitIdx * barSpacing + barSpacing / 2;
		const entryY = trade.entry != null ? priceToY(trade.entry) : priceToY(candles[6]?.close || minPrice);
		const exitY = trade.exitPrice != null ? priceToY(trade.exitPrice) : priceToY(candles[candles.length - 5]?.close || maxPrice);
		ctx.save();
		ctx.strokeStyle = trade.result === "win" ? "rgba(61, 220, 132, 0.4)" : "rgba(255, 107, 125, 0.4)";
		ctx.lineWidth = 1.5;
		ctx.setLineDash([3, 3]);
		ctx.beginPath();
		ctx.moveTo(entryX, entryY);
		ctx.lineTo(exitX, exitY);
		ctx.stroke();
		ctx.restore();
		const isLong = trade.side === "long";
		ctx.save();
		ctx.fillStyle = isLong ? "#3ddc84" : "#ff6b7d";
		ctx.beginPath();
		if (isLong) {
			ctx.moveTo(entryX, entryY + 8);
			ctx.lineTo(entryX - 6, entryY + 18);
			ctx.lineTo(entryX + 6, entryY + 18);
		} else {
			ctx.moveTo(entryX, entryY - 8);
			ctx.lineTo(entryX - 6, entryY - 18);
			ctx.lineTo(entryX + 6, entryY - 18);
		}
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "rgba(0, 0, 0, 0.85)";
		ctx.strokeStyle = isLong ? "#3ddc84" : "#ff6b7d";
		ctx.lineWidth = 1;
		const entryLabel = `BUY @ ${trade.entry?.toFixed(2) ?? "MKT"}`;
		ctx.fillRect(entryX - 35, isLong ? entryY + 20 : entryY - 34, 70, 16);
		ctx.strokeRect(entryX - 35, isLong ? entryY + 20 : entryY - 34, 70, 16);
		ctx.fillStyle = isLong ? "#3ddc84" : "#ff6b7d";
		ctx.font = "bold 9px \"IBM Plex Mono\", monospace";
		ctx.textAlign = "center";
		ctx.fillText(entryLabel, entryX, isLong ? entryY + 31 : entryY - 23);
		ctx.restore();
		ctx.save();
		const isWin = trade.result === "win";
		ctx.fillStyle = isWin ? "#3ddc84" : "#ff6b7d";
		ctx.beginPath();
		if (isLong) {
			ctx.moveTo(exitX, exitY - 8);
			ctx.lineTo(exitX - 6, exitY - 18);
			ctx.lineTo(exitX + 6, exitY - 18);
		} else {
			ctx.moveTo(exitX, exitY + 8);
			ctx.lineTo(exitX - 6, exitY + 18);
			ctx.lineTo(exitX + 6, exitY + 18);
		}
		ctx.closePath();
		ctx.fill();
		ctx.fillStyle = "rgba(0, 0, 0, 0.85)";
		ctx.strokeStyle = isWin ? "#3ddc84" : "#ff6b7d";
		ctx.lineWidth = 1;
		const exitLabel = `EXIT (${trade.rMultiple != null ? `${trade.rMultiple > 0 ? "+" : ""}${trade.rMultiple.toFixed(2)}R` : "EXIT"})`;
		ctx.fillRect(exitX - 36, isLong ? exitY - 34 : exitY + 20, 72, 16);
		ctx.strokeRect(exitX - 36, isLong ? exitY - 34 : exitY + 20, 72, 16);
		ctx.fillStyle = isWin ? "#3ddc84" : "#ff6b7d";
		ctx.font = "bold 9px \"IBM Plex Mono\", monospace";
		ctx.textAlign = "center";
		ctx.fillText(exitLabel, exitX, isLong ? exitY - 23 : exitY + 31);
		ctx.restore();
		if (showExcursions && trade.entry && trade.sl) {
			const riskDist = Math.abs(trade.entry - trade.sl);
			if (trade.mfeR) {
				const mfeY = priceToY(isLong ? trade.entry + trade.mfeR * riskDist : trade.entry - trade.mfeR * riskDist);
				ctx.save();
				ctx.strokeStyle = "rgba(34, 211, 238, 0.6)";
				ctx.lineWidth = 1;
				ctx.setLineDash([2, 3]);
				ctx.beginPath();
				ctx.moveTo(entryX, mfeY);
				ctx.lineTo(width - paddingRight, mfeY);
				ctx.stroke();
				ctx.fillStyle = "rgba(34, 211, 238, 0.85)";
				ctx.font = "9px \"IBM Plex Mono\", monospace";
				ctx.textAlign = "left";
				ctx.fillText(`MFE +${trade.mfeR.toFixed(1)}R`, width - paddingRight + 6, mfeY - 2);
				ctx.restore();
			}
			if (trade.maeR) {
				const maeY = priceToY(isLong ? trade.entry + trade.maeR * riskDist : trade.entry - trade.maeR * riskDist);
				ctx.save();
				ctx.strokeStyle = "rgba(245, 185, 66, 0.6)";
				ctx.lineWidth = 1;
				ctx.setLineDash([2, 3]);
				ctx.beginPath();
				ctx.moveTo(entryX, maeY);
				ctx.lineTo(width - paddingRight, maeY);
				ctx.stroke();
				ctx.fillStyle = "rgba(245, 185, 66, 0.85)";
				ctx.font = "9px \"IBM Plex Mono\", monospace";
				ctx.textAlign = "left";
				ctx.fillText(`MAE ${trade.maeR.toFixed(1)}R`, width - paddingRight + 6, maeY + 9);
				ctx.restore();
			}
		}
		if (hoverPos) {
			ctx.save();
			ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
			ctx.lineWidth = 1;
			ctx.setLineDash([3, 3]);
			ctx.beginPath();
			ctx.moveTo(hoverPos.x, paddingTop);
			ctx.lineTo(hoverPos.x, height - paddingBottom);
			ctx.stroke();
			ctx.beginPath();
			ctx.moveTo(paddingLeft, hoverPos.y);
			ctx.lineTo(width - paddingRight, hoverPos.y);
			ctx.stroke();
			ctx.fillStyle = "#ffffff";
			ctx.fillRect(width - paddingRight, hoverPos.y - 8, 76, 16);
			ctx.fillStyle = "#000000";
			ctx.font = "bold 9px \"IBM Plex Mono\", monospace";
			ctx.textAlign = "center";
			ctx.fillText(hoverPos.price.toFixed(2), width - paddingRight + 38, hoverPos.y + 3);
			ctx.restore();
		}
		ctx.restore();
	}, [
		candles,
		trade,
		height,
		showExcursions,
		hoverPos
	]);
	const handleMouseMove = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const x = e.clientX - rect.left;
		const y = e.clientY - rect.top;
		const paddingLeft = 16;
		const paddingRight = 80;
		const paddingTop = 28;
		const paddingBottom = 32;
		const chartWidth = canvas.clientWidth - paddingLeft - paddingRight;
		const chartHeight = canvas.clientHeight - paddingTop - paddingBottom;
		if (x < paddingLeft || x > canvas.clientWidth - paddingRight || y < paddingTop || y > canvas.clientHeight - paddingBottom) {
			setHoverPos(null);
			setHoverBar(null);
			return;
		}
		const barSpacing = chartWidth / candles.length;
		const barIndex = Math.min(candles.length - 1, Math.max(0, Math.floor((x - paddingLeft) / barSpacing)));
		const bar = candles[barIndex];
		let minPrice = Infinity;
		let maxPrice = -Infinity;
		for (const b of candles) {
			if (b.low < minPrice) minPrice = b.low;
			if (b.high > maxPrice) maxPrice = b.high;
		}
		const priceSpan = maxPrice - minPrice || 1;
		const yMin = minPrice - priceSpan * .08;
		const yMax = maxPrice + priceSpan * .08;
		const price = yMin + (paddingTop + chartHeight - y) / chartHeight * (yMax - yMin);
		setHoverPos({
			x,
			y,
			price
		});
		setHoverBar(bar);
	};
	const handleMouseLeave = () => {
		setHoverPos(null);
		setHoverBar(null);
	};
	const pnl = getTradePnL(trade);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: containerRef,
		className: `relative flex flex-col rounded-md border border-white/[0.08] bg-[#070707] shadow-inner ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between border-b border-white/[0.06] px-3 py-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-semibold tracking-wide text-foreground",
							children: trade.market
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider ${trade.side === "long" ? "bg-up/20 text-up" : "bg-down/20 text-down"}`,
							children: trade.side
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-mono text-[11px] text-muted-foreground",
							children: [
								trade.date,
								" · ",
								trade.session || "NY"
							]
						}),
						trade.result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: `rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${trade.result === "win" ? "bg-up/15 text-up border border-up/30" : trade.result === "loss" ? "bg-down/15 text-down border border-down/30" : "bg-white/10 text-muted-foreground"}`,
							children: [
								trade.result,
								" ",
								pnl !== 0 && `(${formatCurrency(pnl)})`
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [[
						"1m",
						"5m",
						"15m",
						"1H"
					].map((tf) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTimeframe(tf),
						className: `rounded px-2 py-0.5 font-mono text-[10px] transition-colors ${timeframe === tf ? "bg-white/20 text-foreground font-bold" : "text-muted-foreground hover:bg-white/10 hover:text-foreground"}`,
						children: tf
					}, tf)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						onClick: downloadSnapshot,
						title: "Download Chart Snapshot",
						className: "h-6 w-6 text-muted-foreground hover:text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute left-4 top-10 z-10 flex flex-wrap gap-2 text-[10px] font-mono",
				children: hoverBar ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded bg-black/80 px-2 py-1 border border-white/10 backdrop-blur-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: hoverBar.time
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["O: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: hoverBar.open.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["H: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: hoverBar.high.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["L: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: hoverBar.low.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["C: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: hoverBar.close >= hoverBar.open ? "text-up" : "text-down",
							children: hoverBar.close.toFixed(2)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: ["Vol: ", hoverBar.volume]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Entry: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: trade.entry?.toFixed(2) ?? "—"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Exit: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: trade.exitPrice?.toFixed(2) ?? "—"
						})] }),
						trade.sl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["SL: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-down",
							children: trade.sl.toFixed(2)
						})] }),
						trade.tp1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["TP: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-up",
							children: trade.tp1.toFixed(2)
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				onMouseMove: handleMouseMove,
				onMouseLeave: handleMouseLeave,
				className: "cursor-crosshair w-full block"
			})
		]
	});
}
function TradeInspectorDialog({ trade, open, onOpenChange, models, onEditTrade, onDeleteTrade, onUpdateTrade }) {
	if (!trade) return null;
	const model = models.find((m) => m.id === trade.modelId || m.name === trade.modelName);
	const rules = (0, import_react.useMemo)(() => model ? getPlaybookRules(model) : [], [model]);
	const pnl = getTradePnL(trade);
	const duration = getTradeHoldDuration(trade);
	const efficiency = getTradeEfficiency(trade);
	const adherence = calculateTradeRuleAdherence(trade, model);
	const toggleRule = (ruleId) => {
		const current = trade.ruleChecklist ?? {};
		const updated = {
			...current,
			[ruleId]: !current[ruleId]
		};
		const followedCount = rules.filter((r) => updated[r.id] === true).length;
		const adherencePct = rules.length > 0 ? Math.round(followedCount / rules.length * 100) : 100;
		onUpdateTrade({
			...trade,
			ruleChecklist: updated,
			ruleAdherencePct: adherencePct,
			ruleFollowed: adherencePct >= 80
		});
		toast.success("Rule checklist updated");
	};
	const isWin = trade.result === "win";
	const isLoss = trade.result === "loss";
	const isLong = trade.side === "long";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-4xl max-h-[90vh] overflow-y-auto bg-[#0a0a0a] border-white/10 p-0 text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-white/[0.08] p-5 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `flex items-center gap-1 rounded px-2.5 py-1 text-xs font-bold uppercase tracking-wider ${isLong ? "bg-up/20 text-up border border-up/30" : "bg-down/20 text-down border border-down/30"}`,
								children: [
									trade.side,
									" ",
									trade.market
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `rounded px-2.5 py-1 text-xs font-semibold uppercase ${isWin ? "bg-up/15 text-up border border-up/30" : isLoss ? "bg-down/15 text-down border border-down/30" : "bg-white/10 text-muted-foreground"}`,
								children: [
									trade.result,
									" ",
									trade.rMultiple != null && `(${formatR(trade.rMultiple)})`
								]
							}),
							trade.modelName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "default",
								className: "border-white/15 bg-white/[0.04] text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "mr-1 size-3 text-accent" }), trade.modelName]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							className: "h-8 border-white/15 text-xs hover:bg-white/10",
							onClick: () => {
								onOpenChange(false);
								onEditTrade(trade);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-1 size-3.5" }), " Edit"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "h-8 text-xs text-destructive hover:bg-destructive/15",
							onClick: () => {
								if (confirm("Delete this trade record?")) {
									onDeleteTrade(trade.id);
									onOpenChange(false);
									toast.success("Trade removed");
								}
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mr-1 size-3.5" }), " Delete"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-medium text-muted-foreground uppercase tracking-wider",
								children: "Net P&L"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-0.5 font-mono text-base font-bold ${pnl > 0 ? "text-up" : pnl < 0 ? "text-down" : "text-muted-foreground"}`,
								children: formatCurrency(pnl)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-medium text-muted-foreground uppercase tracking-wider",
								children: "Realized R"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-0.5 font-mono text-base font-bold ${trade.rMultiple && trade.rMultiple > 0 ? "text-up" : trade.rMultiple && trade.rMultiple < 0 ? "text-down" : "text-muted-foreground"}`,
								children: trade.rMultiple != null ? formatR(trade.rMultiple) : "—"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-medium text-muted-foreground uppercase tracking-wider",
								children: "Hold Duration"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 flex items-center gap-1 font-mono text-base font-semibold text-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 text-muted-foreground" }),
									" ",
									duration
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-medium text-muted-foreground uppercase tracking-wider",
								children: "Rule Adherence"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: `mt-0.5 font-mono text-base font-bold ${adherence.adherencePct >= 80 ? "text-up" : adherence.adherencePct >= 60 ? "text-warn" : "text-down"}`,
								children: [adherence.adherencePct, "%"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.06] bg-white/[0.02] p-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-medium text-muted-foreground uppercase tracking-wider",
								children: "Efficiency"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 font-mono text-base font-bold text-cyan-400",
								children: [efficiency, "%"]
							})]
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase",
							children: "Execution Chart & Price Trajectory"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted-foreground",
							children: "Hover over candles for OHLCV & Crosshair"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeCanvasChart, {
						trade,
						height: 340
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-4 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase mb-3",
								children: "Excursions (TradeZella MAE / MFE)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-xs mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-cyan-400 font-medium",
											children: "MFE (Peak Potential)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-foreground font-semibold",
											children: trade.mfeR != null ? `+${trade.mfeR.toFixed(2)}R` : "—"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1.5 w-full rounded-full bg-white/10 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-cyan-400 rounded-full",
											style: { width: `${Math.min(100, (trade.mfeR ?? 0) / 4 * 100)}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-[11px] text-muted-foreground",
										children: "Highest unrealized profit reached before exit."
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-xs mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-amber-400 font-medium",
											children: "MAE (Heat Endured)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-foreground font-semibold",
											children: trade.maeR != null ? `${trade.maeR.toFixed(2)}R` : "—"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1.5 w-full rounded-full bg-white/10 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-amber-400 rounded-full",
											style: { width: `${Math.min(100, Math.abs(trade.maeR ?? 0) * 100)}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-[11px] text-muted-foreground",
										children: "Maximum drawdown dip during trade lifecycle."
									})
								] })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase mb-3",
								children: "Execution Prices & Metrics"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-y-2.5 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Entry Price:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-semibold text-foreground",
										children: trade.entry != null ? trade.entry.toFixed(2) : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Exit Price:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-semibold text-foreground",
										children: trade.exitPrice != null ? trade.exitPrice.toFixed(2) : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Stop Loss:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-semibold text-down",
										children: trade.sl != null ? trade.sl.toFixed(2) : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Take Profit:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono font-semibold text-up",
										children: trade.tp1 != null ? trade.tp1.toFixed(2) : "—"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Execution Quality:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold capitalize text-foreground",
										children: trade.executionQuality || "Optimal"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Emotional State:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold capitalize text-accent",
										children: trade.emotion || "Calm"
									})] })
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase",
								children: "Playbook Rule Adherence Checklist"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground",
								children: "TradeZella tracks whether you respected your pre-defined strategy rules."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "default",
								className: `font-mono text-xs ${adherence.adherencePct >= 80 ? "border-up/40 bg-up/10 text-up" : "border-warn/40 bg-warn/10 text-warn"}`,
								children: [
									adherence.followed,
									" of ",
									adherence.total,
									" rules followed (",
									adherence.adherencePct,
									"%)"
								]
							})]
						}), rules.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground py-2",
							children: "No playbook setup linked to this trade. Assign a playbook to track rule adherence."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
							children: rules.map((rule) => {
								const isChecked = trade.ruleChecklist?.[rule.id] ?? trade.ruleFollowed;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => toggleRule(rule.id),
									className: `flex items-start gap-2.5 rounded-md border p-2.5 text-left text-xs transition-colors ${isChecked ? "border-up/30 bg-up/[0.04] text-foreground hover:bg-up/[0.08]" : "border-white/10 bg-white/[0.01] text-muted-foreground hover:bg-white/[0.04]"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5",
										children: isChecked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-up shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4 text-muted-foreground/60 shrink-0" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block leading-snug",
											children: rule.text
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-mono uppercase text-muted-foreground",
											children: [
												rule.category.replace("_", " "),
												" · ",
												rule.isMandatory ? "Mandatory" : "Confluence"
											]
										})]
									})]
								}, rule.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase mb-2",
							children: "Tags & Mistake Attribution"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1.5",
							children: [
								trade.taken?.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded bg-accent/15 px-2 py-0.5 text-xs font-medium text-accent border border-accent/20",
									children: ["#", tag]
								}, tag)),
								trade.pdArray && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded bg-white/10 px-2 py-0.5 text-xs text-foreground",
									children: trade.pdArray
								}),
								trade.session && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded bg-white/10 px-2 py-0.5 text-xs text-muted-foreground",
									children: [trade.session, " Session"]
								}),
								trade.errors?.filter((e) => e !== "No actual error").map((err) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded bg-destructive/20 px-2 py-0.5 text-xs text-destructive border border-destructive/30",
									children: ["Mistake: ", err]
								}, err)),
								(!trade.errors || trade.errors.every((e) => e === "No actual error")) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded bg-up/10 px-2 py-0.5 text-xs text-up border border-up/20",
									children: "Clean Execution (No mistakes)"
								})
							]
						})]
					}),
					trade.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-md border border-white/[0.08] bg-white/[0.02] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "text-xs font-semibold tracking-wider text-muted-foreground uppercase mb-1.5",
							children: "Journal Notes & Thesis"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-foreground whitespace-pre-wrap font-sans",
							children: trade.notes
						})]
					})
				]
			})]
		})
	});
}
function CalendarPanel({ trades, missed, models, onLogTrade, onLogMissed, onEditTrade, onDeleteTrade, onUpdateTrade }) {
	const todayKey = formatDateKey(/* @__PURE__ */ new Date());
	const [month, setMonth] = (0, import_react.useState)(() => {
		const now = /* @__PURE__ */ new Date();
		return new Date(now.getFullYear(), now.getMonth(), 1);
	});
	const [selectedDate, setSelectedDate] = (0, import_react.useState)(todayKey);
	const [dailyDrawerOpen, setDailyDrawerOpen] = (0, import_react.useState)(false);
	const [inspectTrade, setInspectTrade] = (0, import_react.useState)(null);
	const counts = (0, import_react.useMemo)(() => buildEntriesByDate(trades, missed), [trades, missed]);
	const monthKey = formatDateKey(month).slice(0, 7);
	const monthTrades = trades.filter((trade) => trade.date.startsWith(monthKey));
	const monthMissed = missed.filter((trade) => trade.date.startsWith(monthKey));
	const netR = netROf(monthTrades);
	const activeDays = activeDayCount(monthTrades, monthMissed);
	const monthDollarPnL = monthTrades.reduce((sum, t) => sum + getTradePnL(t), 0);
	const wins = monthTrades.filter((t) => t.result === "win").length;
	const winRate = monthTrades.length > 0 ? Math.round(wins / monthTrades.length * 100) : 0;
	const shift = (delta) => {
		const next = new Date(month.getFullYear(), month.getMonth() + delta, 1);
		setMonth(next);
		setSelectedDate(formatDateKey(next));
	};
	const handleSelectDate = (dateKey) => {
		setSelectedDate(dateKey);
		setDailyDrawerOpen(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			kicker: "TradeZella Performance Heatmap",
			title: month.toLocaleDateString(void 0, {
				month: "long",
				year: "numeric"
			}),
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => {
							const now = /* @__PURE__ */ new Date();
							setMonth(new Date(now.getFullYear(), now.getMonth(), 1));
							setSelectedDate(todayKey);
						},
						children: "Today"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Previous month",
						onClick: () => shift(-1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "aria-hidden": "true" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Next month",
						onClick: () => shift(1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "aria-hidden": "true" })
					})
				]
			}),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "Month Net P&L",
							value: formatCurrency(monthDollarPnL),
							tone: monthDollarPnL > 0 ? "up" : monthDollarPnL < 0 ? "down" : "default"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "Net R",
							value: formatR(netR),
							tone: netR > 0 ? "up" : netR < 0 ? "down" : "default"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "Win Rate",
							value: monthTrades.length > 0 ? `${winRate}%` : "—",
							tone: winRate >= 50 ? "up" : "warn"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
							label: "Active Days",
							value: `${activeDays} days`,
							tone: "default"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthGrid, {
					month,
					counts,
					trades,
					selectedDate,
					todayKey,
					onSelectDate: handleSelectDate
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.08] pt-3 text-[11px] text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded bg-up/40 border border-up/70" }), " Profitable Day"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded bg-down/40 border border-down/70" }), " Loss Day"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded bg-white/10 border border-white/20" }), " No trades / BE"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "Tip: Click any calendar day to pop open its full Daily Journal & executed trades."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectedDay, {
					date: selectedDate,
					trades: trades.filter((t) => t.date === selectedDate),
					missed: missed.filter((m) => m.date === selectedDate),
					onLogTrade: () => onLogTrade(selectedDate),
					onLogMissed: () => onLogMissed(selectedDate),
					className: "mt-4"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DailyDrawer, {
			date: selectedDate,
			open: dailyDrawerOpen,
			onOpenChange: setDailyDrawerOpen,
			trades,
			missed,
			onSelectTrade: (trade) => setInspectTrade(trade),
			onLogTrade: (date) => onLogTrade(date),
			onLogMissed: (date) => onLogMissed(date)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeInspectorDialog, {
			trade: inspectTrade,
			open: Boolean(inspectTrade),
			onOpenChange: (open) => !open && setInspectTrade(null),
			models: models ?? [],
			onEditTrade: (t) => onEditTrade?.(t),
			onDeleteTrade: (id) => onDeleteTrade?.(id),
			onUpdateTrade: (t) => onUpdateTrade?.(t)
		})
	] });
}
function QuarterPanel({ trades, missed, onLogTrade, onLogMissed }) {
	const todayKey = formatDateKey(/* @__PURE__ */ new Date());
	const [quarterStart, setQuarterStart] = (0, import_react.useState)(() => getQuarterStart(/* @__PURE__ */ new Date()));
	const [selectedDate, setSelectedDate] = (0, import_react.useState)(todayKey);
	const counts = (0, import_react.useMemo)(() => buildEntriesByDate(trades, missed), [trades, missed]);
	const months = Array.from({ length: 3 }, (_, index) => {
		const month = new Date(quarterStart.getFullYear(), quarterStart.getMonth() + index, 1);
		const key = formatDateKey(month).slice(0, 7);
		const monthTrades = trades.filter((trade) => trade.date.startsWith(key));
		const monthMissed = missed.filter((row) => row.date.startsWith(key));
		return {
			month,
			key,
			trades: monthTrades,
			missed: monthMissed,
			netR: netROf(monthTrades),
			activeDays: activeDayCount(monthTrades, monthMissed)
		};
	});
	const quarterTrades = months.flatMap((month) => month.trades);
	const quarterMissed = months.flatMap((month) => month.missed);
	const quarterNetR = months.reduce((total, month) => total + month.netR, 0);
	const quarterActiveDays = activeDayCount(quarterTrades, quarterMissed);
	const shift = (delta) => setQuarterStart(new Date(quarterStart.getFullYear(), quarterStart.getMonth() + delta, 1));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "Quarter overview",
		title: `Q${Math.floor(quarterStart.getMonth() / 3) + 1} ${quarterStart.getFullYear()}`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					size: "sm",
					onClick: () => setQuarterStart(getQuarterStart(/* @__PURE__ */ new Date())),
					children: "This quarter"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					"aria-label": "Previous quarter",
					onClick: () => shift(-3),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { "aria-hidden": "true" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					"aria-label": "Next quarter",
					onClick: () => shift(3),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "aria-hidden": "true" })
				})
			]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-2 gap-1.5 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Taken",
						value: String(quarterTrades.length),
						tone: "up"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Missed",
						value: String(quarterMissed.length),
						tone: "warn"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Net R",
						value: formatR(quarterNetR),
						tone: quarterNetR > 0 ? "up" : quarterNetR < 0 ? "down" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						label: "Active days",
						value: String(quarterActiveDays)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2.5 lg:grid-cols-3",
				children: months.map(({ month, key, netR, activeDays }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": `${month.toLocaleDateString(void 0, {
						month: "long",
						year: "numeric"
					})}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-end justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-lg leading-none tracking-wide text-foreground",
							children: month.toLocaleDateString(void 0, { month: "long" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-[11px] text-muted-foreground",
							children: [
								activeDays,
								" active ",
								activeDays === 1 ? "day" : "days"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("font-mono text-sm font-semibold tabular-nums", netR > 0 ? "text-up" : netR < 0 ? "text-down" : "text-muted-foreground"),
							children: formatR(netR)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MonthGrid, {
						month,
						counts,
						selectedDate,
						todayKey,
						onSelectDate: setSelectedDate,
						compact: true
					})]
				}, key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-[11px] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-1.5 rounded-full bg-up",
							"aria-hidden": "true"
						}), " Taken"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-1.5 rounded-full bg-warn",
							"aria-hidden": "true"
						}), " Missed"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-1.5 rounded-full bg-accent",
							"aria-hidden": "true"
						}), " Today"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectedDay, {
				className: "mt-5",
				date: selectedDate,
				trades: trades.filter((trade) => trade.date === selectedDate),
				missed: missed.filter((row) => row.date === selectedDate),
				onLogTrade,
				onLogMissed
			})
		]
	});
}
/**
* Missed setups are research rows too — the reason matters as much as the
* outcome that would have followed.
*/
function MissedPanel({ missed, onEdit, onDelete, onAdd }) {
	const sorted = missed.slice().sort((a, b) => `${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-3 flex justify-end",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			onClick: onAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "aria-hidden": "true" }), " Log missed"]
		})
	}), sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl border border-dashed border-white/[0.12] px-4 py-10 text-center text-sm text-muted-foreground",
		children: "No missed setups recorded."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: sorted.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "overflow-hidden rounded-xl border border-white/[0.09] bg-card/85 transition-colors hover:border-white/[0.18]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-0.5 w-full bg-warn/60",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[11px] text-muted-foreground",
							children: [
								row.date,
								" · ",
								row.time,
								" NY"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "warn",
							children: "Missed opportunity"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-1.5 font-display text-2xl tracking-tight text-foreground",
						children: [
							row.market,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-accent uppercase",
								children: row.side
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1.5 text-sm text-foreground/90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Hesitation:"
							}),
							" ",
							row.why || "—",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-1.5 text-white/25",
								children: "→"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground",
								children: row.outcome || "unknown"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: row.narrativeValid ? "up" : "down",
								children: ["Narrative ", row.narrativeValid ? "valid" : "invalid"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: row.liquiditySwept ? "up" : "default",
								children: ["Sweep ", row.liquiditySwept ? "yes" : "no"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: row.triggerOccurred ? "up" : "default",
								children: ["Trigger ", row.triggerOccurred ? "fired" : "no"]
							})
						]
					}),
					row.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 rounded-md border border-white/[0.07] bg-black/40 p-3 text-xs leading-relaxed text-muted-foreground",
						children: [
							"“",
							row.notes,
							"”"
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2 border-t border-white/[0.06] pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => onEdit(row),
							children: "Edit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => onDelete(row.id),
							className: "hover:text-down",
							children: "Delete"
						})]
					})
				]
			})]
		}, row.id))
	})] });
}
function one(v) {
	return Array.isArray(v) ? v[0] : v;
}
function MissedForm({ open, onOpenChange, row }) {
	const upsert = useDeskStore((s) => s.upsertMissed);
	const [form, setForm] = (0, import_react.useState)(emptyMissed(todayISO(), nowHHMM()));
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setForm(row ?? emptyMissed(todayISO(), nowHHMM()));
	}, [open, row]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: row ? "Edit missed trade" : "Missed trade" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Hesitation is data. Record the setup you saw and what price did without you." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Date",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: form.date,
									onChange: (e) => setForm({
										...form,
										date: e.target.value
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Time (NY)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "time",
									value: form.time,
									onChange: (e) => setForm({
										...form,
										time: e.target.value
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Market",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: form.market,
									onChange: (e) => setForm({
										...form,
										market: e.target.value
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Side",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
									options: ["long", "short"],
									value: form.side,
									onChange: (v) => setForm({
										...form,
										side: one(v)
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
									label: "Narrative valid",
									value: form.narrativeValid,
									onChange: (v) => setForm({
										...form,
										narrativeValid: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
									label: "Liquidity swept",
									value: form.liquiditySwept,
									onChange: (v) => setForm({
										...form,
										liquiditySwept: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
									label: "PD array present",
									value: form.pdArrayPresent,
									onChange: (v) => setForm({
										...form,
										pdArrayPresent: v
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
									label: "Trigger occurred",
									value: form.triggerOccurred,
									onChange: (v) => setForm({
										...form,
										triggerOccurred: v
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Why I didn't enter",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: MISS_REASONS,
								value: form.why,
								onChange: (v) => setForm({
									...form,
									why: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What happened after",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: MISS_OUTCOMES,
								value: form.outcome,
								onChange: (v) => setForm({
									...form,
									outcome: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: form.notes,
								onChange: (e) => setForm({
									...form,
									notes: e.target.value
								})
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						upsert(form);
						toast.success("Missed trade saved");
						onOpenChange(false);
					},
					children: "Save"
				}) })
			]
		})
	});
}
function JournalPage() {
	const trades = useDeskStore((s) => s.trades);
	const missed = useDeskStore((s) => s.missed);
	const removeMissed = useDeskStore((s) => s.removeMissed);
	const [activeTab, setActiveTab] = (0, import_react.useState)("all");
	const [selectedTrade, setSelectedTrade] = (0, import_react.useState)(null);
	const [tradeFormOpen, setTradeFormOpen] = (0, import_react.useState)(false);
	const [editingTrade, setEditingTrade] = (0, import_react.useState)(null);
	const [selectedDayDate, setSelectedDayDate] = (0, import_react.useState)(() => todayISO());
	const [missedOpen, setMissedOpen] = (0, import_react.useState)(false);
	const [editMissed, setEditMissed] = (0, import_react.useState)(null);
	const sortedTrades = (0, import_react.useMemo)(() => {
		return trades.slice().sort((a, b) => {
			const timeA = `${a.date}T${a.time || "00:00"}`;
			return `${b.date}T${b.time || "00:00"}`.localeCompare(timeA);
		});
	}, [trades]);
	const selectedIndex = selectedTrade ? sortedTrades.findIndex((t) => t.id === selectedTrade.id) : -1;
	const hasPrev = selectedIndex > 0;
	const hasNext = selectedIndex !== -1 && selectedIndex < sortedTrades.length - 1;
	const handlePrevTrade = () => {
		if (hasPrev) setSelectedTrade(sortedTrades[selectedIndex - 1]);
	};
	const handleNextTrade = () => {
		if (hasNext) setSelectedTrade(sortedTrades[selectedIndex + 1]);
	};
	const openLogTrade = () => {
		setEditingTrade(null);
		setTradeFormOpen(true);
	};
	const openEditTrade = (t) => {
		setEditingTrade(t);
		setTradeFormOpen(true);
	};
	const openNewMissed = () => {
		setEditMissed(null);
		setMissedOpen(true);
	};
	const openEditMissed = (row) => {
		setEditMissed(row);
		setMissedOpen(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-[1152px] px-4 pt-6 sm:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-12 items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-[36px] leading-none tracking-tight text-white",
					children: "Journal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: openLogTrade,
					className: "flex h-9 items-center gap-1.5 rounded-md bg-[#e50914] px-3.5 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] transition-colors hover:brightness-110",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Log trade" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: activeTab,
				onValueChange: (val) => setActiveTab(val),
				className: "mt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "flex h-10 items-end gap-6 border-b border-white/[0.07] bg-transparent p-0 text-[11px] font-semibold tracking-[0.14em] uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "all",
								className: "rounded-none border-b-2 border-transparent bg-transparent px-0 pb-2.5 text-[#a2a2a0] shadow-none data-[state=active]:border-[#e50914] data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none",
								children: ["All ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono ml-1 text-[#a2a2a0]",
									children: trades.length
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "day",
								className: "rounded-none border-b-2 border-transparent bg-transparent px-0 pb-2.5 text-[#a2a2a0] shadow-none data-[state=active]:border-[#e50914] data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none",
								children: "Day"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "calendar",
								className: "rounded-none border-b-2 border-transparent bg-transparent px-0 pb-2.5 text-[#a2a2a0] shadow-none data-[state=active]:border-[#e50914] data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none",
								children: "Calendar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "quarter",
								className: "rounded-none border-b-2 border-transparent bg-transparent px-0 pb-2.5 text-[#a2a2a0] shadow-none data-[state=active]:border-[#e50914] data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none",
								children: "Quarter"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "missed",
								className: "rounded-none border-b-2 border-transparent bg-transparent px-0 pb-2.5 text-[#a2a2a0] shadow-none data-[state=active]:border-[#e50914] data-[state=active]:bg-transparent data-[state=active]:text-white data-[state=active]:shadow-none",
								children: ["Missed ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono ml-1 text-[#a2a2a0]",
									children: missed.length
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "all",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AllView, {
							trades,
							selectedTradeId: selectedTrade?.id ?? null,
							onSelectTrade: setSelectedTrade,
							onEditTrade: openEditTrade
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "day",
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayView, {
							trades,
							selectedDate: selectedDayDate,
							onSelectDate: setSelectedDayDate,
							onSelectTrade: setSelectedTrade,
							onEditTrade: openEditTrade
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "calendar",
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPanel, {
							trades,
							missed,
							onLogTrade: openLogTrade,
							onLogMissed: openNewMissed
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "quarter",
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuarterPanel, {
							trades,
							missed,
							onLogTrade: openLogTrade,
							onLogMissed: openNewMissed
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "missed",
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissedPanel, {
							missed,
							onEdit: openEditMissed,
							onDelete: removeMissed,
							onAdd: openNewMissed
						})
					})
				]
			})]
		}),
		selectedTrade && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeInspector, {
			trade: selectedTrade,
			onClose: () => setSelectedTrade(null),
			onEdit: openEditTrade,
			onPrev: handlePrevTrade,
			onNext: handleNextTrade,
			hasPrev,
			hasNext
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeFormModal, {
			open: tradeFormOpen,
			onOpenChange: setTradeFormOpen,
			trade: editingTrade,
			onSaved: (saved) => {
				if (selectedTrade?.id === saved.id) setSelectedTrade(saved);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissedForm, {
			open: missedOpen,
			onOpenChange: setMissedOpen,
			row: editMissed
		})
	] });
}
//#endregion
export { JournalPage as component };
