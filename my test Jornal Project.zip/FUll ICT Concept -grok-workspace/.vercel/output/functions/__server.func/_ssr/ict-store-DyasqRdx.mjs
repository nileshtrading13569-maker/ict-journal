import { c as deskSnapshot } from "./router-CdjogOIb.mjs";
export { deskSnapshot };
