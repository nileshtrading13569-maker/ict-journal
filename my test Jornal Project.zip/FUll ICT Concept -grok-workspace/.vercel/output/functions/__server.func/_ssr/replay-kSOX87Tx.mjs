import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as cn, j as Button, l as useDeskStore, z as formatR } from "./router-CdjogOIb.mjs";
import { S as RangeBar, i as Chips, k as closedTrades, n as Badge, t as AppShell, x as Panel } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/replay-kSOX87Tx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GUESSES = [
	"raid BSL",
	"raid SSL",
	"continuation",
	"reversal",
	"no trade"
];
function ReplayPage() {
	const trades = useDeskStore((s) => s.trades);
	const closed = (0, import_react.useMemo)(() => closedTrades(trades).slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`)), [trades]);
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [guess, setGuess] = (0, import_react.useState)("");
	const [revealed, setRevealed] = (0, import_react.useState)(false);
	const trade = closed[idx];
	function next() {
		setIdx((i) => closed.length ? (i + 1) % closed.length : 0);
		setGuess("");
		setRevealed(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Replay",
		title: "What should happen next?",
		description: "Read the narrative. Pick a delivery. Then reveal what actually paid — or didn’t.",
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-[11px] text-muted-foreground",
			children: "Result hidden"
		})
	}), !trade ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Log closed trades to replay them."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Case ",
					idx + 1,
					" of ",
					closed.length,
					" · ",
					trade.date,
					" · ",
					trade.market,
					" · result hidden"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HiddenCase, {
				trade,
				revealed
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Your call",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
					options: GUESSES,
					value: guess,
					onChange: (v) => setGuess(Array.isArray(v) ? v[0] : v)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: !guess,
						onClick: () => setRevealed(true),
						children: "Reveal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: next,
						children: "Next case"
					})]
				})]
			}),
			revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				trade,
				guess
			}) : null
		]
	})] });
}
function HiddenCase({ trade, revealed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: `${trade.session} · ${trade.killZone}`,
		title: "Before the fill",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Weekly bias",
						v: trade.weeklyBias
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Daily bias",
						v: trade.dailyBias
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Draw",
						v: trade.drawOnLiquidity || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Location",
						v: trade.location
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Taken so far",
						v: trade.taken.join(", ") || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "PD array",
						v: `${trade.pdTimeframe} ${trade.pdArray}`.trim() || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Time model",
						v: trade.timeModel || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Structure",
						v: trade.structureBefore || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Model",
						v: trade.modelName || "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeBar, {
					range: trade.dealingRange,
					mark: revealed ? trade.entry : trade.dealingRange.current
				})
			}),
			trade.screenshotHtf ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: ["HTF note: ", trade.screenshotHtf]
			}) : null
		]
	});
}
function Reveal({ trade, guess }) {
	const actual = trade.side === "short" && trade.taken.some((t) => t.includes("H") || t === "BSL" || t === "PWH") ? "reversal" : trade.side === "long" ? "reversal" : "continuation";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		kicker: "After",
		title: "What happened",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: (trade.rMultiple ?? 0) > 0 ? "up" : "down",
						children: [
							trade.side,
							" · ",
							trade.rMultiple == null ? "—" : formatR(trade.rMultiple)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: trade.modelName }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: trade.primaryError === "No actual error" ? "up" : "warn",
						children: trade.primaryError || "unlabeled"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"You called ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: guess || "nothing"
					}),
					". Price",
					" ",
					trade.side === "long" ? "expanded higher" : "expanded lower",
					" from ",
					trade.location,
					" after",
					" ",
					trade.taken.join(", ") || "no tagged sweep",
					". Triggers: ",
					trade.triggers.join(" · ") || "—",
					"."
				]
			}),
			trade.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: trade.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("mt-3 text-xs", guess && actual ? "text-muted-foreground" : ""),
				children: [
					"Delivery read as ",
					actual,
					" for this sample — use it as a prompt, not a score."
				]
			})
		]
	});
}
function Item({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-muted-foreground",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "capitalize",
		children: v
	})] });
}
//#endregion
export { ReplayPage as component };
