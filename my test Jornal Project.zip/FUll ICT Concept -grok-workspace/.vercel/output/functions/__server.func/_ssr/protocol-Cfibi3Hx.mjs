import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as cn, j as Button, l as useDeskStore } from "./router-CdjogOIb.mjs";
import { K as protocolDayNumber, Z as todayProtocol, n as Badge, q as remainingRToDanger, t as AppShell, w as Textarea, x as Panel } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/protocol-Cfibi3Hx.js
var import_jsx_runtime = require_jsx_runtime();
function ProtocolPage() {
	const data = useDeskStore();
	const setPhaseId = useDeskStore((s) => s.setPhaseId);
	const upsertProtocolDay = useDeskStore((s) => s.upsertProtocolDay);
	const addProtocolDay = useDeskStore((s) => s.addProtocolDay);
	const dayN = protocolDayNumber(data);
	const today = todayProtocol(data);
	const danger = remainingRToDanger(data);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Payout protocol",
			title: "Survive the cycle.",
			description: "Distance to danger matters more than distance to payout. ICT research sits on top of this floor.",
			aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5 rounded-sm border border-white/[0.12] px-2 py-0.5 font-mono text-[10px] text-muted-foreground",
				children: [
					"Phase ",
					data.phaseId,
					" · ",
					data.phases.find((phase) => phase.id === data.phaseId)?.name
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mb-4",
			kicker: `Day ${dayN}`,
			title: today?.title ?? "Custom cycle",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: today?.focus
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm",
				children: [
					danger.dailyR.toFixed(1),
					"R left before daily cap · ",
					danger.totalR.toFixed(1),
					"R before max DD"
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6 grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4",
			children: data.phases.map((p) => {
				const isActive = data.phaseId === p.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setPhaseId(p.id),
					className: cn("group relative overflow-hidden rounded-xl border p-4 text-left transition-colors duration-200", isActive ? "border-accent/60 bg-accent/[0.07] before:absolute before:inset-x-0 before:top-0 before:h-0.5 before:bg-accent" : "border-white/[0.09] bg-card/70 hover:border-white/[0.2] hover:bg-card"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] font-semibold tracking-wider text-muted-foreground uppercase",
								children: ["Phase ", p.id]
							}), isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-accent animate-pulse" }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-2xl font-semibold tracking-tight text-foreground",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-xs leading-relaxed text-muted-foreground",
							children: p.goal
						})
					]
				}, p.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-6",
			title: "Account Constraints & Guidelines",
			kicker: "Risk Parameters",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Daily Loss Limit",
						v: `${data.rules.maxDailyLossPct}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Max Drawdown",
						v: `${data.rules.maxTotalDrawdownPct}% (${data.rules.drawdownType})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Payout Target",
						v: `${data.rules.payoutThresholdPct}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Profit Split",
						v: `${data.rules.profitSplit}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Consistency Score",
						v: `${data.rules.consistencyPct}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Min Trading Days",
						v: `${data.rules.minTradingDays} days`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "News Trading",
						v: data.rules.newsRestricted ? "Restricted" : "Open"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "Weekend Holding",
						v: data.rules.weekendRestricted ? "Flat" : "Allowed"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-semibold text-foreground",
				children: "30-Day Execution Track"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mt-0.5",
				children: "Discipline cycle progression"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "outline",
				onClick: addProtocolDay,
				children: "Add Day"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "space-y-3",
			children: data.protocolDays.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "group relative overflow-hidden rounded-2xl border border-white/[0.08] bg-gradient-to-b from-card/90 via-card/75 to-card/50 p-5 shadow-lg backdrop-blur-md transition-all duration-150 hover:border-white/[0.16]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-mono text-muted-foreground",
								children: [
									d.date,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-accent font-semibold",
										children: [d.riskPct, "% Risk"]
									}),
									" · Max ",
									d.maxTrades,
									" trades"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-2xl font-semibold text-foreground",
								children: d.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground mt-0.5",
								children: d.focus
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: d.completed ? "up" : d.skipped ? "warn" : "default",
								className: "px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider",
								children: d.completed ? "Completed" : d.skipped ? "Skipped" : "Pending"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: d.completed ? "outline" : "default",
							onClick: () => upsertProtocolDay({
								...d,
								completed: !d.completed,
								skipped: false
							}),
							children: d.completed ? "Undo Completion" : "Mark Complete"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => upsertProtocolDay({
								...d,
								skipped: !d.skipped,
								completed: false
							}),
							children: d.skipped ? "Unskip" : "Skip Day"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-3.5 bg-black/25 text-xs leading-relaxed",
						rows: 2,
						value: d.notes,
						onChange: (e) => upsertProtocolDay({
							...d,
							notes: e.target.value
						}),
						placeholder: "Session reflections, psychology notes, or mistakes made today..."
					})
				]
			}, d.id))
		})
	] });
}
function Item({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-white/[0.05] bg-white/[0.02] p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[11px] font-semibold tracking-wider text-muted-foreground uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-mono text-base font-semibold text-foreground",
			children: v
		})]
	});
}
//#endregion
export { ProtocolPage as component };
