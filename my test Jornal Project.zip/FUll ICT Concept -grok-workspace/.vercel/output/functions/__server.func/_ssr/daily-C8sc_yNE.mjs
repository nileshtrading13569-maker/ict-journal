import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { U as todayISO, _ as DRAWS, d as defaultPlanFrom, g as DELIVERIES, h as AMD_PHASES, l as useDeskStore } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { D as biasConfidence, S as RangeBar, W as planFor, b as NumField, et as weeklyFor, i as Chips, n as Badge, r as BoolRow, t as AppShell, w as Textarea, x as Panel, y as Field } from "./app-shell-x0M2IuoN.mjs";
import { t as PageHeader } from "./page-header-Bx98j88H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/daily-C8sc_yNE.js
var import_jsx_runtime = require_jsx_runtime();
function one(v) {
	return Array.isArray(v) ? v[0] : v;
}
function DailyPage() {
	const data = useDeskStore();
	const setPlan = useDeskStore((s) => s.setPlan);
	const today = todayISO();
	const plan = planFor(data, today);
	const week = weeklyFor(data, today);
	const conf = biasConfidence(plan.alignments);
	function patch(partial) {
		const next = {
			...plan,
			...partial,
			date: today
		};
		setPlan(today, next);
	}
	function setAlign(key, v) {
		patch({ alignments: {
			...plan.alignments,
			[key]: v
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Daily map",
			title: "Build the bias.",
			description: `Not “bullish because I feel good.” Alignment of HTF, liquidity, location, time, and narrative.${week ? ` Weekly draw is ${week.primaryDraw || "unset"}.` : ""}`,
			aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-[11px] text-muted-foreground",
				children: [today, " NY"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-4",
			kicker: "Confidence",
			title: `${conf}% objective alignment`,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				variant: conf >= 80 ? "up" : conf >= 60 ? "warn" : "default",
				children: [conf, " / 100"]
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "HTF alignment",
						value: plan.alignments.htf,
						onChange: (v) => setAlign("htf", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "Liquidity alignment",
						value: plan.alignments.liquidity,
						onChange: (v) => setAlign("liquidity", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "Location alignment",
						value: plan.alignments.location,
						onChange: (v) => setAlign("location", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "Time alignment",
						value: plan.alignments.time,
						onChange: (v) => setAlign("time", v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "Narrative alignment",
						value: plan.alignments.narrative,
						onChange: (v) => setAlign("narrative", v)
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "HTF structure",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
					options: [
						"bullish",
						"bearish",
						"consolidation",
						"expansion",
						"reversal"
					],
					value: plan.htfStructure,
					onChange: (v) => patch({ htfStructure: one(v) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Location in range",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"premium",
								"discount",
								"equilibrium"
							],
							value: plan.location,
							onChange: (v) => patch({ location: one(v) })
						})
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				title: "Daily dealing range",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Range high",
						value: plan.dealingRange.high,
						onChange: (n) => patch({ dealingRange: {
							...plan.dealingRange,
							high: n
						} })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Range low",
						value: plan.dealingRange.low,
						onChange: (n) => patch({ dealingRange: {
							...plan.dealingRange,
							low: n
						} })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeBar, { range: plan.dealingRange })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-4",
			title: "Previous day",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "PDH",
						value: plan.previousDay.pdh,
						onChange: (n) => patch({ previousDay: {
							...plan.previousDay,
							pdh: n
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "PDL",
						value: plan.previousDay.pdl,
						onChange: (n) => patch({ previousDay: {
							...plan.previousDay,
							pdl: n
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "PDC",
						value: plan.previousDay.pdc,
						onChange: (n) => patch({ previousDay: {
							...plan.previousDay,
							pdc: n
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Daily open",
						value: plan.previousDay.dailyOpen,
						onChange: (n) => patch({ previousDay: {
							...plan.previousDay,
							dailyOpen: n
						} })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Midnight open",
						value: plan.previousDay.midnightOpen,
						onChange: (n) => patch({ previousDay: {
							...plan.previousDay,
							midnightOpen: n
						} })
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mb-4",
			title: "Liquidity & delivery",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Liquidity condition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"BSL available",
							"SSL available",
							"Both",
							"One side raided"
						],
						value: plan.liquidityCondition,
						onChange: (v) => patch({ liquidityCondition: one(v) })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Expected draw",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: DRAWS,
							value: plan.expectedDraw,
							onChange: (v) => patch({ expectedDraw: one(v) })
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Expected delivery",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: DELIVERIES,
							value: plan.expectedDelivery,
							onChange: (v) => patch({ expectedDelivery: one(v) })
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mb-4",
			title: "AMD / Power of Three",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Expected phase",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: AMD_PHASES,
						value: plan.amdPhase,
						onChange: (v) => patch({ amdPhase: one(v) })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Expected manipulation",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: plan.expectedManipulation,
							onChange: (e) => patch({ expectedManipulation: e.target.value }),
							placeholder: "Asia high / PDH raid"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Expected distribution",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"bullish",
								"bearish",
								"neutral"
							],
							value: plan.expectedDistribution,
							onChange: (v) => patch({ expectedDistribution: one(v) })
						})
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mb-4",
			title: "Scenarios",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: plan.scenarios,
				onChange: (e) => patch({ scenarios: e.target.value }),
				rows: 5,
				placeholder: "A: Raid PDH then reverse into PDL.\nB: If PDL taken first without displacement — no trade."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			title: "Risk for today",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Risk %",
							value: plan.riskPerTrade,
							onChange: (n) => patch({ riskPerTrade: n ?? .25 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Max trades",
							value: plan.maxTrades,
							onChange: (n) => patch({ maxTrades: n ?? 2 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Daily loss %",
							value: plan.maxDailyLossPct,
							onChange: (n) => patch({ maxDailyLossPct: n ?? 1 })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Daily plan & review",
						hint: "Capture the plan before trading, then add an end-of-day lesson.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: plan.notes,
							onChange: (e) => patch({ notes: e.target.value }),
							placeholder: "Plan: ...\nReview: What followed the plan? What will I improve next session?",
							rows: 4
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 text-xs text-muted-foreground underline",
					onClick: () => setPlan(today, defaultPlanFrom(data, today)),
					children: "Reset today to defaults"
				})
			]
		})
	] });
}
//#endregion
export { DailyPage as component };
