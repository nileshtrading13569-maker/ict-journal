import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { I as cn } from "./router-CdjogOIb.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-10 w-full rounded-md border border-white/[0.09] bg-surface-2/80 px-3 text-sm text-foreground outline-none transition-all duration-[var(--motion-quick)] placeholder:text-muted-foreground/45 hover:border-white/[0.16] focus-visible:border-accent/60 focus-visible:bg-surface-2 focus-visible:ring-2 focus-visible:ring-accent/15 disabled:opacity-50", className),
		...props
	});
}
//#endregion
export { Input as t };
