import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as Eye, Q as ArrowUp, S as Pencil, V as ChevronUp, W as ChevronDown, _ as RotateCcw, b as Plus, et as ArrowDown, g as Search, j as Ellipsis, s as Trash2, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { G as uid, a as syncDeskToServer, j as Button, l as useDeskStore, z as formatR } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { L as fmtCurrency, Q as tradeDollarPnl, _ as DropdownMenuSeparator, a as ConfirmDelete, c as DialogDescription, d as DialogTitle, f as DropdownMenu, h as DropdownMenuItem, k as closedTrades, m as DropdownMenuContent, o as Dialog, s as DialogContent, t as AppShell, v as DropdownMenuTrigger, z as instrumentOf } from "./app-shell-x0M2IuoN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/playbook-C9XzNpZl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlaybookFormModal({ open, onOpenChange, model, onSaved }) {
	const models = useDeskStore((s) => s.models);
	const upsertModel = useDeskStore((s) => s.upsertModel);
	const [code, setCode] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [market, setMarket] = (0, import_react.useState)("XAUUSD");
	const [timeframe, setTimeframe] = (0, import_react.useState)("1H → 5m");
	const [htfNarrative, setHtfNarrative] = (0, import_react.useState)("");
	const [liquidityCondition, setLiquidityCondition] = (0, import_react.useState)("");
	const [pdArray, setPdArray] = (0, import_react.useState)("");
	const [trigger, setTrigger] = (0, import_react.useState)("");
	const [invalidation, setInvalidation] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)("");
	const [requiredTiming, setRequiredTiming] = (0, import_react.useState)("");
	const [validWhen, setValidWhen] = (0, import_react.useState)([]);
	const [invalidWhen, setInvalidWhen] = (0, import_react.useState)([]);
	const [active, setActive] = (0, import_react.useState)(true);
	const [newValidRule, setNewValidRule] = (0, import_react.useState)("");
	const [newInvalidRule, setNewInvalidRule] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (model) {
			setCode(model.code || "");
			setName(model.name || "");
			setMarket(model.market || "XAUUSD");
			setTimeframe(model.timeframe || "1H → 5m");
			setHtfNarrative(model.htfNarrative || "");
			setLiquidityCondition(model.liquidityCondition || "");
			setPdArray(model.pdArray || "");
			setTrigger(model.trigger || "");
			setInvalidation(model.invalidation || "");
			setTarget(model.target || "");
			setRequiredTiming(model.requiredTiming || "");
			setValidWhen(model.validWhen ? [...model.validWhen] : []);
			setInvalidWhen(model.invalidWhen ? [...model.invalidWhen] : []);
			setActive(model.active !== false);
		} else {
			const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			const usedCodes = new Set(models.map((m) => m.code.toUpperCase()));
			let nextCode = "A";
			for (let i = 0; i < 26; i++) if (!usedCodes.has(letters[i])) {
				nextCode = letters[i];
				break;
			}
			setCode(nextCode);
			setName("");
			setMarket("XAUUSD");
			setTimeframe("1H → 5m");
			setHtfNarrative("");
			setLiquidityCondition("");
			setPdArray("");
			setTrigger("");
			setInvalidation("");
			setTarget("");
			setRequiredTiming("");
			setValidWhen([
				"HTF aligned",
				"Liquidity swept",
				"Kill zone timing"
			]);
			setInvalidWhen(["Mid-range", "Already delivered"]);
			setActive(true);
		}
	}, [
		open,
		model,
		models
	]);
	const addValidRule = () => {
		const val = newValidRule.trim();
		if (val && !validWhen.includes(val)) {
			setValidWhen([...validWhen, val]);
			setNewValidRule("");
		}
	};
	const removeValidRule = (index) => {
		setValidWhen(validWhen.filter((_, i) => i !== index));
	};
	const addInvalidRule = () => {
		const val = newInvalidRule.trim();
		if (val && !invalidWhen.includes(val)) {
			setInvalidWhen([...invalidWhen, val]);
			setNewInvalidRule("");
		}
	};
	const removeInvalidRule = (index) => {
		setInvalidWhen(invalidWhen.filter((_, i) => i !== index));
	};
	const handleSave = async () => {
		const trimmedName = name.trim();
		const trimmedCode = code.trim().toUpperCase();
		if (!trimmedName) {
			toast.error("Please enter a playbook name.");
			return;
		}
		if (!trimmedCode) {
			toast.error("Please enter a playbook code.");
			return;
		}
		const duplicate = models.find((m) => m.id !== model?.id && m.code.toUpperCase() === trimmedCode);
		if (duplicate) {
			toast.error(`Code '${trimmedCode}' is already used by ${duplicate.name}.`);
			return;
		}
		const updatedModel = {
			id: model?.id ?? `model-${uid()}`,
			code: trimmedCode,
			name: trimmedName,
			market: market.trim() || "XAUUSD",
			timeframe: timeframe.trim() || "1H → 5m",
			htfNarrative: htfNarrative.trim(),
			liquidityCondition: liquidityCondition.trim(),
			pdArray: pdArray.trim(),
			trigger: trigger.trim(),
			invalidation: invalidation.trim(),
			target: target.trim(),
			requiredTiming: requiredTiming.trim(),
			validWhen: validWhen.map((s) => s.trim()).filter(Boolean),
			invalidWhen: invalidWhen.map((s) => s.trim()).filter(Boolean),
			active
		};
		setSaving(true);
		try {
			upsertModel(updatedModel);
			await syncDeskToServer();
			toast.success(model ? "Playbook updated" : "Playbook created");
			onSaved?.(updatedModel);
			onOpenChange(false);
		} catch (err) {
			console.error("[playbook-form] save error:", err);
			toast.error("Saved locally. Could not sync with server.");
			onOpenChange(false);
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			"aria-describedby": "playbook-form-desc",
			className: "max-h-[90vh] w-[95vw] max-w-[680px] overflow-hidden rounded-xl border border-white/[0.1] bg-[#0e0e0e] p-0 text-[#f5f5f4] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.95)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "sr-only",
					children: model ? "Edit playbook" : "Create playbook"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					id: "playbook-form-desc",
					className: "sr-only",
					children: "Configure playbook rules, criteria, and timing."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 shrink-0 items-center justify-between border-b border-white/[0.07] px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-[26px] leading-none text-white",
							children: model ? "Edit playbook" : "Create playbook"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[12px] text-[#a2a2a0]",
							children: code ? `Code [${code}]` : ""
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						"aria-label": "Close",
						className: "flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[calc(90vh-140px)] min-h-0 flex-1 overflow-y-auto px-6 py-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Code"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									maxLength: 4,
									value: code,
									onChange: (e) => setCode(e.target.value.toUpperCase()),
									placeholder: "A",
									className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[14px] font-semibold text-[#e50914]"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
										children: "Playbook name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										value: name,
										onChange: (e) => setName(e.target.value),
										placeholder: "Sell-side raid reversal",
										className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] font-semibold text-white"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Market"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: market,
									onChange: (e) => setMarket(e.target.value),
									placeholder: "XAUUSD",
									className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Timeframe"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: timeframe,
									onChange: (e) => setTimeframe(e.target.value),
									placeholder: "1H → 5m",
									className: "font-mono h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "HTF narrative & context"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: htfNarrative,
								onChange: (e) => setHtfNarrative(e.target.value),
								placeholder: "Bearish weekly/daily. Price in premium of the dealing range.",
								className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Liquidity condition"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: liquidityCondition,
									onChange: (e) => setLiquidityCondition(e.target.value),
									placeholder: "SSL / PDL / Asia low taken first.",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "PD Array"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: pdArray,
									onChange: (e) => setPdArray(e.target.value),
									placeholder: "1H or 15m bearish FVG / OB in premium.",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Trigger"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: trigger,
									onChange: (e) => setTrigger(e.target.value),
									placeholder: "MSS + displacement + 5m FVG.",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Invalidation"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: invalidation,
									onChange: (e) => setInvalidation(e.target.value),
									placeholder: "Close back beyond the swept structural extreme.",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Target"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: target,
									onChange: (e) => setTarget(e.target.value),
									placeholder: "BSL / PDH / opposing external.",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
									children: "Required timing / session"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: requiredTiming,
									onChange: (e) => setRequiredTiming(e.target.value),
									placeholder: "NY AM kill zone (09:30–11:00 ET)",
									className: "h-10 border-white/[0.09] bg-[#151515]/80 text-[13px] text-white"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Valid When (Checklist rules)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [validWhen.map((rule, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 rounded-md border border-white/[0.08] bg-[#151515] px-3 py-1.5 text-[12px] text-white",
										children: rule
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => removeValidRule(idx),
										className: "text-[#a2a2a0] hover:text-[#ff6b7d]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
									})]
								}, idx)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										value: newValidRule,
										onChange: (e) => setNewValidRule(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), addValidRule()),
										placeholder: "Add a required condition...",
										className: "h-8 text-[12px]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										onClick: addValidRule,
										className: "h-8 px-3 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 size-3" }), " Add"]
									})]
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1.5 block text-[11px] font-medium tracking-wider text-[#a2a2a0] uppercase",
								children: "Invalid When (Disqualifiers)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [invalidWhen.map((rule, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 rounded-md border border-[#ff6b7d]/20 bg-[#ff6b7d]/5 px-3 py-1.5 text-[12px] text-[#ff6b7d]",
										children: rule
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => removeInvalidRule(idx),
										className: "text-[#a2a2a0] hover:text-[#ff6b7d]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
									})]
								}, idx)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										value: newInvalidRule,
										onChange: (e) => setNewInvalidRule(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && (e.preventDefault(), addInvalidRule()),
										placeholder: "Add a disqualifier...",
										className: "h-8 text-[12px]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										onClick: addInvalidRule,
										className: "h-8 px-3 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1 size-3" }), " Add"]
									})]
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2.5 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									id: "model-active-check",
									checked: active,
									onChange: (e) => setActive(e.target.checked),
									className: "size-4 rounded border-white/[0.2] bg-white/[0.04] text-[#e50914] focus:ring-[#e50914]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "model-active-check",
									className: "cursor-pointer text-[13px] text-[#d6d6d4]",
									children: "Active playbook (shows in quick dropdowns and active ledger)"
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 shrink-0 items-center justify-end gap-2 border-t border-white/[0.07] px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						className: "h-10 border-white/[0.1] bg-white/[0.03] px-4 text-[13px] text-white hover:bg-white/[0.08]",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: handleSave,
						disabled: saving,
						className: "h-10 bg-[#e50914] px-4 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] hover:brightness-110",
						children: saving ? "Saving…" : model ? "Save changes" : "Create playbook"
					})]
				})
			]
		})
	});
}
function PlaybookDetailModal({ open, onOpenChange, model, onEdit }) {
	const data = useDeskStore();
	const trades = useDeskStore((s) => s.trades);
	if (!model) return null;
	const sample = closedTrades(trades.filter((t) => t.modelId === model.id || t.modelName === model.name));
	const wins = sample.filter((t) => t.result === "win").length;
	const wr = sample.length ? Math.round(wins / sample.length * 100) : 0;
	const netPnL = sample.reduce((acc, t) => {
		return acc + (tradeDollarPnl(t, instrumentOf(data, t.market)).net ?? 0);
	}, 0);
	const sumR = sample.reduce((acc, t) => acc + (t.rMultiple ?? 0), 0);
	const avgR = sample.length ? Number((sumR / sample.length).toFixed(2)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			"aria-describedby": "playbook-detail-desc",
			className: "max-h-[90vh] w-[95vw] max-w-[700px] overflow-hidden rounded-xl border border-white/[0.1] bg-[#0e0e0e] p-0 text-[#f5f5f4] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.95)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "sr-only",
					children: model.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					id: "playbook-detail-desc",
					className: "sr-only",
					children: "Playbook model specifications, rules, and research performance."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-16 shrink-0 items-center justify-between border-b border-white/[0.07] px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono flex size-8 items-center justify-center rounded-md border border-[#e50914]/40 bg-[#e50914]/10 text-[13px] font-semibold text-[#e50914]",
							children: model.code
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-[22px] leading-none text-white",
							children: model.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono mt-1 text-[11px] text-[#a2a2a0]",
							children: [
								model.market,
								" · ",
								model.timeframe
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								onOpenChange(false);
								onEdit(model);
							},
							className: "h-8 border-white/[0.1] bg-white/[0.03] text-xs text-white hover:bg-white/[0.08]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-1 size-3" }), " Edit"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onOpenChange(false),
							"aria-label": "Close",
							className: "flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.06] hover:text-white",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4 border-b border-white/[0.07] bg-white/[0.02] px-6 py-3 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-[#a2a2a0]",
							children: "Closed trades"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono mt-0.5 text-[16px] text-white",
							children: sample.length
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-[#a2a2a0]",
							children: "Win rate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono mt-0.5 text-[16px] text-white",
							children: [wr, "%"]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-[#a2a2a0]",
							children: "Net P&L"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `font-mono mt-0.5 text-[16px] ${netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
							children: fmtCurrency(netPnL)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase text-[#a2a2a0]",
							children: "Avg R"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `font-mono mt-0.5 text-[16px] ${avgR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
							children: formatR(avgR)
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[calc(90vh-180px)] min-h-0 flex-1 space-y-4 overflow-y-auto px-6 py-5 text-[13px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "HTF narrative"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.htfNarrative || "None specified"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "Liquidity condition"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.liquidityCondition || "None specified"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "PD array"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.pdArray || "None specified"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "Trigger"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.trigger || "None specified"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "Target"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.target || "None specified"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
									children: "Invalidation"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 leading-relaxed text-white",
									children: model.invalidation || "None specified"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-white/[0.07] bg-[#151515] p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-semibold text-[#a2a2a0] uppercase",
								children: "Required timing"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 leading-relaxed text-white",
								children: model.requiredTiming || "Any session"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 text-[11px] font-semibold text-[#a2a2a0] uppercase",
							children: "Valid when (Rules)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: model.validWhen?.length ? model.validWhen.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-md border border-[#3ddc84]/30 bg-[#3ddc84]/10 px-2.5 py-1 text-xs text-[#3ddc84]",
								children: ["✓ ", r]
							}, i)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[#6f6f6d]",
								children: "No checklist rules"
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1.5 text-[11px] font-semibold text-[#a2a2a0] uppercase",
							children: "Invalid when (Disqualifiers)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: model.invalidWhen?.length ? model.invalidWhen.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded-md border border-[#ff6b7d]/30 bg-[#ff6b7d]/10 px-2.5 py-1 text-xs text-[#ff6b7d]",
								children: ["✕ ", r]
							}, i)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-[#6f6f6d]",
								children: "No disqualifiers"
							})
						})] })
					]
				})
			]
		})
	});
}
function PlaybookPage() {
	const data = useDeskStore();
	const models = useDeskStore((s) => s.models);
	const recentlyDeletedModels = useDeskStore((s) => s.recentlyDeletedModels ?? []);
	const trades = useDeskStore((s) => s.trades);
	const removeModel = useDeskStore((s) => s.removeModel);
	const restoreModel = useDeskStore((s) => s.restoreModel);
	const permanentlyDeleteModel = useDeskStore((s) => s.permanentlyDeleteModel);
	const upsertModel = useDeskStore((s) => s.upsertModel);
	const [query, setQuery] = (0, import_react.useState)("");
	const [filterTab, setFilterTab] = (0, import_react.useState)("active");
	const [sortDirection, setSortDirection] = (0, import_react.useState)("desc");
	const [createModalOpen, setCreateModalOpen] = (0, import_react.useState)(false);
	const [editingModel, setEditingModel] = (0, import_react.useState)(null);
	const [viewingModel, setViewingModel] = (0, import_react.useState)(null);
	const [deletingModel, setDeletingModel] = (0, import_react.useState)(null);
	const [permDeletingModel, setPermDeletingModel] = (0, import_react.useState)(null);
	const [deletedSectionOpen, setDeletedSectionOpen] = (0, import_react.useState)(true);
	const filteredModels = (0, import_react.useMemo)(() => {
		return models.filter((m) => {
			if (filterTab === "active" && !m.active) return false;
			if (filterTab === "inactive" && m.active) return false;
			if (query.trim()) {
				const q = query.toLowerCase();
				const matchName = m.name.toLowerCase().includes(q);
				const matchCode = m.code.toLowerCase().includes(q);
				const matchMarket = (m.market || "").toLowerCase().includes(q);
				if (!matchName && !matchCode && !matchMarket) return false;
			}
			return true;
		});
	}, [
		models,
		filterTab,
		query
	]);
	const modelStats = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const m of models) {
			const sample = closedTrades(trades.filter((t) => t.modelId === m.id || t.modelName.toLowerCase() === m.name.toLowerCase()));
			let netPnL = 0;
			let grossProfit = 0;
			let grossLoss = 0;
			let sumR = 0;
			let wins = 0;
			let totalAssessed = 0;
			let totalFollowed = 0;
			for (const t of sample) {
				const inst = instrumentOf(data, t.market);
				const net = tradeDollarPnl(t, inst).net ?? 0;
				netPnL += net;
				if (net > 0) grossProfit += net;
				else if (net < 0) grossLoss += Math.abs(net);
				const r = t.rMultiple ?? 0;
				sumR += r;
				if (t.result === "win") wins += 1;
				const assessments = t.rulesAssessment ? Object.values(t.rulesAssessment) : [];
				if (assessments.length > 0) {
					totalAssessed += assessments.length;
					totalFollowed += assessments.filter((v) => v === "followed").length;
				} else {
					totalAssessed += 8;
					totalFollowed += t.ruleFollowed ? 7 : 4;
				}
			}
			const closedCount = sample.length;
			const winRate = closedCount > 0 ? Math.round(wins / closedCount * 100) : 0;
			const profitFactor = grossLoss === 0 ? grossProfit > 0 ? Infinity : 0 : Number((grossProfit / grossLoss).toFixed(2));
			const expectancy = closedCount > 0 ? Number((netPnL / closedCount).toFixed(2)) : 0;
			const avgR = closedCount > 0 ? Number((sumR / closedCount).toFixed(2)) : 0;
			const rulesFollowedPct = totalAssessed > 0 ? Math.round(totalFollowed / totalAssessed * 100) : 100;
			map.set(m.id, {
				closedCount,
				winRate,
				netPnL,
				profitFactor,
				expectancy,
				avgR,
				rulesFollowedPct,
				assessedCount: totalAssessed,
				followedCount: totalFollowed
			});
		}
		return map;
	}, [
		models,
		trades,
		data
	]);
	const sortedModels = (0, import_react.useMemo)(() => {
		return filteredModels.slice().sort((a, b) => {
			const statsA = modelStats.get(a.id);
			const statsB = modelStats.get(b.id);
			const pnlA = statsA?.netPnL ?? 0;
			const pnlB = statsB?.netPnL ?? 0;
			return sortDirection === "desc" ? pnlB - pnlA : pnlA - pnlB;
		});
	}, [
		filteredModels,
		modelStats,
		sortDirection
	]);
	const allClosedTrades = closedTrades(trades);
	const totalNetPnL = allClosedTrades.reduce((acc, t) => {
		return acc + (tradeDollarPnl(t, instrumentOf(data, t.market)).net ?? 0);
	}, 0);
	const activeCount = models.filter((m) => m.active).length;
	const inactiveCount = models.filter((m) => !m.active).length;
	const handleOpenCreate = () => {
		setEditingModel(null);
		setCreateModalOpen(true);
	};
	const handleOpenEdit = (m) => {
		setEditingModel(m);
		setCreateModalOpen(true);
	};
	const handleToggleActive = async (m) => {
		const updated = {
			...m,
			active: !m.active
		};
		upsertModel(updated);
		await syncDeskToServer();
		toast.success(updated.active ? `Activated ${m.name}` : `Deactivated ${m.name}`);
	};
	const handleConfirmDelete = async () => {
		if (!deletingModel) return;
		removeModel(deletingModel.id);
		await syncDeskToServer();
		toast.success(`Moved ${deletingModel.name} to recently deleted`);
		setDeletingModel(null);
	};
	const handleRestore = async (id, name) => {
		if (restoreModel(id)) {
			await syncDeskToServer();
			toast.success(`Restored ${name}`);
		} else toast.error("Could not restore. Another active model already uses that code.");
	};
	const handlePermanentDelete = async () => {
		if (!permDeletingModel) return;
		permanentlyDeleteModel(permDeletingModel.id);
		await syncDeskToServer();
		toast.success(`Permanently deleted ${permDeletingModel.name}`);
		setPermDeletingModel(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-[1152px] px-4 pt-6 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-12 items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-[36px] leading-none tracking-tight text-white",
						children: "Playbook"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: handleOpenCreate,
						className: "flex h-9 items-center gap-1.5 rounded-md bg-[#e50914] px-3.5 text-[13px] font-semibold text-white shadow-[0_10px_24px_-12px_rgba(229,9,20,0.9)] transition-colors hover:brightness-110",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Create playbook" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-10 w-[300px] items-center gap-2 rounded-md border border-white/[0.09] bg-[#151515]/80 px-3 text-[13px] text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 text-[#6f6f6d]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "Search name or code",
								value: query,
								onChange: (e) => setQuery(e.target.value),
								className: "w-full bg-transparent text-[13px] placeholder-[#6f6f6d] outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-10 overflow-hidden rounded-md border border-white/[0.1] text-[12px] font-medium",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setFilterTab("active"),
									className: `flex items-center px-3 transition-colors ${filterTab === "active" ? "bg-white/[0.08] font-semibold text-white" : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"}`,
									children: ["Active ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono ml-1.5 text-[#a2a2a0]",
										children: activeCount
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setFilterTab("inactive"),
									className: `flex items-center border-l border-white/[0.1] px-3 transition-colors ${filterTab === "inactive" ? "bg-white/[0.08] font-semibold text-white" : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"}`,
									children: ["Inactive ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono ml-1.5 text-[#a2a2a0]",
										children: inactiveCount
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setFilterTab("all"),
									className: `flex items-center border-l border-white/[0.1] px-3 transition-colors ${filterTab === "all" ? "bg-white/[0.08] font-semibold text-white" : "text-[#a2a2a0] hover:bg-white/[0.03] hover:text-white"}`,
									children: "All"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-[12px] text-[#a2a2a0]",
							children: "Closed trades · Oct 1 – Oct 29, 2026"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative mt-4 overflow-hidden rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#e50914]/60 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[960px] table-fixed text-[13px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "280px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "70px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "84px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "110px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "90px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "104px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "80px" } }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { style: { width: "48px" } })
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "h-9 border-b border-white/[0.07] text-left text-[10px] font-semibold tracking-[0.12em] text-[#a2a2a0] uppercase",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 font-semibold",
												children: "Playbook"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Trades"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Win rate"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													onClick: () => setSortDirection((d) => d === "desc" ? "asc" : "desc"),
													className: "inline-flex items-center gap-1 text-white hover:text-[#e50914]",
													children: ["Net P&L", sortDirection === "desc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3 text-[#e50914]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3 text-[#e50914]" })]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Profit factor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Expectancy"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Avg R"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 text-right font-semibold",
												children: "Rules followed"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												"aria-label": "Actions",
												className: "w-12"
											})
										]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "[&>tr]:h-16 [&>tr]:border-b [&>tr]:border-white/[0.05]",
										children: sortedModels.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 9,
											className: "py-12 text-center text-sm text-[#a2a2a0]",
											children: "No playbooks match your criteria."
										}) }) : sortedModels.map((m) => {
											const stats = modelStats.get(m.id) ?? {
												closedCount: 0,
												winRate: 0,
												netPnL: 0,
												profitFactor: 0,
												expectancy: 0,
												avgR: 0,
												rulesFollowedPct: 100,
												assessedCount: 0,
												followedCount: 0
											};
											stats.netPnL;
											const pfDisplay = stats.profitFactor === Infinity ? "∞" : stats.profitFactor.toFixed(2);
											const rulesWarning = stats.rulesFollowedPct < 70;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "transition-colors hover:bg-white/[0.03]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center gap-3",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono flex size-8 shrink-0 items-center justify-center rounded-md border border-[#e50914]/40 bg-[#e50914]/10 text-[13px] font-semibold text-[#e50914]",
																children: m.code
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																	className: "truncate font-semibold text-white",
																	children: m.name
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																	className: "font-mono mt-0.5 text-[11px] text-[#a2a2a0]",
																	children: [
																		m.market,
																		" · ",
																		m.timeframe
																	]
																})]
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "font-mono px-3 text-right text-white",
														children: stats.closedCount
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "font-mono px-3 text-right text-white",
														children: [stats.winRate, "%"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: `font-mono px-3 text-right font-medium ${stats.netPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
														children: fmtCurrency(stats.netPnL)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "font-mono px-3 text-right text-white",
														children: pfDisplay
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: `font-mono px-3 text-right ${stats.expectancy >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
														children: fmtCurrency(stats.expectancy)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: `font-mono px-3 text-right ${stats.avgR >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
														children: formatR(stats.avgR)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-3 text-right",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: `font-mono ${rulesWarning ? "text-[#f5b942]" : "text-white"}`,
															children: [stats.rulesFollowedPct, "%"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "font-mono text-[11px] text-[#a2a2a0]",
															children: [
																stats.followedCount,
																" of ",
																stats.assessedCount,
																" assessed"
															]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "pr-3 text-center",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
															asChild: true,
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																type: "button",
																"aria-label": "Model options",
																className: "flex size-8 items-center justify-center rounded-md text-[#a2a2a0] transition-colors hover:bg-white/[0.08] hover:text-white",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
															})
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
															className: "w-48 border-white/[0.1] bg-[#121212] text-white",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
																	onClick: () => setViewingModel(m),
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "mr-2 size-3.5 text-[#a2a2a0]" }), " View details"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
																	onClick: () => handleOpenEdit(m),
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "mr-2 size-3.5 text-[#a2a2a0]" }), " Edit playbook"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
																	onClick: () => handleToggleActive(m),
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "mr-2 size-3.5 text-[#a2a2a0]" }), m.active ? "Deactivate" : "Activate"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, { className: "bg-white/[0.08]" }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
																	onClick: () => setDeletingModel(m),
																	className: "text-[#ff6b7d] focus:text-[#ff6b7d]",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "mr-2 size-3.5" }), " Delete"]
																})
															]
														})] })
													})
												]
											}, m.id);
										})
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-11 items-center justify-between px-4 text-[12px] text-[#a2a2a0]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[#d6d6d4]",
									children: models.length
								}),
								" playbooks ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[#d6d6d4]",
									children: allClosedTrades.length
								}),
								" closed trades · Net P&L",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `font-mono font-medium ${totalNetPnL >= 0 ? "text-[#3ddc84]" : "text-[#ff6b7d]"}`,
									children: fmtCurrency(totalNetPnL)
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Unassigned trades: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[#d6d6d4]",
								children: "0"
							})] })]
						})
					]
				}),
				recentlyDeletedModels.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-4 rounded-xl border border-white/[0.09] bg-[#0a0a0a]/85",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						onClick: () => setDeletedSectionOpen(!deletedSectionOpen),
						className: "flex h-12 cursor-pointer items-center justify-between px-4 transition-colors hover:bg-white/[0.02]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 text-[13px] font-semibold text-white",
							children: [
								deletedSectionOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 text-[#a2a2a0]" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "size-3.5 text-[#a2a2a0]" }),
								"Recently deleted",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-[12px] font-normal text-[#a2a2a0]",
									children: recentlyDeletedModels.length
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[12px] text-[#a2a2a0]",
							children: "Linked trades are kept"
						})]
					}), deletedSectionOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-white/[0.06]",
						children: recentlyDeletedModels.map((item) => {
							const m = item.model;
							const deletedDate = new Date(item.deletedAt);
							const formattedDeleted = !Number.isNaN(deletedDate.getTime()) ? `Deleted ${deletedDate.toLocaleDateString("en-US", {
								month: "short",
								day: "numeric",
								year: "numeric"
							})}, ${deletedDate.toLocaleTimeString("en-US", {
								hour: "numeric",
								minute: "2-digit"
							})}` : "Deleted recently";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between border-b border-white/[0.04] px-4 py-3 text-[13px] last:border-b-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono flex size-8 items-center justify-center rounded-md border border-white/[0.12] text-[13px] text-[#a2a2a0]",
										children: m.code
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium text-[#d6d6d4]",
										children: m.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-[11px] text-[#a2a2a0]",
										children: formattedDeleted
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => handleRestore(m.id, m.name),
										className: "flex h-8 items-center rounded-md border border-white/[0.12] bg-white/[0.04] px-3 text-[12px] font-semibold text-white transition hover:bg-white/[0.08]",
										children: "Restore"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPermDeletingModel(m),
										className: "flex h-8 items-center rounded-md px-3 text-[12px] font-medium text-[#ff6b7d] transition hover:bg-white/[0.04]",
										children: "Delete permanently"
									})]
								})]
							}, m.id);
						})
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaybookFormModal, {
			open: createModalOpen,
			onOpenChange: setCreateModalOpen,
			model: editingModel
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaybookDetailModal, {
			open: !!viewingModel,
			onOpenChange: (open) => !open && setViewingModel(null),
			model: viewingModel,
			onEdit: (m) => {
				setViewingModel(null);
				handleOpenEdit(m);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
			open: !!deletingModel,
			onOpenChange: (open) => !open && setDeletingModel(null),
			title: `Delete "${deletingModel?.name}"?`,
			description: "This will move the playbook to Recently Deleted. Linked trades will keep their references.",
			onConfirm: handleConfirmDelete
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
			open: !!permDeletingModel,
			onOpenChange: (open) => !open && setPermDeletingModel(null),
			title: `Permanently delete "${permDeletingModel?.name}"?`,
			description: "This cannot be undone. This playbook will be completely removed.",
			onConfirm: handlePermanentDelete
		})
	] });
}
//#endregion
export { PlaybookPage as component };
