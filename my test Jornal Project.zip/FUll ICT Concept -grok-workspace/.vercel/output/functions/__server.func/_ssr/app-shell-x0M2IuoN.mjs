import { o as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useNavigate, d as useRouterState, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent$1, f as DialogDescription$1, h as DialogTitle$1, i as Description2, l as Dialog$1, m as DialogPortal$1, n as Cancel, o as Portal2, p as DialogOverlay$1, r as Content2, s as Root2, t as Action, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as signOut } from "./client-B40BzJxt.mjs";
import { D as LayoutDashboard, E as ListChecks, F as Cloud, G as Check, I as CloudUpload, K as ChartLine, L as CloudOff, M as Copy, N as Compass, T as LoaderCircle, Y as CalendarRange, Z as BookOpen, _ as RotateCcw, b as Plus, d as Shield, h as Send, i as Users, j as Ellipsis, l as Sun, m as Settings2, n as WifiOff, t as X, v as Radio } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Label2, c as Separator2, i as ItemIndicator2, l as Trigger, n as Content2$1, o as Portal2$1, r as Item2, s as Root2$1, t as CheckboxItem2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { A as TRIGGERS, B as inWindow, C as MANAGEMENT, D as SESSIONS, E as PD_ARRAYS, H as parseNum, I as cn, L as formatMoney, M as buttonVariants, O as TIMEFRAMES, P as TRADING_TZ, S as LIQUIDITY_TYPES, U as todayISO, V as nowHHMM, W as todayISO$1, _ as DRAWS, b as EXIT_REASONS, c as deskSnapshot, d as defaultPlanFrom, i as saveDeskState, j as Button, k as TIME_MODELS, l as useDeskStore, n as useDeskSyncStatus, o as UserButton, p as emptyTrade, q as weekdayShort, r as isDeskData, u as createResetState, v as EMOTIONS, x as KILL_ZONES, y as ERRORS, z as formatR } from "./router-CdjogOIb.mjs";
import { t as Input } from "./input-BhW_SaKF.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-x0M2IuoN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] leading-4 transition-colors duration-150", {
	variants: { variant: {
		default: "bg-white/[0.04] text-foreground/75 border-white/[0.1]",
		accent: "bg-accent/15 text-accent border-accent/35",
		up: "bg-up/10 text-up border-up/30",
		down: "bg-down/10 text-down border-down/30",
		warn: "bg-warn/10 text-warn border-warn/30"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function dealingMeta(range) {
	const high = range.high;
	const low = range.low;
	if (high == null || low == null || high === low) return {
		eq: null,
		span: 0,
		location: "equilibrium",
		pctFromLow: null
	};
	const top = Math.max(high, low);
	const bot = Math.min(high, low);
	const eq = (top + bot) / 2;
	const span = top - bot;
	const price = range.current ?? range.close ?? null;
	let location = "equilibrium";
	let pctFromLow = null;
	if (price != null && span > 0) {
		pctFromLow = (price - bot) / span;
		if (pctFromLow > .55) location = "premium";
		else if (pctFromLow < .45) location = "discount";
		else location = "equilibrium";
	}
	return {
		eq,
		span,
		location,
		pctFromLow,
		high: top,
		low: bot
	};
}
function locationOfPrice(price, range) {
	return dealingMeta({
		...range,
		current: price ?? range.current
	}).location;
}
function stopDistance(t) {
	if (t.entry == null || t.sl == null) return 0;
	return Math.abs(t.entry - t.sl);
}
function rFromPrices(side, entry, sl, exit) {
	if (entry == null || sl == null || exit == null) return null;
	const stop = Math.abs(entry - sl);
	if (stop === 0) return null;
	return (side === "long" ? exit - entry : entry - exit) / stop;
}
function resultFromR(r, explicit) {
	if (explicit === "open") return "open";
	if (r == null) return "open";
	if (r > .15) return "win";
	if (r < -.15) return "loss";
	return "be";
}
function computeTradeR(t) {
	return rFromPrices(t.side, t.entry, t.sl, t.exitPrice);
}
function pnlPctOf(t) {
	if (t.rMultiple == null || t.result === "open") return 0;
	return t.riskPct * t.rMultiple;
}
function instrumentOf(data, symbol) {
	return data.instruments.find((i) => i.symbol === symbol) ?? data.instruments[0];
}
function positionLots(equity, riskPct, entry, sl, inst) {
	if (!inst || entry == null || sl == null) return null;
	const stop = Math.abs(entry - sl);
	if (stop <= 0) return null;
	const riskUsd = equity * (riskPct / 100);
	const $PerLot = stop / inst.tickSize * inst.tickValuePerLot;
	if ($PerLot <= 0) return null;
	return riskUsd / $PerLot;
}
function riskPctForLots(equity, lots, entry, sl, inst) {
	if (!inst || equity <= 0 || entry == null || sl == null || inst.tickSize <= 0) return null;
	const stop = Math.abs(entry - sl);
	if (stop <= 0) return null;
	const riskUsd = lots * (stop / inst.tickSize) * inst.tickValuePerLot;
	if (!Number.isFinite(riskUsd)) return null;
	return riskUsd / equity * 100;
}
function biasConfidence(a) {
	const keys = [
		"htf",
		"liquidity",
		"location",
		"time",
		"narrative"
	];
	const n = keys.filter((k) => a[k]).length;
	return Math.round(n / keys.length * 100);
}
function confluenceScore(t) {
	let n = 0;
	if (t.weeklyBias !== "neutral" && t.weeklyBias === t.dailyBias) n += 1;
	if (t.drawOnLiquidity) n += 1;
	if (t.side === "long" && t.location === "discount" || t.side === "short" && t.location === "premium") n += 1;
	if (t.taken.length) n += 1;
	if (t.pdArray) n += 1;
	if (t.triggers.includes("MSS") || t.triggers.includes("CISD") || t.triggers.includes("BOS")) n += 1;
	if (t.triggers.includes("Displacement") || t.displacementQuality === "strong") n += 1;
	if (t.killZone && t.killZone !== "Other") n += 1;
	if (t.smt.present !== "no") n += 1;
	if (t.ote.used === "used" && t.ote.inside) n += 1;
	return n;
}
function closedTrades(trades) {
	return trades.filter((t) => t.result !== "open" && t.rMultiple != null);
}
function fmtPx(n, digits = 2) {
	if (n == null || Number.isNaN(n)) return "—";
	return n.toLocaleString("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function fmtLots(n) {
	if (n == null || Number.isNaN(n)) return "—";
	return n.toFixed(n > 0 && n < .01 ? 4 : 2);
}
function calcTradeMetrics(t, inst) {
	const tickSize = inst?.tickSize ?? .01;
	const tickValuePerLot = inst?.tickValuePerLot ?? 1;
	const pointValuePerLot = 1 / tickSize * tickValuePerLot;
	const lots = t.lots ?? 0;
	const side = t.side ?? "long";
	const entry = t.entry ?? null;
	const sl = t.sl ?? null;
	const exit = t.exitPrice ?? null;
	const target = t.targetPrice ?? t.tp1 ?? null;
	const fees = t.fees != null ? t.fees : lots > 0 ? Number((1.75 * (lots / .25)).toFixed(2)) : 0;
	let stopDist = null;
	let riskUsd = null;
	if (entry != null && sl != null) {
		stopDist = Math.abs(entry - sl);
		if (stopDist > 0 && lots > 0) riskUsd = Number((stopDist * pointValuePerLot * lots).toFixed(2));
	}
	let plannedR = null;
	if (stopDist != null && stopDist > 0 && target != null && entry != null) {
		const targetDist = Math.abs(target - entry);
		plannedR = Number((targetDist / stopDist).toFixed(2));
	}
	let grossPnL = null;
	let netPnL = null;
	let realizedR = null;
	if (entry != null && exit != null && lots > 0) {
		const priceDiff = side === "long" ? exit - entry : entry - exit;
		grossPnL = Number((priceDiff * pointValuePerLot * lots).toFixed(2));
		netPnL = Number((grossPnL - fees).toFixed(2));
		if (stopDist != null && stopDist > 0) realizedR = Number((priceDiff / stopDist).toFixed(2));
	}
	return {
		risk: riskUsd,
		grossPnL,
		fees,
		netPnL,
		plannedR,
		realizedR,
		stopDist
	};
}
function tradeDollarPnl(t, inst) {
	if (t.result === "open" && t.exitPrice == null) return {
		gross: null,
		fees: t.fees ?? 0,
		net: null
	};
	const metrics = calcTradeMetrics(t, inst);
	if (metrics.netPnL != null) return {
		gross: metrics.grossPnL,
		fees: metrics.fees,
		net: metrics.netPnL
	};
	if (t.rMultiple != null) {
		const gross = Number((t.rMultiple * 125).toFixed(2));
		const fees = t.fees ?? 1.75;
		return {
			gross,
			fees,
			net: Number((gross - fees).toFixed(2))
		};
	}
	return {
		gross: null,
		fees: t.fees ?? 0,
		net: null
	};
}
function fmtCurrency(n, includeSign = true) {
	if (n == null || Number.isNaN(n)) return "—";
	const absFormatted = Math.abs(n).toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	if (n > 0) return includeSign ? `+$${absFormatted}` : `$${absFormatted}`;
	if (n < 0) return `−$${absFormatted}`;
	return `$${absFormatted}`;
}
function tradesOn(trades, date) {
	return trades.filter((t) => t.date === date);
}
function consecutiveLosses(trades) {
	const list = trades.filter((t) => t.result !== "open").slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
	let n = 0;
	for (let i = list.length - 1; i >= 0; i -= 1) if (list[i].result === "loss") n += 1;
	else break;
	return n;
}
function worstStreak(trades) {
	const list = closedTrades(trades).slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
	let worst = 0;
	let cur = 0;
	for (const t of list) if (t.result === "loss") {
		cur += 1;
		worst = Math.max(worst, cur);
	} else cur = 0;
	return worst;
}
function sumPnlPct(trades) {
	return trades.reduce((acc, t) => acc + pnlPctOf(t), 0);
}
function sumR(trades) {
	return closedTrades(trades).reduce((acc, t) => acc + (t.rMultiple ?? 0), 0);
}
function winRate(trades) {
	const closed = closedTrades(trades);
	if (!closed.length) return 0;
	return closed.filter((t) => t.result === "win").length / closed.length * 100;
}
function expectancyR(trades) {
	const closed = closedTrades(trades);
	if (!closed.length) return 0;
	return sumR(closed) / closed.length;
}
function profitFactor(trades) {
	const closed = closedTrades(trades);
	const gp = closed.filter((t) => (t.rMultiple ?? 0) > 0).reduce((a, t) => a + (t.rMultiple ?? 0), 0);
	const gl = Math.abs(closed.filter((t) => (t.rMultiple ?? 0) < 0).reduce((a, t) => a + (t.rMultiple ?? 0), 0));
	if (gl === 0) return gp > 0 ? 99 : 0;
	return gp / gl;
}
function avgWinR(trades) {
	const w = closedTrades(trades).filter((t) => t.result === "win");
	if (!w.length) return 0;
	return w.reduce((a, t) => a + (t.rMultiple ?? 0), 0) / w.length;
}
function avgLossR(trades) {
	const l = closedTrades(trades).filter((t) => t.result === "loss");
	if (!l.length) return 0;
	return l.reduce((a, t) => a + (t.rMultiple ?? 0), 0) / l.length;
}
function ruleFollowRate(trades) {
	if (!trades.length) return 0;
	return trades.filter((t) => t.ruleFollowed).length / trades.length * 100;
}
function equityCurve(trades) {
	const closed = closedTrades(trades).slice().sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
	let r = 0;
	let pct = 0;
	let peak = 0;
	return closed.map((t) => {
		r += t.rMultiple ?? 0;
		pct += pnlPctOf(t);
		peak = Math.max(peak, pct);
		const dd = peak - pct;
		return {
			id: t.id,
			date: t.date,
			time: t.time,
			r,
			pct,
			dd,
			label: `${t.date} ${t.market}`
		};
	});
}
function maxDrawdownPct(trades) {
	return equityCurve(trades).reduce((m, p) => Math.max(m, p.dd), 0);
}
function currentBalance(data) {
	const pct = sumPnlPct(data.trades);
	return data.rules.startingBalance * (1 + pct / 100);
}
function payoutProgress(data) {
	const gained = currentBalance(data) - data.rules.startingBalance;
	const target = data.rules.startingBalance * (data.rules.payoutThresholdPct / 100);
	return {
		gained,
		target,
		pct: target === 0 ? 0 : gained / target * 100
	};
}
function planFor(data, date) {
	return data.dailyPlans[date] ?? defaultPlanFrom(data, date);
}
function protocolDayNumber(data, date = todayISO$1()) {
	if (!data.rules.protocolStartDate) return 1;
	const a = Date.parse(`${data.rules.protocolStartDate}T00:00:00Z`);
	const b = Date.parse(`${date}T00:00:00Z`);
	const n = Math.round((b - a) / 864e5) + 1;
	return Math.max(1, n);
}
function todayProtocol(data, date = todayISO$1()) {
	const n = protocolDayNumber(data, date);
	return data.protocolDays.find((d) => d.day === n) ?? data.protocolDays.find((d) => d.date === date);
}
function lockInfo(data, date = todayISO$1()) {
	const plan = planFor(data, date);
	const todays = tradesOn(data.trades, date);
	const reasons = [];
	const warnings = [];
	const losses = consecutiveLosses(todays);
	if (losses >= data.rules.maxConsecutiveLosses) reasons.push(`${losses} consecutive losses — stop. Analyse, do not take the next trade.`);
	const lostPct = -Math.min(0, sumPnlPct(todays));
	if (lostPct >= plan.maxDailyLossPct) reasons.push(`Daily loss limit hit (${lostPct.toFixed(2)}% ≥ ${plan.maxDailyLossPct}%). Platform close.`);
	if (todays.length >= plan.maxTrades) reasons.push(`Max trades for today reached (${todays.length}/${plan.maxTrades}).`);
	const totalDd = -Math.min(0, sumPnlPct(data.trades));
	if (totalDd >= data.rules.maxTotalDrawdownPct) reasons.push(`Max total drawdown reached (${totalDd.toFixed(2)}%).`);
	const news = data.newsEvents.filter((n) => n.date === date && n.avoid);
	if (news.length) warnings.push(`High-impact: ${news.map((n) => n.name).join(", ")}. Default is flat around the print.`);
	if (!inWindow(data.rules.windowStart, data.rules.windowEnd)) warnings.push("Outside the New York trading window. Chart should be closed.");
	if (data.forceClosedDates.includes(date)) reasons.push("You closed the platform for today.");
	const forceOpen = data.forceOpenDates.includes(date);
	return {
		locked: forceOpen ? false : reasons.length > 0,
		reasons: forceOpen ? [] : reasons,
		warnings
	};
}
function remainingRToDanger(data, date = todayISO$1()) {
	const plan = planFor(data, date);
	const todays = tradesOn(data.trades, date);
	const lostToday = -Math.min(0, sumPnlPct(todays));
	const dailyLeftPct = Math.max(0, plan.maxDailyLossPct - lostToday);
	const totalDd = -Math.min(0, sumPnlPct(data.trades));
	const totalLeftPct = Math.max(0, data.rules.maxTotalDrawdownPct - totalDd);
	const risk = plan.riskPerTrade || data.rules.normalRiskPct || .25;
	return {
		dailyLeftPct,
		totalLeftPct,
		dailyR: risk > 0 ? dailyLeftPct / risk : 0,
		totalR: risk > 0 ? totalLeftPct / risk : 0,
		risk
	};
}
function weeklyFor(data, date) {
	return data.weeklies.slice().sort((a, b) => b.weekStart.localeCompare(a.weekStart)).find((w) => w.weekStart <= date);
}
function finalize(map) {
	return [...map.entries()].map(([key, v]) => ({
		key,
		label: v.label,
		trades: v.trades,
		wins: v.wins,
		r: v.r,
		expectancy: v.trades ? v.r / v.trades : 0
	})).sort((a, b) => b.r - a.r);
}
function bump(map, key, label, t) {
	const cur = map.get(key) ?? {
		label,
		trades: 0,
		wins: 0,
		r: 0
	};
	cur.trades += 1;
	if (t.result === "win") cur.wins += 1;
	cur.r += t.rMultiple ?? 0;
	map.set(key, cur);
}
function conceptMatrix(trades) {
	const map = /* @__PURE__ */ new Map();
	for (const t of trades) {
		for (const liq of t.taken) bump(map, `taken:${liq}`, `${liq} sweep`, t);
		if (t.pdArray) bump(map, `pd:${t.pdArray}`, t.pdArray, t);
		for (const tr of t.triggers) bump(map, `tr:${tr}`, tr, t);
		if (t.session) bump(map, `sess:${t.session}`, t.session, t);
		if (t.killZone) bump(map, `kz:${t.killZone}`, t.killZone, t);
		bump(map, `loc:${t.location}`, t.location, t);
		if (t.smt.present !== "no") bump(map, `smt:${t.smt.present}`, `SMT ${t.smt.present}`, t);
		if (t.ote.used === "used") bump(map, "ote", "OTE", t);
		if (t.crt.used) bump(map, "crt", "CRT", t);
		if (t.judas.present === "yes") bump(map, "judas", "Judas", t);
		if (t.modelName) bump(map, `model:${t.modelId || t.modelName}`, t.modelName, t);
	}
	return finalize(map);
}
function errorBreakdown(trades) {
	const map = /* @__PURE__ */ new Map();
	for (const t of trades) {
		const keys = t.errors.length ? t.errors : t.primaryError ? [t.primaryError] : ["Unlabeled"];
		for (const e of keys) bump(map, e, e, t);
	}
	return finalize(map);
}
function dayOfWeekTable(trades) {
	const order = [
		"Mon",
		"Tue",
		"Wed",
		"Thu",
		"Fri",
		"Sat",
		"Sun"
	];
	const map = /* @__PURE__ */ new Map();
	for (const t of closedTrades(trades)) {
		const d = weekdayShort(t.date);
		const cur = map.get(d) ?? {
			bias: t.dailyBias,
			liq: t.taken[0] ?? "—",
			dir: t.side,
			r: 0,
			n: 0
		};
		cur.r += t.rMultiple ?? 0;
		cur.n += 1;
		cur.bias = t.dailyBias;
		cur.liq = t.taken[0] ?? cur.liq;
		cur.dir = t.side;
		map.set(d, cur);
	}
	return order.filter((d) => map.has(d)).map((d) => ({
		day: d,
		...map.get(d)
	}));
}
function maeMfeStats(trades) {
	const closed = closedTrades(trades).filter((t) => t.mfeR != null || t.maeR != null);
	if (!closed.length) return {
		avgMae: 0,
		avgMfe: 0,
		conversion: 0,
		n: 0
	};
	const avgMae = closed.reduce((a, t) => a + (t.maeR ?? 0), 0) / closed.length;
	const avgMfe = closed.reduce((a, t) => a + (t.mfeR ?? 0), 0) / closed.length;
	const withBoth = closed.filter((t) => t.mfeR && t.mfeR > 0 && t.rMultiple != null);
	return {
		avgMae,
		avgMfe,
		conversion: withBoth.length ? withBoth.reduce((a, t) => a + (t.rMultiple ?? 0) / t.mfeR, 0) / withBoth.length : 0,
		n: closed.length
	};
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-black/85 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
		...props
	});
}
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed inset-x-0 bottom-0 z-50 flex max-h-[92dvh] w-full flex-col overflow-hidden rounded-t-2xl border border-white/[0.12] bg-[#080808] p-6 shadow-[0_40px_120px_-24px_rgba(0,0,0,1)] duration-[var(--motion-fast)] ease-[var(--ease-cinema)] sm:inset-auto sm:top-1/2 sm:left-1/2 sm:max-h-[88vh] sm:w-full sm:max-w-lg sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-2xl before:pointer-events-none before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-accent/70 before:to-transparent", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 rounded-sm border border-white/[0.1] p-1.5 text-muted-foreground transition-all hover:border-accent/50 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 shrink-0 pr-10", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl leading-tight tracking-wide text-foreground", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1.5 text-sm leading-relaxed text-muted-foreground", className),
		...props
	});
}
function DialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex shrink-0 flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-24 w-full rounded-md border border-white/[0.09] bg-surface-2/80 px-3 py-2.5 text-sm text-foreground outline-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-subtle hover:border-white/[0.16] focus-visible:border-accent/60 focus-visible:ring-2 focus-visible:ring-accent/15 disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-muted-foreground", className),
		...props
	});
}
function Field({ label, children, hint, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex flex-col gap-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium tracking-wider text-muted-foreground uppercase",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-subtle",
				children: hint
			}) : null
		]
	});
}
function NumField({ label, value, onChange, step = "any", placeholder, className }) {
	const [draft, setDraft] = (0, import_react.useState)(value == null ? "" : String(value));
	const [editing, setEditing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!editing) setDraft(value == null ? "" : String(value));
	}, [editing, value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label,
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			type: "text",
			inputMode: "decimal",
			step,
			placeholder,
			value: draft,
			onFocus: () => setEditing(true),
			onBlur: () => setEditing(false),
			onChange: (e) => {
				const next = e.target.value;
				setDraft(next);
				onChange(parseNum(next));
			}
		})
	});
}
function Panel({ kicker, title, meta, action, titleAction, children, className, bodyClassName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("relative overflow-hidden rounded-2xl border border-white/[0.09] bg-card/85 transition-colors duration-200 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-accent/60 before:to-transparent hover:border-white/[0.16]", className),
		children: [kicker || title || action || titleAction || meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex flex-wrap items-start justify-between gap-3 border-b border-white/[0.06] px-5 py-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-semibold tracking-[0.16em] text-accent uppercase",
						children: kicker
					}) : null,
					title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl font-normal leading-tight tracking-wide text-foreground",
						children: title
					}) : null,
					titleAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2.5 flex flex-wrap items-center gap-2",
						children: titleAction
					}) : null,
					meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: meta
					}) : null
				]
			}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex shrink-0 items-center gap-2",
				children: action
			}) : null]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("p-5 sm:p-6", bodyClassName),
			children
		})]
	});
}
function Chips({ options, value, onChange, multiple = false }) {
	const items = options.map((o) => typeof o === "string" ? {
		value: o,
		label: o
	} : o);
	const selected = new Set(Array.isArray(value) ? value : value ? [value] : []);
	function toggle(v) {
		if (multiple) {
			const next = new Set(selected);
			if (next.has(v)) next.delete(v);
			else next.add(v);
			onChange([...next]);
		} else onChange(v);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1.5",
		children: items.map((o) => {
			const on = selected.has(o.value);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => toggle(o.value),
				className: cn("h-8 rounded-md border px-3 text-xs font-medium transition-all duration-150 active:scale-[0.97]", on ? "border-accent bg-accent text-primary-foreground font-semibold shadow-[0_8px_18px_-12px_rgba(229,9,20,0.9)]" : "border-white/[0.1] bg-white/[0.03] text-foreground/75 hover:border-white/[0.24] hover:text-foreground"),
				children: o.label
			}, o.value);
		})
	});
}
function BoolRow({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": value,
		onClick: () => onChange(!value),
		className: cn("flex h-11 items-center justify-between gap-3 rounded-lg border px-3.5 text-left text-sm transition-all duration-150 active:scale-[0.99]", value ? "border-up/35 bg-up/[0.07] text-foreground" : "border-white/[0.09] bg-white/[0.02] text-foreground/75 hover:border-white/[0.2] hover:text-foreground"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("rounded-sm border px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em]", value ? "border-up/30 bg-up/10 text-up" : "border-white/[0.1] bg-white/[0.04] text-subtle"),
			children: value ? "Yes" : "No"
		})]
	});
}
function TriRow({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-lg border border-white/[0.07] bg-white/[0.02] px-3.5 py-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-1.5",
			children: [
				[true, "Correct"],
				[false, "Wrong"],
				[null, "—"]
			].map(([v, lab]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": value === v,
				onClick: () => onChange(v),
				className: cn("h-8 rounded-md border px-2.5 text-xs font-medium transition-all active:scale-[0.97]", value === v ? v === true ? "border-up/40 bg-up/15 text-up font-semibold" : v === false ? "border-down/40 bg-down/15 text-down font-semibold" : "border-accent bg-accent text-primary-foreground font-semibold" : "border-white/[0.1] bg-white/[0.03] text-foreground/70 hover:border-white/[0.22] hover:text-foreground"),
				children: lab
			}, lab))
		})]
	});
}
function RangeBar({ range, mark, markLabel = "Price" }) {
	const meta = dealingMeta({
		...range,
		current: mark ?? range.current ?? range.close ?? null
	});
	if (!meta.span || meta.high == null || meta.low == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Set a high and a low to map premium / discount."
	});
	const price = mark ?? range.current ?? range.close;
	const pct = meta.pctFromLow != null ? Math.min(1, Math.max(0, meta.pctFromLow)) : .5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2.5 rounded-lg border border-white/[0.08] bg-black/50 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-[11px] font-mono",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["Low ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: fmtPx(meta.low)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-md border border-white/[0.1] bg-white/[0.05] px-2.5 py-0.5 font-medium text-foreground shadow-sm",
						children: ["EQ ", fmtPx(meta.eq)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["High ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: fmtPx(meta.high)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-8 overflow-hidden rounded-sm border border-white/[0.08] bg-surface-2/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 left-0 w-1/2 border-r border-dashed border-up/30 bg-gradient-to-r from-up/[0.04] to-up/15" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-0 right-0 w-1/2 border-l border-dashed border-down/30 bg-gradient-to-l from-down/[0.04] to-down/15" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 bottom-0 left-1/2 w-px bg-white/40" }),
					price != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute top-1 bottom-1 w-1 rounded-full bg-accent shadow-[0_0_10px_rgba(229,9,20,0.9)] transition-all duration-300",
						style: { left: `calc(${pct * 100}% - 2px)` }
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-up uppercase",
						children: "Discount · buy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("rounded-sm border px-2 py-0.5 text-[10px] font-semibold tracking-[0.12em] uppercase", meta.location === "premium" ? "border-down/35 bg-down/10 text-down" : meta.location === "discount" ? "border-up/35 bg-up/10 text-up" : "border-white/[0.1] bg-white/[0.04] text-muted-foreground"),
						children: [
							markLabel,
							": ",
							fmtPx(price),
							" · ",
							meta.location
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-semibold tracking-[0.12em] text-down uppercase",
						children: "Premium · sell"
					})
				]
			})
		]
	});
}
var STEPS = [
	"Narrative",
	"Trigger",
	"Execute",
	"Manage",
	"Review"
];
var BALANCE_FORMATTER = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
function Optional({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "rounded-md bg-surface-2/80 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "cursor-pointer text-sm font-medium text-muted-foreground",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-3",
			children
		})]
	});
}
function one(v) {
	return Array.isArray(v) ? v[0] : v;
}
function many(v) {
	return Array.isArray(v) ? v : [v];
}
function TradeWizard({ open, onOpenChange, trade }) {
	const data = useDeskStore();
	const upsertTrade = useDeskStore((s) => s.upsertTrade);
	const models = data.models.filter((m) => m.active);
	const today = todayISO();
	const dailyPlan = useDeskStore((s) => s.dailyPlans[today]);
	const rules = useDeskStore((s) => s.rules);
	const plan = (0, import_react.useMemo)(() => dailyPlan ?? defaultPlanFrom(rules, today), [
		dailyPlan,
		rules,
		today
	]);
	const lock = lockInfo(data, today);
	const first = models[0];
	const [step, setStep] = (0, import_react.useState)(0);
	const [form, setForm] = (0, import_react.useState)(emptyTrade(today, nowHHMM(), plan.riskPerTrade, first));
	const inst = instrumentOf(data, form.market);
	const equity = currentBalance(data);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setStep(0);
		if (trade) setForm(trade);
		else {
			const next = emptyTrade(today, nowHHMM(), plan.riskPerTrade, first);
			if (lock.locked) next.ruleFollowed = false;
			if (plan.expectedDraw) next.drawOnLiquidity = plan.expectedDraw;
			next.location = plan.location;
			next.dealingRange = { ...plan.dealingRange };
			setForm(next);
		}
	}, [
		open,
		trade,
		today,
		plan.riskPerTrade,
		first,
		lock.locked,
		plan.expectedDraw,
		plan.location,
		plan.dealingRange
	]);
	const patch = (0, import_react.useCallback)((key, value) => {
		setForm((f) => {
			const next = {
				...f,
				[key]: value
			};
			if (key === "entry" || key === "sl" || key === "exitPrice" || key === "side" || key === "result") {
				if (next.result !== "open") {
					const r = computeTradeR(next);
					next.rMultiple = r;
					if (next.exitPrice != null) next.result = resultFromR(r, next.result);
				} else next.rMultiple = null;
			}
			if (key === "entry" || key === "dealingRange") next.location = locationOfPrice(next.entry, next.dealingRange);
			if (key === "entry" || key === "sl" || key === "market") next.lots = null;
			return next;
		});
	}, []);
	const calculatedLots = positionLots(equity, form.riskPct, form.entry, form.sl, inst);
	const lots = form.lots ?? calculatedLots;
	const stop = stopDistance(form);
	const rLive = form.result === "open" ? null : computeTradeR(form);
	const score = confluenceScore(form);
	const model = models.find((m) => m.id === form.modelId);
	const tradeLock = lockInfo(trade ? {
		...data,
		trades: data.trades.filter((item) => item.id !== trade.id)
	} : data, form.date);
	const saveTrade = () => {
		const r = form.result === "open" ? null : computeTradeR(form) ?? form.rMultiple;
		const planSnapshot = trade?.planSnapshot ?? {
			capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
			plan: planFor(data, form.date),
			warnings: [...tradeLock.reasons, ...tradeLock.warnings]
		};
		upsertTrade({
			...form,
			ruleFollowed: tradeLock.locked ? false : form.ruleFollowed,
			planSnapshot,
			rMultiple: r,
			result: form.result === "open" ? "open" : resultFromR(r, form.result),
			lots,
			modelName: model?.name ?? form.modelName
		});
		toast.success(trade ? "Trade updated" : "Trade logged");
		onOpenChange(false);
	};
	const attachScreenshot = (0, import_react.useCallback)((key, file) => {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			toast.error("Choose an image file.");
			return;
		}
		if (file.size > 3e5) {
			toast.error("Screenshot must be 300 KB or smaller to keep cloud sync reliable.");
			return;
		}
		const reader = new FileReader();
		reader.onerror = () => toast.error("Could not read that image.");
		reader.onload = () => {
			if (typeof reader.result === "string") patch(key, reader.result);
		};
		reader.readAsDataURL(file);
	}, [patch]);
	const body = (0, import_react.useMemo)(() => {
		if (step === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Model",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: models.map((m) => ({
							value: m.id,
							label: `${m.code} · ${m.name}`
						})),
						value: form.modelId,
						onChange: (v) => {
							const id = one(v);
							const m = models.find((x) => x.id === id);
							setForm((f) => ({
								...f,
								modelId: id,
								modelName: m?.name ?? ""
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Weekly bias",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"bullish",
								"bearish",
								"neutral"
							],
							value: form.weeklyBias,
							onChange: (v) => patch("weeklyBias", one(v))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Daily bias",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"bullish",
								"bearish",
								"neutral"
							],
							value: form.dailyBias,
							onChange: (v) => patch("dailyBias", one(v))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Draw on liquidity",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: DRAWS,
						value: form.drawOnLiquidity,
						onChange: (v) => patch("drawOnLiquidity", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Dealing range",
					hint: "Entry is tagged premium / discount against this range.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "High",
							value: form.dealingRange.high,
							onChange: (n) => patch("dealingRange", {
								...form.dealingRange,
								high: n
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							label: "Low",
							value: form.dealingRange.low,
							onChange: (n) => patch("dealingRange", {
								...form.dealingRange,
								low: n
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeBar, {
							range: form.dealingRange,
							mark: form.entry,
							markLabel: "Entry"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Location",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"premium",
							"discount",
							"equilibrium"
						],
						value: form.location,
						onChange: (v) => patch("location", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Liquidity taken",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						multiple: true,
						options: LIQUIDITY_TYPES,
						value: form.taken,
						onChange: (v) => patch("taken", many(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Target",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						multiple: true,
						options: LIQUIDITY_TYPES,
						value: form.targetLiq,
						onChange: (v) => patch("targetLiq", many(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "PD array",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: PD_ARRAYS,
						value: form.pdArray,
						onChange: (v) => patch("pdArray", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Array timeframe",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: TIMEFRAMES,
							value: form.pdTimeframe,
							onChange: (v) => patch("pdTimeframe", one(v))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Array condition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"fresh",
								"partial",
								"mitigated",
								"invalidated"
							],
							value: form.pdCondition,
							onChange: (v) => patch("pdCondition", one(v))
						})
					})]
				}),
				model ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Invalid when: ", model.invalidWhen.join(" · ")]
				}) : null
			]
		});
		if (step === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trigger",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						multiple: true,
						options: TRIGGERS,
						value: form.triggers,
						onChange: (v) => patch("triggers", many(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Session",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: SESSIONS,
							value: form.session,
							onChange: (v) => patch("session", one(v))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kill zone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: KILL_ZONES,
							value: form.killZone,
							onChange: (v) => patch("killZone", one(v))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Time model",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: TIME_MODELS,
						value: form.timeModel,
						onChange: (v) => patch("timeModel", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Structure before",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"bullish",
								"bearish",
								"range",
								"compression",
								"expansion"
							],
							value: form.structureBefore,
							onChange: (v) => patch("structureBefore", one(v))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Displacement",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"weak",
								"normal",
								"strong"
							],
							value: form.displacementQuality,
							onChange: (v) => patch("displacementQuality", one(v))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "FVG created on displacement",
						value: form.fvgCreated,
						onChange: (v) => patch("fvgCreated", v)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "FVG timeframe",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: TIMEFRAMES,
							value: form.fvgTimeframe,
							onChange: (v) => patch("fvgTimeframe", one(v))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Optional, {
					title: "Judas / AMD (optional)",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Judas present",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"yes",
									"no",
									"unclear"
								],
								value: form.judas.present,
								onChange: (v) => patch("judas", {
									...form.judas,
									present: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Direction",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: ["higher", "lower"],
								value: form.judas.direction,
								onChange: (v) => patch("judas", {
									...form.judas,
									direction: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
							label: "Aligned with narrative",
							value: form.judas.aligned,
							onChange: (v) => patch("judas", {
								...form.judas,
								aligned: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "After Judas",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"reversal",
									"continuation",
									"failed"
								],
								value: form.judas.after,
								onChange: (v) => patch("judas", {
									...form.judas,
									after: one(v)
								})
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Optional, {
					title: "OTE (optional)",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "OTE",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"used",
									"not-used",
									"invalid"
								],
								value: form.ote.used,
								onChange: (v) => patch("ote", {
									...form.ote,
									used: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Swing high",
									value: form.ote.swingHigh,
									onChange: (n) => patch("ote", {
										...form.ote,
										swingHigh: n
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Swing low",
									value: form.ote.swingLow,
									onChange: (n) => patch("ote", {
										...form.ote,
										swingLow: n
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Retrace %",
									value: form.ote.retracement,
									onChange: (n) => patch("ote", {
										...form.ote,
										retracement: n
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
							label: "Entry inside OTE",
							value: form.ote.inside,
							onChange: (v) => patch("ote", {
								...form.ote,
								inside: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
							label: "PD array + OTE confluence",
							value: form.ote.confluence,
							onChange: (v) => patch("ote", {
								...form.ote,
								confluence: v
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Optional, {
					title: "SMT (optional)",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "SMT",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"no",
									"bullish",
									"bearish"
								],
								value: form.smt.present,
								onChange: (v) => patch("smt", {
									...form.smt,
									present: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Markets",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"XAUUSD ↔ DXY",
									"ES ↔ NQ",
									"EURUSD ↔ GBPUSD",
									"Other"
								],
								value: form.smt.pair,
								onChange: (v) => patch("smt", {
									...form.smt,
									pair: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Swept market",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.smt.sweptMarket,
								onChange: (e) => patch("smt", {
									...form.smt,
									sweptMarket: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
							label: "SMT before trigger",
							value: form.smt.beforeTrigger,
							onChange: (v) => patch("smt", {
								...form.smt,
								beforeTrigger: v
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Optional, {
					title: "CRT (optional)",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
							label: "CRT used",
							value: form.crt.used,
							onChange: (v) => patch("crt", {
								...form.crt,
								used: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Reference candle",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: TIMEFRAMES,
								value: form.crt.reference,
								onChange: (v) => patch("crt", {
									...form.crt,
									reference: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Range high",
								value: form.crt.high,
								onChange: (n) => patch("crt", {
									...form.crt,
									high: n
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Range low",
								value: form.crt.low,
								onChange: (n) => patch("crt", {
									...form.crt,
									low: n
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Raid",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
								options: [
									"high",
									"low",
									"neither"
								],
								value: form.crt.raidSide,
								onChange: (v) => patch("crt", {
									...form.crt,
									raidSide: one(v)
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
								label: "Purge",
								value: form.crt.purge,
								onChange: (v) => patch("crt", {
									...form.crt,
									purge: v
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
								label: "Reclaim",
								value: form.crt.reclaim,
								onChange: (v) => patch("crt", {
									...form.crt,
									reclaim: v
								})
							})]
						})
					]
				})
			]
		});
		if (step === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "TP2",
						value: form.tp2,
						onChange: (n) => patch("tp2", n)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "TP3",
						value: form.tp3,
						onChange: (n) => patch("tp3", n)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Risk %",
						value: form.riskPct,
						onChange: (n) => setForm((f) => ({
							...f,
							riskPct: n ?? plan.riskPerTrade,
							lots: null
						}))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Lots",
						value: lots,
						onChange: (n) => {
							if (n == null) {
								patch("lots", null);
								return;
							}
							if (n < 0) return;
							const riskPct = riskPctForLots(equity, n, form.entry, form.sl, inst);
							setForm((f) => ({
								...f,
								lots: n,
								...riskPct == null ? {} : { riskPct }
							}));
						}
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-md bg-surface-2 p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Current balance",
							v: BALANCE_FORMATTER.format(equity)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Stop distance",
							v: fmtPx(stop || null)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Risk $",
							v: `$${(equity * (form.riskPct / 100)).toFixed(0)}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Size (lots)",
							v: fmtLots(lots)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							k: "Confluence",
							v: `${score}/10`
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-subtle",
					children: [
						"Set risk % to calculate lots, or enter lots to calculate risk % from the stop and",
						" ",
						inst?.symbol ?? "instrument",
						" tick value. Confluence classifies the trade for research — it does not tell you to take it."
					]
				})]
			})]
		});
		if (step === 3) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Exit time (NY)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "time",
							value: form.exitTime,
							onChange: (e) => patch("exitTime", e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Computed R",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "flex h-11 items-center font-mono text-lg tabular-nums",
							children: rLive == null && form.rMultiple == null ? "—" : formatR(rLive ?? form.rMultiple ?? 0)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Exit reason",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: EXIT_REASONS,
						value: form.exitReason,
						onChange: (v) => patch("exitReason", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Management",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: MANAGEMENT,
						value: form.management,
						onChange: (v) => patch("management", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
						label: "Moved to BE",
						value: form.be,
						onChange: (v) => patch("be", v)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "Partial at R",
						value: form.partialAtR,
						onChange: (n) => patch("partialAtR", n)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "MAE (R)",
						value: form.maeR,
						onChange: (n) => patch("maeR", n)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
						label: "MFE (R)",
						value: form.mfeR,
						onChange: (n) => patch("mfeR", n)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "MAE / MFE answer whether stops are too tight and whether you give winners back."
				})
			]
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriRow, {
							label: "Narrative",
							value: form.narrativeCorrect,
							onChange: (v) => patch("narrativeCorrect", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriRow, {
							label: "Liquidity read",
							value: form.liquidityCorrect,
							onChange: (v) => patch("liquidityCorrect", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriRow, {
							label: "Location",
							value: form.locationCorrect,
							onChange: (v) => patch("locationCorrect", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriRow, {
							label: "Trigger",
							value: form.triggerCorrect,
							onChange: (v) => patch("triggerCorrect", v)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Entry quality",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"early",
							"optimal",
							"late",
							"chasing"
						],
						value: form.executionQuality,
						onChange: (v) => patch("executionQuality", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Delivery status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: [
							"pre",
							"early",
							"mid",
							"late",
							"delivered"
						],
						value: form.deliveryStatus,
						onChange: (v) => patch("deliveryStatus", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "What failed",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						multiple: true,
						options: ERRORS,
						value: form.errors,
						onChange: (v) => patch("errors", many(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Primary error",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
						options: ERRORS,
						value: form.primaryError,
						onChange: (v) => patch("primaryError", one(v))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Grade",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: [
								"A+",
								"A",
								"A-",
								"B",
								"C",
								"D",
								"F"
							],
							value: form.grade,
							onChange: (v) => patch("grade", one(v))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Emotion",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
							options: EMOTIONS.map((e) => ({
								value: e.value,
								label: e.label
							})),
							value: form.emotion,
							onChange: (v) => patch("emotion", one(v))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoolRow, {
					label: "Rules followed",
					value: form.ruleFollowed,
					onChange: (v) => patch("ruleFollowed", v)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "HTF screenshot or note",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.screenshotHtf,
								onChange: (e) => patch("screenshotHtf", e.target.value),
								placeholder: "PWH/PWL, weekly range, FVG…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "file",
								accept: "image/*",
								"aria-label": "Attach HTF screenshot",
								className: "mt-2",
								onChange: (e) => attachScreenshot("screenshotHtf", e.target.files?.[0])
							}),
							form.screenshotHtf.startsWith("data:image/") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: form.screenshotHtf,
								alt: "HTF chart attachment preview",
								className: "mt-2 max-h-32 rounded-lg border border-white/10 object-contain"
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Execution screenshot or note",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.screenshotExec,
								onChange: (e) => patch("screenshotExec", e.target.value),
								placeholder: "Sweep, MSS, FVG, entry, SL, TP…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "file",
								accept: "image/*",
								"aria-label": "Attach execution screenshot",
								className: "mt-2",
								onChange: (e) => attachScreenshot("screenshotExec", e.target.files?.[0])
							}),
							form.screenshotExec.startsWith("data:image/") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: form.screenshotExec,
								alt: "Execution chart attachment preview",
								className: "mt-2 max-h-32 rounded-lg border border-white/10 object-contain"
							}) : null
						]
					})]
				})
			]
		});
	}, [
		step,
		form,
		models,
		model,
		equity,
		lots,
		stop,
		score,
		inst,
		rLive,
		plan.riskPerTrade,
		patch,
		attachScreenshot
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: trade ? "Edit trade" : "Quick Trade" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Add the essentials now. Journal extra setup details only when you need them." })] }),
				tradeLock.reasons.length || tradeLock.warnings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 max-h-24 shrink-0 space-y-1 overflow-y-auto rounded-md bg-down/10 px-3 py-2 text-sm text-down",
					role: "alert",
					children: [
						tradeLock.reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: reason }, reason)),
						tradeLock.warnings.map((warning) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: warning }, warning)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: "Review these conditions before saving; you can still journal the trade."
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1 space-y-4 overflow-y-auto pr-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Market",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: form.market,
											onChange: (e) => patch("market", e.target.value.toUpperCase())
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Date",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "date",
											value: form.date,
											onChange: (e) => patch("date", e.target.value)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Time (NY)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "time",
											value: form.time,
											onChange: (e) => patch("time", e.target.value)
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Side",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
									options: ["long", "short"],
									value: form.side,
									onChange: (v) => patch("side", one(v))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
										label: "Entry",
										value: form.entry,
										onChange: (n) => patch("entry", n)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
										label: "Stop",
										value: form.sl,
										onChange: (n) => patch("sl", n)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
										label: "Target",
										value: form.tp1,
										onChange: (n) => patch("tp1", n)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Result",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
										options: [
											"open",
											"win",
											"loss",
											"be"
										],
										value: form.result,
										onChange: (v) => {
											const result = one(v);
											setForm((f) => ({
												...f,
												result,
												rMultiple: result === "open" ? null : computeTradeR({
													...f,
													result
												})
											}));
										}
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Exit price",
									value: form.exitPrice,
									onChange: (n) => patch("exitPrice", n)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Notes",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: form.notes,
									onChange: (e) => patch("notes", e.target.value),
									rows: 2,
									placeholder: "What happened?"
								})
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "rounded-md border border-border bg-surface-2/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
							className: "cursor-pointer text-sm font-medium",
							children: ["More details ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-1 text-xs font-normal text-muted-foreground",
								children: "· optional journal fields"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1.5 overflow-x-auto py-1",
								children: STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setStep(i),
									className: cn("h-9 shrink-0 rounded-full border px-3.5 text-xs font-medium transition-all", i === step ? "border-accent bg-accent font-semibold text-accent-foreground shadow-sm" : "border-border bg-surface-2 text-foreground/85 hover:border-foreground/30 hover:bg-surface-2/80 hover:text-foreground"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-1 opacity-70",
											children: i + 1
										}),
										" ",
										s
									]
								}, s))
							}), body]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
					className: "shrink-0 pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: saveTrade,
						children: trade ? "Save changes" : "Save trade"
					})
				})
			]
		})
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-[11px] tracking-wide text-muted-foreground uppercase",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-mono tabular-nums",
		children: v
	})] });
}
var Sheet = Dialog$1;
var SheetPortal = DialogPortal$1;
function SheetOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
		className: cn("fixed inset-0 z-50 bg-black/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:animate-out data-[state=closed]:fade-out-0", className),
		...props
	});
}
function SheetContent({ className, children, side = "right", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed z-50 flex flex-col border-white/[0.1] bg-[#080808] duration-[var(--motion-fast)] ease-[var(--ease-cinema)]", side === "right" && "inset-y-0 right-0 h-full w-full max-w-md border-l shadow-[-40px_0_80px_-40px_rgba(0,0,0,1)]", side === "left" && "inset-y-0 left-0 h-full w-full max-w-md border-r", side === "bottom" && "inset-x-0 bottom-0 max-h-[92dvh] rounded-t-2xl border-t", "data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:animate-out data-[state=closed]:fade-out-0", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-4 right-4 rounded-sm border border-white/[0.1] p-1.5 text-muted-foreground transition-colors hover:border-accent/50 hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative shrink-0 border-b border-white/[0.08] p-5 pr-12 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-accent/60 before:to-transparent", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("font-display text-2xl leading-tight tracking-wide", className),
		...props
	});
}
function SheetDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1.5 text-sm leading-relaxed text-muted-foreground", className),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-5 w-9 shrink-0 items-center rounded-sm border border-white/[0.12] transition-colors focus-visible:ring-2 focus-visible:ring-ring/50 data-[state=checked]:border-accent/60 data-[state=checked]:bg-accent data-[state=unchecked]:bg-surface-2", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block size-3.5 translate-x-0.5 rounded-xs bg-foreground transition-transform data-[state=checked]:translate-x-4.5 data-[state=checked]:bg-primary-foreground") })
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
		className: cn("fixed inset-0 z-50 bg-background/80", className),
		...props
	});
}
function AlertDialogContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-xl bg-card p-5 shadow-border", className),
		...props
	})] });
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("space-y-1", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
		className: cn("font-display text-2xl leading-tight", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
		...props
	});
}
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
		className: cn(buttonVariants(), className),
		...props
	});
}
function AlertDialogCancel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
		className: cn(buttonVariants({ variant: "outline" }), className),
		...props
	});
}
function ConfirmDelete({ open, onOpenChange, title, description, confirmLabel = "Delete", isPending = false, pendingLabel = "Working…", onConfirm }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: description })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			onClick: onConfirm,
			disabled: isPending,
			className: "bg-down/20 text-down hover:bg-down/30",
			children: isPending ? pendingLabel : confirmLabel
		})] })] })
	});
}
var ACCENT_COLORS = [
	{
		id: "cinema",
		name: "Cinema red",
		value: "#e50914",
		foreground: "#ffffff"
	},
	{
		id: "scarlet",
		name: "Scarlet",
		value: "#ff2d3f",
		foreground: "#ffffff"
	},
	{
		id: "wine",
		name: "Wine",
		value: "#9f1239",
		foreground: "#ffffff"
	},
	{
		id: "ember",
		name: "Ember",
		value: "#f5b942",
		foreground: "#111111"
	},
	{
		id: "ice",
		name: "Ice",
		value: "#7dd3fc",
		foreground: "#082f49"
	},
	{
		id: "violet",
		name: "Violet",
		value: "#c4b5fd",
		foreground: "#2e1065"
	},
	{
		id: "sage",
		name: "Sage",
		value: "#d4ded0",
		foreground: "#111111"
	}
];
var DEFAULT_ACCENT = "cinema";
var ACCENT_STORAGE_KEY = "first-payout-accent-color-v2";
function applyAccentColor(colorId) {
	const color = ACCENT_COLORS.find((option) => option.id === colorId);
	if (!color) return;
	const root = document.documentElement.style;
	root.setProperty("--color-accent", color.value);
	root.setProperty("--color-accent-foreground", color.foreground);
	root.setProperty("--color-primary", color.value);
	root.setProperty("--color-primary-foreground", color.foreground);
	root.setProperty("--color-ring", color.value);
}
function SettingsSheet({ open, onOpenChange }) {
	const data = useDeskStore();
	const patchAccount = useDeskStore((s) => s.patchAccount);
	const rebuildProtocolDates = useDeskStore((s) => s.rebuildProtocolDates);
	const resetAll = useDeskStore((s) => s.resetAll);
	const replaceAll = useDeskStore((s) => s.replaceAll);
	const [resetOpen, setResetOpen] = (0, import_react.useState)(false);
	const [isResetting, setIsResetting] = (0, import_react.useState)(false);
	const [accentColor, setAccentColor] = (0, import_react.useState)(DEFAULT_ACCENT);
	(0, import_react.useEffect)(() => {
		try {
			const saved = window.localStorage.getItem(ACCENT_STORAGE_KEY);
			const color = ACCENT_COLORS.find((option) => option.id === saved)?.id ?? DEFAULT_ACCENT;
			setAccentColor(color);
			applyAccentColor(color);
		} catch (error) {
			console.error("[settings] failed to load accent color:", error);
			applyAccentColor(DEFAULT_ACCENT);
		}
	}, []);
	const handleAccentColorChange = (color) => {
		setAccentColor(color);
		applyAccentColor(color);
		try {
			window.localStorage.setItem(ACCENT_STORAGE_KEY, color);
		} catch (error) {
			console.error("[settings] failed to save accent color:", error);
			toast.error("Color changed for this session but could not be saved.");
		}
	};
	const handleReset = async () => {
		setIsResetting(true);
		try {
			const resetState = createResetState();
			await saveDeskState({ data: resetState });
			resetAll(resetState);
			setResetOpen(false);
			toast.success("All desk data reset");
		} catch (error) {
			console.error("[settings] failed to reset desk data:", error);
			toast.error("Could not reset desk data. Your saved data was not changed.");
		} finally {
			setIsResetting(false);
		}
	};
	const downloadBackup = () => {
		const blob = new Blob([JSON.stringify(deskSnapshot(), null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const anchor = document.createElement("a");
		anchor.href = url;
		anchor.download = `first-payout-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
		anchor.click();
		URL.revokeObjectURL(url);
		toast.success("Backup downloaded");
	};
	const restoreBackup = async (file) => {
		try {
			if (file.size > 1e6) throw new Error("Backup exceeds the 1 MB limit.");
			const parsed = JSON.parse(await file.text());
			if (!isDeskData(parsed)) throw new Error("This file is not a valid First Payout backup.");
			if (!window.confirm(`Restore ${parsed.trades.length} trades and replace the current desk data?`)) return;
			await saveDeskState({ data: parsed });
			replaceAll(parsed);
			toast.success("Desk backup restored");
		} catch (error) {
			console.error("[settings] failed to restore desk backup:", error);
			toast.error(error instanceof Error ? error.message : "Could not restore the backup.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Account rules" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetDescription, { children: [
				"Funded-account constraints plus risk. ICT timing always uses ",
				TRADING_TZ,
				" — not the browser clock."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-lg border border-white/[0.08] bg-white/[0.02] p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-[10px] font-semibold tracking-[0.16em] text-accent uppercase",
									children: "Accent color"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: "Red is the desk default. Everything else is a deviation."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-label": "Accent color",
								className: "flex flex-wrap gap-3",
								role: "group",
								children: ACCENT_COLORS.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `${color.name} accent`,
									"aria-pressed": accentColor === color.id,
									title: color.name,
									onClick: () => handleAccentColorChange(color.id),
									className: `size-8 rounded-full border-2 transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 focus-visible:ring-offset-background ${accentColor === color.id ? "border-foreground scale-110" : "border-white/20 hover:scale-105"}`,
									style: { backgroundColor: color.value }
								}, color.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: ["Selected: ", ACCENT_COLORS.find((color) => color.id === accentColor)?.name]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Account name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: data.accountName,
							onChange: (e) => patchAccount({ accountName: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Starting balance",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.startingBalance,
									onChange: (e) => patchAccount({ startingBalance: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Payout threshold %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.5",
									value: data.rules.payoutThresholdPct,
									onChange: (e) => patchAccount({ payoutThresholdPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Profit target %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.5",
									value: data.rules.profitTargetPct,
									onChange: (e) => patchAccount({ profitTargetPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Profit split %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.profitSplit,
									onChange: (e) => patchAccount({ profitSplit: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max daily loss %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.1",
									value: data.rules.maxDailyLossPct,
									onChange: (e) => patchAccount({ maxDailyLossPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max total DD %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.1",
									value: data.rules.maxTotalDrawdownPct,
									onChange: (e) => patchAccount({ maxTotalDrawdownPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Normal risk %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.05",
									value: data.rules.normalRiskPct,
									onChange: (e) => patchAccount({ normalRiskPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "High-conviction %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.05",
									value: data.rules.highConvictionRiskPct,
									onChange: (e) => patchAccount({ highConvictionRiskPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max trades / day",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.maxTrades,
									onChange: (e) => patchAccount({ maxTrades: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max consecutive losses",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.maxConsecutiveLosses,
									onChange: (e) => patchAccount({ maxConsecutiveLosses: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Window start (NY)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "time",
									value: data.rules.windowStart,
									onChange: (e) => patchAccount({ windowStart: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Window end (NY)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "time",
									value: data.rules.windowEnd,
									onChange: (e) => patchAccount({ windowEnd: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Min trading days",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.minTradingDays,
									onChange: (e) => patchAccount({ minTradingDays: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Consistency cap %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: data.rules.consistencyPct,
									onChange: (e) => patchAccount({ consistencyPct: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max lots",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									value: data.rules.maxPositionLots,
									onChange: (e) => patchAccount({ maxPositionLots: Number(e.target.value) })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Protocol start",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: data.rules.protocolStartDate,
									onChange: (e) => rebuildProtocolDates(e.target.value)
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-md bg-surface-2 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "News restricted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: data.rules.newsRestricted,
							onCheckedChange: (v) => patchAccount({ newsRestricted: v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-md bg-surface-2 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: "Weekend restricted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: data.rules.weekendRestricted,
							onCheckedChange: (v) => patchAccount({ weekendRestricted: v })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Scaling note",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: data.rules.scalingNote,
							onChange: (e) => patchAccount({ scalingNote: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mantra",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: data.mantra,
							onChange: (e) => patchAccount({ mantra: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									try {
										patchAccount({
											accountName: data.accountName,
											phaseId: data.phaseId,
											mantra: data.mantra,
											...data.rules
										});
										toast.success("Account settings saved");
										onOpenChange(false);
									} catch (error) {
										console.error("[settings] failed to save account settings:", error);
										toast.error("Could not save account settings");
									}
								},
								children: "Save settings"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: downloadBackup,
								children: "Download backup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "cursor-pointer",
									children: ["Restore backup", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "application/json",
										className: "hidden",
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (file) restoreBackup(file);
											e.currentTarget.value = "";
										}
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "destructive",
								onClick: () => setResetOpen(true),
								children: "Reset All Data"
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDelete, {
			open: resetOpen,
			onOpenChange: setResetOpen,
			title: "Reset all desk data?",
			description: "This permanently clears your trades, plans, notes, settings, and checklist progress. Your standard checklist will return unchecked. This cannot be undone.",
			confirmLabel: "Reset All Data",
			isPending: isResetting,
			pendingLabel: "Resetting…",
			onConfirm: () => void handleReset()
		})]
	});
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
/**
* React binding for P2PRoom. Identity and room id are captured once on mount
* (useState initializers) so re-renders never tear down the mesh: the P2PRoom
* instance lives exactly as long as the component that mounted it, and
* changing `room`/`name` requires a remount (key the component on them).
*/
function defaultRoom() {
	if (typeof window === "undefined") return "room-ssr";
	return `room-${window.location.hostname.split(".")[0]}`.slice(0, 64);
}
function useP2PRoom(options = {}) {
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [room] = (0, import_react.useState)(() => options.room ?? defaultRoom());
	const [name] = (0, import_react.useState)(() => options.name ?? selfId);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true)
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, [])
	};
}
function parseRead(data) {
	if (typeof data !== "object" || data === null) return null;
	const message = data;
	if (message.type !== "desk-read") return null;
	if (typeof message.read !== "object" || message.read === null) return null;
	const read = message.read;
	if (typeof read.handle !== "string" || typeof read.market !== "string") return null;
	if (typeof read.sentAt !== "string") return null;
	return {
		handle: read.handle,
		account: typeof read.account === "string" ? read.account : "",
		phase: typeof read.phase === "number" ? read.phase : 1,
		day: typeof read.day === "number" ? read.day : 1,
		market: read.market,
		bias: typeof read.bias === "string" ? read.bias : "—",
		draw: typeof read.draw === "string" ? read.draw : "—",
		delivery: typeof read.delivery === "string" ? read.delivery : "—",
		equity: typeof read.equity === "string" ? read.equity : "—",
		payoutPct: typeof read.payoutPct === "number" ? read.payoutPct : 0,
		rToDanger: typeof read.rToDanger === "number" ? read.rToDanger : 0,
		sentAt: read.sentAt
	};
}
var STATE_TONE = {
	connected: "bg-up",
	connecting: "bg-warn",
	new: "bg-warn",
	disconnected: "bg-down",
	failed: "bg-down",
	closed: "bg-subtle"
};
function RoomSheet({ open, onOpenChange }) {
	const [roomInput, setRoomInput] = (0, import_react.useState)("");
	const [activeRoom, setActiveRoom] = (0, import_react.useState)(null);
	const handle = (useDeskStore().accountName || "Trader").slice(0, 40);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "overflow-y-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Live room" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Pair directly with one other trader over WebRTC. Signaling only relays offers between you — the desk read never touches the database, and the room closes when you close this panel." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Room code",
							placeholder: "Room code, e.g. london-am",
							value: roomInput,
							onChange: (event) => setRoomInput(event.target.value.replace(/[^a-zA-Z0-9_-]/g, ""))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							onClick: () => setActiveRoom(roomInput.trim() || "desk-main"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { "aria-hidden": "true" }),
								" ",
								activeRoom ? "Rejoin" : "Join"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: [
							"Both sides need to enter the same code. Leave the field empty to use ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "font-mono",
								children: "desk-main"
							}),
							"."
						]
					}),
					activeRoom ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomSession, {
						room: activeRoom,
						handle
					}, activeRoom) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 rounded-lg border border-dashed border-white/[0.12] px-4 py-8 text-center text-sm text-muted-foreground",
						children: "Not in a room. Join to see who is online."
					})
				]
			})]
		})
	});
}
function RoomSession({ room, handle }) {
	const p2p = useP2PRoom({
		room,
		name: handle
	});
	const data = useDeskStore();
	const [reads, setReads] = (0, import_react.useState)([]);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const seen = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const { onMessage } = p2p;
	(0, import_react.useEffect)(() => {
		return onMessage((from, payload) => {
			const read = parseRead(payload);
			if (!read) return;
			const key = `${from}:${read.sentAt}`;
			if (seen.current.has(key)) return;
			seen.current.add(key);
			setReads((current) => [read, ...current].slice(0, 12));
			toast.info(`${read.handle} shared a read`);
		});
	}, [onMessage]);
	const connected = p2p.peers.filter((peer) => peer.connectionState === "connected");
	const share = () => {
		if (!connected.length) {
			toast.info("No connected peers yet — wait for the other side to appear.");
			return;
		}
		const today = todayISO();
		const plan = planFor(data, today);
		const pay = payoutProgress(data);
		const danger = remainingRToDanger(data, today);
		const read = {
			handle,
			account: data.accountName,
			phase: data.phaseId,
			day: protocolDayNumber(data),
			market: plan.market || "—",
			bias: plan.expectedDelivery || plan.htfStructure,
			draw: plan.expectedDraw || "—",
			delivery: plan.expectedDelivery || "—",
			equity: formatMoney(currentBalance(data)),
			payoutPct: Math.round(pay.pct),
			rToDanger: Math.round(danger.dailyR),
			sentAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		p2p.send({
			type: "desk-read",
			read
		});
		toast.success(`Read shared with ${connected.length} peer${connected.length === 1 ? "" : "s"}`);
	};
	const copyRoom = async () => {
		try {
			await navigator.clipboard.writeText(room);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			toast.error("Could not copy the room code.");
		}
	};
	const summary = (0, import_react.useMemo)(() => p2p.joined ? `${p2p.peers.length} peer${p2p.peers.length === 1 ? "" : "s"}` : "Connecting", [p2p.joined, p2p.peers.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-lg border border-white/[0.09] bg-card/70",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-3.5 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("size-1.5 rounded-full", p2p.joined ? "bg-up" : "bg-warn animate-pulse"),
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-foreground",
							children: room
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-muted-foreground",
							children: summary
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					onClick: copyRoom,
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "aria-hidden": "true" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "aria-hidden": "true" }), copied ? "Copied" : "Copy code"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-3.5",
				children: [p2p.peers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2.5 rounded-md border border-dashed border-white/[0.12] px-3 py-4 text-sm text-muted-foreground",
					children: p2p.joined ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, {
						className: "size-4 shrink-0",
						"aria-hidden": "true"
					}), "Waiting for the other trader to join this code."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "size-4 shrink-0 animate-spin",
						"aria-hidden": "true"
					}), "Registering with the signaling service…"] })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1.5",
					children: p2p.peers.map((peer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md border border-white/[0.07] bg-white/[0.02] px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("size-1.5 rounded-full", STATE_TONE[peer.connectionState] ?? "bg-subtle"),
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate text-sm text-foreground",
								children: peer.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[10px] text-subtle",
								children: ["#", peer.id.slice(-4)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-[11px] text-muted-foreground",
								children: [
									peer.connectionState,
									peer.rttMs != null ? ` · ${peer.rttMs}ms` : "",
									peer.candidateType ? ` · ${peer.candidateType}` : ""
								]
							})
						]
					}, peer.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					className: "mt-3 w-full",
					onClick: share,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { "aria-hidden": "true" }), " Share today's read"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "mb-2 flex items-center gap-2 text-[10px] font-semibold tracking-[0.16em] text-accent uppercase",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
				className: "size-3.5",
				"aria-hidden": "true"
			}), " Peer reads"]
		}), reads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-lg border border-dashed border-white/[0.1] px-3 py-6 text-center text-sm text-muted-foreground",
			children: "Nothing received yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2",
			children: reads.map((read) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-lg border border-white/[0.08] bg-card/60 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-foreground",
							children: read.handle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[10px] text-muted-foreground",
							children: new Date(read.sentAt).toLocaleTimeString([], {
								hour: "2-digit",
								minute: "2-digit"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							"Phase ",
							read.phase,
							" · Day ",
							read.day,
							" · ",
							read.market
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-2 grid grid-cols-2 gap-1.5 text-[11px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCell, {
								k: "Bias",
								v: read.bias
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCell, {
								k: "Draw",
								v: read.draw
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCell, {
								k: "Equity",
								v: read.equity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadCell, {
								k: "Payout",
								v: `${read.payoutPct}%`
							})
						]
					})
				]
			}, `${read.handle}-${read.sentAt}`))
		})] })]
	});
}
function ReadCell({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-white/[0.06] bg-white/[0.02] px-2 py-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "truncate font-medium capitalize text-foreground",
			children: v
		})]
	});
}
var DropdownMenu = Root2$1;
var DropdownMenuTrigger = Trigger;
var DropdownMenuPortal = Portal2$1;
function DropdownMenuContent({ className, sideOffset = 6, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
		sideOffset,
		className: cn("z-50 min-w-40 overflow-hidden rounded-md bg-popover p-1 text-popover-foreground shadow-border", className),
		...props
	}) });
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
		className: cn("flex cursor-pointer items-center gap-2 rounded-sm px-2.5 py-2 text-sm outline-none select-none focus:bg-surface-2 data-disabled:pointer-events-none data-disabled:opacity-40", variant === "destructive" && "text-down focus:bg-down/10", inset && "pl-8", className),
		...props
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
function DropdownMenuLabel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
		className: cn("px-2.5 py-1.5 text-xs font-medium text-muted-foreground", className),
		...props
	});
}
function DropdownMenuCheckboxItem({ className, children, checked, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
		className: cn("relative flex cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-xs outline-none transition-colors focus:bg-surface-2 focus:text-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
		checked,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-accent" }) })
		}), children]
	});
}
var NAV = [
	{
		to: "/",
		label: "Today",
		icon: LayoutDashboard
	},
	{
		to: "/weekly",
		label: "Weekly",
		icon: CalendarRange
	},
	{
		to: "/daily",
		label: "Daily",
		icon: Sun
	},
	{
		to: "/playbook",
		label: "Playbook",
		icon: Compass
	},
	{
		to: "/journal",
		label: "Journal",
		icon: BookOpen
	},
	{
		to: "/replay",
		label: "Replay",
		icon: RotateCcw
	},
	{
		to: "/analytics",
		label: "Analytics",
		icon: ChartLine
	},
	{
		to: "/protocol",
		label: "Protocol",
		icon: ListChecks
	}
];
var MOBILE = [
	{
		to: "/",
		label: "Today",
		icon: LayoutDashboard
	},
	{
		to: "/weekly",
		label: "Weekly",
		icon: CalendarRange
	},
	{
		to: "/journal",
		label: "Journal",
		icon: BookOpen
	},
	{
		to: "/analytics",
		label: "Edge",
		icon: ChartLine
	}
];
var MOBILE_MORE = [
	{
		to: "/daily",
		label: "Daily map"
	},
	{
		to: "/playbook",
		label: "Playbook"
	},
	{
		to: "/replay",
		label: "Replay"
	},
	{
		to: "/protocol",
		label: "Protocol"
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const phaseId = useDeskStore((s) => s.phaseId);
	const phases = useDeskStore((s) => s.phases);
	const accountName = useDeskStore((s) => s.accountName);
	const [tradeOpen, setTradeOpen] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [roomOpen, setRoomOpen] = (0, import_react.useState)(false);
	const [sidebarExpanded, setSidebarExpanded] = (0, import_react.useState)(true);
	const syncStatus = useDeskSyncStatus();
	const locked = useDeskStore((s) => lockInfo(s, todayISO()).locked);
	const day = useDeskStore((s) => protocolDayNumber(s));
	const phase = phases.find((p) => p.id === phaseId);
	const syncLabel = {
		local: "Local only",
		loading: "Connecting",
		saved: "Cloud saved",
		saving: "Syncing",
		error: "Sync issue"
	}[syncStatus];
	const SyncIcon = syncStatus === "error" ? CloudOff : syncStatus === "saving" || syncStatus === "loading" ? CloudUpload : Cloud;
	const handleMobileSignOut = () => {
		signOut().catch((error) => {
			console.error("[auth] sign-out failed:", error);
			toast.error(error instanceof Error ? error.message : "Could not sign out. Please try again.");
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				id: "primary-sidebar",
				"aria-label": "Primary navigation",
				className: cn("sticky top-0 hidden h-dvh shrink-0 flex-col overflow-hidden border-r border-white/[0.08] bg-black/50 px-2.5 py-5 lg:flex", sidebarExpanded ? "w-56" : "w-[68px]"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("mb-7 flex items-center gap-2.5 px-1.5", !sidebarExpanded && "justify-center px-0"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-8 shrink-0 items-center justify-center rounded-sm bg-accent text-primary-foreground shadow-[0_8px_20px_-10px_rgba(229,9,20,0.9)] transition hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
							"aria-label": sidebarExpanded ? "Collapse sidebar" : "Expand sidebar",
							"aria-controls": "primary-sidebar",
							"aria-expanded": sidebarExpanded,
							title: sidebarExpanded ? "Collapse sidebar" : "Expand sidebar",
							onClick: () => setSidebarExpanded((expanded) => !expanded),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" })
						}), sidebarExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-lg leading-none tracking-wide text-foreground",
								children: "First Payout"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-nowrap text-[9px] font-semibold tracking-[0.2em] text-accent uppercase",
								children: "ICT desk terminal"
							})]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-0.5",
						children: NAV.map((item) => {
							const active = pathname === item.to;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								title: !sidebarExpanded ? item.label : void 0,
								"aria-label": item.label,
								"aria-current": active ? "page" : void 0,
								className: cn("relative flex h-9 items-center gap-2.5 rounded-sm text-[12px] font-medium transition-colors duration-150", sidebarExpanded ? "px-2.5" : "justify-center px-0", active ? "bg-white/[0.06] text-foreground before:absolute before:inset-y-1.5 before:left-0 before:w-0.5 before:rounded-full before:bg-accent" : "text-muted-foreground hover:bg-white/[0.03] hover:text-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
									className: cn("size-4 shrink-0", active ? "text-accent" : "text-muted-foreground"),
									"aria-hidden": "true"
								}), sidebarExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "whitespace-nowrap",
									children: item.label
								}) : null]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("mt-auto w-full border-t border-white/[0.08] pt-3", sidebarExpanded ? "px-1" : "flex flex-col items-center px-0"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => setRoomOpen(true),
								className: cn("mb-2 w-full justify-start gap-2 text-muted-foreground hover:bg-white/[0.05] hover:text-foreground", !sidebarExpanded && "justify-center px-0"),
								"aria-label": "Open live room",
								title: "Live room",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
									className: "size-3.5 shrink-0",
									"aria-hidden": "true"
								}), sidebarExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-medium",
									children: "Live room"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => setSettingsOpen(true),
								className: cn("mb-3 w-full justify-start gap-2 rounded-sm border border-white/[0.08] text-muted-foreground transition hover:border-white/[0.2] hover:bg-white/[0.04] hover:text-foreground", !sidebarExpanded && "justify-center px-0"),
								"aria-label": "Open settings",
								title: "Settings",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {
									className: "size-3.5 shrink-0",
									"aria-hidden": "true"
								}), sidebarExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-medium",
									children: "Settings"
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("flex w-full items-center font-mono text-[10px] text-muted-foreground", sidebarExpanded ? "justify-between" : "justify-center"),
								children: sidebarExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Day ", day] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1 text-up",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-1 rounded-full bg-up animate-pulse",
										"aria-hidden": "true"
									}), " Live NY"]
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-1.5 rounded-full bg-up animate-pulse",
									title: `Day ${day} · Live NY`
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("mt-3 w-full border-t border-white/[0.08] pt-3", !sidebarExpanded && "flex justify-center"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, { collapsed: !sidebarExpanded })
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 flex items-center gap-2.5 border-b border-white/[0.08] bg-background/85 px-4 py-2.5 backdrop-blur-xl md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden truncate text-[10px] font-semibold tracking-[0.16em] text-muted-foreground uppercase sm:block",
								children: accountName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: locked ? "down" : "up",
									className: "gap-1.5 whitespace-nowrap",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("size-1 rounded-full", locked ? "bg-down" : "bg-up animate-pulse"),
										"aria-hidden": "true"
									}), locked ? "Platform closed" : "Session open"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "default",
									className: "whitespace-nowrap",
									children: [
										"Phase ",
										phaseId,
										" · ",
										phase?.name
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Open live room",
							title: "Live room",
							onClick: () => setRoomOpen(true),
							className: "rounded-sm border border-white/[0.08] hover:border-accent/40 hover:text-accent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
								className: "size-4",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": "Settings",
							title: "Settings",
							onClick: () => setSettingsOpen(true),
							className: "rounded-sm border border-white/[0.08] hover:border-white/[0.2]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {
								className: "size-4",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							role: "status",
							title: syncLabel,
							className: cn("inline-flex shrink-0 items-center gap-1.5 text-[10px] font-medium", syncStatus === "error" ? "text-down" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SyncIcon, {
								className: cn("size-3.5", (syncStatus === "saving" || syncStatus === "loading") && "animate-pulse"),
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: syncLabel
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => setTradeOpen(true),
							className: "gap-1.5 transition-transform active:scale-95",
							"aria-label": "Quick trade",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-4 shrink-0",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold",
								children: "Quick trade"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-6xl flex-1 px-4 py-6 pb-24 md:px-8 md:pb-12",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-white/[0.08] bg-black/90 backdrop-blur-xl lg:hidden",
				children: [MOBILE.map((item) => {
					const active = pathname === item.to;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						"aria-current": active ? "page" : void 0,
						className: cn("relative flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium tracking-wide uppercase transition-colors", active ? "text-accent" : "text-muted-foreground hover:text-foreground"),
						children: [
							active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute inset-x-3 top-0 h-0.5 rounded-full bg-accent",
								"aria-hidden": "true"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
								className: "size-4",
								"aria-hidden": "true"
							}),
							item.label
						]
					}, item.to);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuTrigger, {
					className: cn("flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium tracking-wide uppercase", MOBILE_MORE.some((item) => item.to === pathname) ? "text-accent" : "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {
						className: "size-4",
						"aria-hidden": "true"
					}), "More"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
					align: "end",
					className: "mb-2 border-white/[0.12] bg-popover",
					children: [
						MOBILE_MORE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
							onSelect: () => void navigate({ to: item.to }),
							children: item.label
						}, item.to)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
							onSelect: () => setRoomOpen(true),
							children: "Live room"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
							onSelect: () => setSettingsOpen(true),
							children: "Settings"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
							onSelect: handleMobileSignOut,
							children: "Sign out"
						})
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeWizard, {
				open: tradeOpen,
				onOpenChange: setTradeOpen,
				trade: null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {
				open: settingsOpen,
				onOpenChange: setSettingsOpen
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomSheet, {
				open: roomOpen,
				onOpenChange: setRoomOpen
			})
		]
	});
}
//#endregion
export { tradesOn as $, conceptMatrix as A, lockInfo as B, Switch as C, biasConfidence as D, avgWinR as E, errorBreakdown as F, profitFactor as G, maxDrawdownPct as H, expectancyR as I, ruleFollowRate as J, protocolDayNumber as K, fmtCurrency as L, dayOfWeekTable as M, dealingMeta as N, calcTradeMetrics as O, equityCurve as P, tradeDollarPnl as Q, fmtPx as R, RangeBar as S, avgLossR as T, payoutProgress as U, maeMfeStats as V, planFor as W, sumR as X, sumPnlPct as Y, todayProtocol as Z, DropdownMenuSeparator as _, ConfirmDelete as a, NumField as b, DialogDescription as c, DialogTitle as d, weeklyFor as et, DropdownMenu as f, DropdownMenuLabel as g, DropdownMenuItem as h, Chips as i, currentBalance as j, closedTrades as k, DialogFooter as l, DropdownMenuContent as m, Badge as n, worstStreak as nt, Dialog as o, DropdownMenuCheckboxItem as p, remainingRToDanger as q, BoolRow as r, DialogContent as s, AppShell as t, winRate as tt, DialogHeader as u, DropdownMenuTrigger as v, Textarea as w, Panel as x, Field as y, instrumentOf as z };
