//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cf9JYsE1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analytics",
			"/daily",
			"/journal",
			"/login",
			"/playbook",
			"/protocol",
			"/replay",
			"/weekly",
			"/api/rtc",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-cQ5gSkyp.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/use-current-user-zMt4namc.js",
			"/assets/dist-Cvrf_3W2.js",
			"/assets/utils-BAiaOJRZ.js",
			"/assets/guest-session-Dg7C5CWH.js",
			"/assets/ict-store-_3EHN3g6.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-cQ5gSkyp.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CR1PdJ9Z.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/kpi-card-BEsxX_CV.js",
			"/assets/trash-2-CThzJfik.js",
			"/assets/input-CGKgD91O.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	},
	"/analytics": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-Bw9j3lqp.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/kpi-card-BEsxX_CV.js",
			"/assets/input-CGKgD91O.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	},
	"/daily": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/daily.tsx",
		children: void 0,
		preloads: [
			"/assets/daily-7b4zW9r1.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/input-CGKgD91O.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	},
	"/journal": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-1NmFh8Bf.js",
			"/assets/search-BVXUz4j2.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/trash-2-CThzJfik.js",
			"/assets/input-CGKgD91O.js"
		]
	},
	"/login": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-D8YovDYs.js",
			"/assets/client-DRhaju3Z.js",
			"/assets/input-CGKgD91O.js"
		]
	},
	"/playbook": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/playbook.tsx",
		children: void 0,
		preloads: [
			"/assets/playbook-CRhLFPr3.js",
			"/assets/search-BVXUz4j2.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/trash-2-CThzJfik.js",
			"/assets/input-CGKgD91O.js"
		]
	},
	"/protocol": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/protocol.tsx",
		children: void 0,
		preloads: [
			"/assets/protocol-BPvcZqTh.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	},
	"/replay": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/replay.tsx",
		children: void 0,
		preloads: [
			"/assets/replay-BWn1Kvat.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	},
	"/weekly": {
		filePath: "C:/Users/Niles/Desktop/FUll ICT Concept -grok-workspace (2)/FUll ICT Concept -grok-workspace/src/routes/weekly.tsx",
		children: void 0,
		preloads: [
			"/assets/weekly-CZ-oo39L.js",
			"/assets/app-shell-Bo8IA1Oi.js",
			"/assets/input-CGKgD91O.js",
			"/assets/page-header-D94G0Fz8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
